/*
  # Fix Admin View Access for Buyers

  ## Changes
  - Add RLS policy to allow authenticated admins to view ALL buyers (including pending_approval)
  - This enables admins to see pending approvals in the admin dashboard

  ## Security
  - Policy checks that the user is in the admins table with is_active = true
  - Only applies to SELECT operations for authenticated users
*/

-- Drop existing policy if it exists and create new one
DO $$
BEGIN
  DROP POLICY IF EXISTS "Admins can view all buyers" ON buyers;
END $$;

-- Create policy for admins to view all buyers
CREATE POLICY "Admins can view all buyers"
  ON buyers
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM admins
      WHERE admins.user_id = auth.uid()
      AND admins.is_active = true
    )
  );
