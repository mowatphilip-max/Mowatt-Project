/*
  # Add Appraisal Document Storage

  1. Changes to `seller_questionnaires` table
    - Add `appraisal_document` (jsonb) - stores the full appraisal data
    - Add `appraisal_generated_at` (timestamptz) - timestamp when appraisal was generated
    - Add `appraisal_status` (text) - status: 'pending', 'generated', 'approved', 'sent'
    - Add `appraisal_sent_at` (timestamptz) - timestamp when appraisal was sent to client
    - Add `appraisal_approved_by` (uuid) - admin who approved it
    - Add `appraisal_sent_by` (uuid) - admin who sent it
    
  2. Notes
    - Appraisals are generated but not sent automatically
    - Admin must review and approve before sending
    - All appraisal data stored in database for admin access
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'seller_questionnaires' AND column_name = 'appraisal_document'
  ) THEN
    ALTER TABLE seller_questionnaires ADD COLUMN appraisal_document jsonb DEFAULT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'seller_questionnaires' AND column_name = 'appraisal_generated_at'
  ) THEN
    ALTER TABLE seller_questionnaires ADD COLUMN appraisal_generated_at timestamptz DEFAULT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'seller_questionnaires' AND column_name = 'appraisal_status'
  ) THEN
    ALTER TABLE seller_questionnaires ADD COLUMN appraisal_status text DEFAULT 'pending';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'seller_questionnaires' AND column_name = 'appraisal_sent_at'
  ) THEN
    ALTER TABLE seller_questionnaires ADD COLUMN appraisal_sent_at timestamptz DEFAULT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'seller_questionnaires' AND column_name = 'appraisal_approved_by'
  ) THEN
    ALTER TABLE seller_questionnaires ADD COLUMN appraisal_approved_by uuid REFERENCES auth.users(id) DEFAULT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'seller_questionnaires' AND column_name = 'appraisal_sent_by'
  ) THEN
    ALTER TABLE seller_questionnaires ADD COLUMN appraisal_sent_by uuid REFERENCES auth.users(id) DEFAULT NULL;
  END IF;
END $$;