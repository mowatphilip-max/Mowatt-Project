/*
  # Add Location Circle Preferences to Buyers

  ## Changes
  - Add `location_circles` column to buyers table to store drawn map circles
  - Each circle contains: center coordinates (lat/lng), radius in meters, and optional label

  ## Data Structure
  The location_circles column stores a JSONB array of circle objects:
  [
    {
      "lat": 55.9533,
      "lng": -3.1883,
      "radius": 5000,
      "label": "City Center"
    }
  ]

  ## Notes
  - Circles represent areas where buyers want to find homes
  - Buyers can draw multiple circles on the map
  - Radius is in meters for accurate distance calculations
*/

-- Add location_circles column to buyers table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'location_circles'
  ) THEN
    ALTER TABLE buyers ADD COLUMN location_circles JSONB DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Create index for better query performance on location data
CREATE INDEX IF NOT EXISTS idx_buyers_location_circles ON buyers USING GIN (location_circles);
