/*
  # Add image URL to properties table

  1. Changes
    - Add `image_url` column to `properties` table to store property images
    - Set default value to empty string for existing records

  2. Notes
    - Existing properties will have empty image_url initially
    - Can be updated via application or future migrations
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'properties' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE properties ADD COLUMN image_url text DEFAULT '';
  END IF;
END $$;
