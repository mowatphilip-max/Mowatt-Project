/*
  # Add detailed buyer preference fields

  1. New Columns
    - `bathrooms_min` (integer) - Minimum bathrooms required
    - `property_type_preferences` (text[]) - Array of property types (Detached, Semi-Detached, etc.)
    - `must_haves` (text[]) - Essential features required
    - `outdoor_space` (text[]) - Outdoor space preferences
    - `parking` (text[]) - Parking requirements
    - `property_condition` (text) - Desired property condition
    - `timeline` (text) - When looking to move
    - `email` (text) - Contact email
    - `phone` (text) - Contact phone

  2. Changes
    - Adds comprehensive fields for buyer requirements
    - Enables detailed matching based on specific needs
    - Stores contact information for follow-up

  3. Notes
    - All new fields are nullable to support existing records
    - Array fields default to empty arrays
    - Helps estate agents understand exact buyer requirements
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'bathrooms_min'
  ) THEN
    ALTER TABLE buyers ADD COLUMN bathrooms_min integer DEFAULT NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'property_type_preferences'
  ) THEN
    ALTER TABLE buyers ADD COLUMN property_type_preferences text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'must_haves'
  ) THEN
    ALTER TABLE buyers ADD COLUMN must_haves text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'outdoor_space'
  ) THEN
    ALTER TABLE buyers ADD COLUMN outdoor_space text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'parking'
  ) THEN
    ALTER TABLE buyers ADD COLUMN parking text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'property_condition'
  ) THEN
    ALTER TABLE buyers ADD COLUMN property_condition text DEFAULT NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'timeline'
  ) THEN
    ALTER TABLE buyers ADD COLUMN timeline text DEFAULT NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'email'
  ) THEN
    ALTER TABLE buyers ADD COLUMN email text DEFAULT NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'phone'
  ) THEN
    ALTER TABLE buyers ADD COLUMN phone text DEFAULT NULL;
  END IF;
END $$;
