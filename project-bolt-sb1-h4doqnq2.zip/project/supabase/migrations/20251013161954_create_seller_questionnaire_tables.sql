/*
  # Create Seller Questionnaire and Listing Tables

  ## New Tables
  
  ### `seller_questionnaires`
  Stores all information collected from sellers about their property
  - `id` (uuid, primary key)
  - `user_id` (uuid, foreign key to auth.users)
  - `status` (text) - draft, submitted, under_review, verified, rejected
  
  #### Property Basic Information
  - `property_address` (text)
  - `property_postcode` (text)
  - `property_type` (text) - detached, semi-detached, terraced, flat, bungalow
  - `year_built` (integer)
  - `builder_name` (text)
  - `is_show_home` (boolean)
  
  #### Property Details
  - `num_bedrooms` (integer)
  - `num_bathrooms` (integer)
  - `num_reception_rooms` (integer)
  - `square_meters` (numeric)
  - `square_feet` (numeric)
  
  #### Property Features
  - `kitchen_details` (text)
  - `heating_type` (text)
  - `glazing_type` (text)
  - `parking_details` (text)
  - `garage_details` (text)
  - `special_features` (jsonb) - array of special features
  
  #### Outdoor Space
  - `garden_description` (text)
  - `garden_size` (text)
  - `garden_orientation` (text)
  - `outdoor_features` (jsonb)
  
  #### Condition & Upgrades
  - `property_condition` (text)
  - `recent_upgrades` (jsonb)
  - `boiler_age` (integer)
  - `windows_condition` (text)
  
  #### Location & Amenities
  - `area_description` (text)
  - `nearby_amenities` (jsonb)
  - `walking_distances` (jsonb)
  
  #### Valuation
  - `desired_price_min` (numeric)
  - `desired_price_max` (numeric)
  - `valuation_low` (numeric)
  - `valuation_mid` (numeric)
  - `valuation_high` (numeric)
  - `price_per_sqft` (numeric)
  
  #### Seller Information
  - `seller_name` (text)
  - `seller_email` (text)
  - `seller_phone` (text)
  - `how_long_owned` (text)
  - `reason_for_selling` (text)
  - `timeline` (text)
  - `preferred_sale_route` (text) - off_market, open_market, both
  
  #### Additional
  - `additional_notes` (text)
  - `comparable_properties` (jsonb)
  - `images` (jsonb) - array of image URLs
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)
  - `submitted_at` (timestamptz)
  - `verified_at` (timestamptz)
  - `verified_by` (uuid, foreign key to auth.users)
  - `report_id` (text) - e.g., MOW-036
  
  ### Update `properties` table
  Add verification fields to existing properties table
  - `is_verified` (boolean)
  - `verified_at` (timestamptz)
  - `verified_by` (uuid)
  - `questionnaire_id` (uuid, foreign key to seller_questionnaires)
  
  ## Security
  - Enable RLS on `seller_questionnaires` table
  - Sellers can only view/edit their own questionnaires
  - Admins can view all questionnaires
*/

-- Create seller_questionnaires table
CREATE TABLE IF NOT EXISTS seller_questionnaires (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'submitted', 'under_review', 'verified', 'rejected')),
  
  -- Property Basic Information
  property_address text,
  property_postcode text,
  property_type text CHECK (property_type IN ('detached', 'semi-detached', 'terraced', 'flat', 'bungalow', 'apartment', 'villa', 'other')),
  year_built integer,
  builder_name text,
  is_show_home boolean DEFAULT false,
  
  -- Property Details
  num_bedrooms integer,
  num_bathrooms integer,
  num_reception_rooms integer,
  square_meters numeric,
  square_feet numeric,
  
  -- Property Features
  kitchen_details text,
  heating_type text,
  glazing_type text,
  parking_details text,
  garage_details text,
  special_features jsonb DEFAULT '[]'::jsonb,
  
  -- Outdoor Space
  garden_description text,
  garden_size text,
  garden_orientation text,
  outdoor_features jsonb DEFAULT '[]'::jsonb,
  
  -- Condition & Upgrades
  property_condition text,
  recent_upgrades jsonb DEFAULT '[]'::jsonb,
  boiler_age integer,
  windows_condition text,
  
  -- Location & Amenities
  area_description text,
  nearby_amenities jsonb DEFAULT '[]'::jsonb,
  walking_distances jsonb DEFAULT '{}'::jsonb,
  
  -- Valuation
  desired_price_min numeric,
  desired_price_max numeric,
  valuation_low numeric,
  valuation_mid numeric,
  valuation_high numeric,
  price_per_sqft numeric,
  
  -- Seller Information
  seller_name text,
  seller_email text,
  seller_phone text,
  how_long_owned text,
  reason_for_selling text,
  timeline text,
  preferred_sale_route text CHECK (preferred_sale_route IN ('off_market', 'open_market', 'both')),
  
  -- Additional
  additional_notes text,
  comparable_properties jsonb DEFAULT '[]'::jsonb,
  images jsonb DEFAULT '[]'::jsonb,
  
  -- Timestamps
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  submitted_at timestamptz,
  verified_at timestamptz,
  verified_by uuid REFERENCES auth.users(id),
  report_id text
);

-- Add verification fields to properties table
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'is_verified') THEN
    ALTER TABLE properties ADD COLUMN is_verified boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'verified_at') THEN
    ALTER TABLE properties ADD COLUMN verified_at timestamptz;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'verified_by') THEN
    ALTER TABLE properties ADD COLUMN verified_by uuid REFERENCES auth.users(id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'questionnaire_id') THEN
    ALTER TABLE properties ADD COLUMN questionnaire_id uuid REFERENCES seller_questionnaires(id);
  END IF;
END $$;

-- Enable RLS on seller_questionnaires
ALTER TABLE seller_questionnaires ENABLE ROW LEVEL SECURITY;

-- Sellers can view their own questionnaires
CREATE POLICY "Sellers can view own questionnaires"
  ON seller_questionnaires
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Sellers can insert their own questionnaires
CREATE POLICY "Sellers can create questionnaires"
  ON seller_questionnaires
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Sellers can update their own draft questionnaires
CREATE POLICY "Sellers can update own draft questionnaires"
  ON seller_questionnaires
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND status = 'draft')
  WITH CHECK (auth.uid() = user_id);

-- Admins can view all questionnaires
CREATE POLICY "Admins can view all questionnaires"
  ON seller_questionnaires
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admins
      WHERE admins.user_id = auth.uid()
    )
  );

-- Admins can update all questionnaires
CREATE POLICY "Admins can update questionnaires"
  ON seller_questionnaires
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admins
      WHERE admins.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admins
      WHERE admins.user_id = auth.uid()
    )
  );

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_seller_questionnaires_user_id ON seller_questionnaires(user_id);
CREATE INDEX IF NOT EXISTS idx_seller_questionnaires_status ON seller_questionnaires(status);
CREATE INDEX IF NOT EXISTS idx_properties_questionnaire_id ON properties(questionnaire_id);
