/*
  # Mowatt Matchlist Database Schema

  ## Overview
  This migration creates the database structure for matching property buyers and sellers
  in a private, off-market property platform.

  ## New Tables

  ### `properties` (Hush Homes for Sale)
  - `id` (uuid, primary key)
  - `title` (text) - e.g., "Stunning Victorian Townhouse"
  - `property_type` (text) - e.g., "Detached", "Semi-Detached", "Flat"
  - `bedrooms` (integer)
  - `bathrooms` (integer)
  - `price_min` (numeric) - For price ranges
  - `price_max` (numeric)
  - `area_name` (text) - Public area name e.g., "Central Edinburgh"
  - `exact_address` (text) - Private, only shown after registration
  - `latitude` (numeric) - Exact coordinates for internal use
  - `longitude` (numeric)
  - `approximate_lat` (numeric) - Offset coordinates for public display
  - `approximate_lng` (numeric)
  - `description` (text) - Teaser description
  - `key_features` (text[]) - Array of features
  - `square_feet` (integer)
  - `status` (text) - 'active', 'matched', 'sold'
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### `buyers` (Quiet Seekers)
  - `id` (uuid, primary key)
  - `seeker_name` (text) - Anonymous name like "Buyer #123"
  - `looking_for` (text) - Property type seeking
  - `bedrooms_min` (integer)
  - `bedrooms_max` (integer)
  - `budget_min` (numeric)
  - `budget_max` (numeric)
  - `area_preferences` (text[]) - Array of preferred areas
  - `latitude` (numeric) - Exact location (if provided)
  - `longitude` (numeric)
  - `approximate_lat` (numeric)
  - `approximate_lng` (numeric)
  - `requirements` (text) - Description of requirements
  - `status` (text) - 'active', 'matched', 'purchased'
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### `registrations` (Commission Agreements)
  - `id` (uuid, primary key)
  - `user_id` (uuid, references auth.users)
  - `full_name` (text)
  - `email` (text)
  - `phone` (text)
  - `interested_in_type` (text) - 'buyer' or 'seller'
  - `interested_in_id` (uuid) - References property or buyer
  - `commission_agreed` (boolean)
  - `commission_percentage` (numeric) - Default 1%
  - `agreement_date` (timestamptz)
  - `created_at` (timestamptz)

  ### `matches` (Property Matches)
  - `id` (uuid, primary key)
  - `property_id` (uuid, references properties)
  - `buyer_id` (uuid, references buyers)
  - `match_score` (integer) - Algorithm score 0-100
  - `status` (text) - 'suggested', 'viewing_scheduled', 'completed', 'rejected'
  - `created_at` (timestamptz)

  ## Security
  - Enable RLS on all tables
  - Public can view active properties and buyers (limited fields)
  - Authenticated users who registered can view full details
  - Only authenticated internal users can manage data

  ## Notes
  - Approximate coordinates are offset by ~1-2km for privacy
  - Full address only revealed after registration and commission agreement
  - Commission is 1% of purchase/sale price
*/

-- Create properties table
CREATE TABLE IF NOT EXISTS properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  property_type text NOT NULL,
  bedrooms integer NOT NULL,
  bathrooms integer NOT NULL,
  price_min numeric NOT NULL,
  price_max numeric NOT NULL,
  area_name text NOT NULL,
  exact_address text NOT NULL,
  latitude numeric NOT NULL,
  longitude numeric NOT NULL,
  approximate_lat numeric NOT NULL,
  approximate_lng numeric NOT NULL,
  description text NOT NULL,
  key_features text[] DEFAULT '{}',
  square_feet integer,
  status text DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create buyers table
CREATE TABLE IF NOT EXISTS buyers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seeker_name text NOT NULL,
  looking_for text NOT NULL,
  bedrooms_min integer,
  bedrooms_max integer,
  budget_min numeric NOT NULL,
  budget_max numeric NOT NULL,
  area_preferences text[] DEFAULT '{}',
  latitude numeric,
  longitude numeric,
  approximate_lat numeric,
  approximate_lng numeric,
  requirements text,
  status text DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create registrations table
CREATE TABLE IF NOT EXISTS registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  full_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  interested_in_type text NOT NULL,
  interested_in_id uuid NOT NULL,
  commission_agreed boolean DEFAULT false,
  commission_percentage numeric DEFAULT 1.0,
  agreement_date timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create matches table
CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid REFERENCES properties(id),
  buyer_id uuid REFERENCES buyers(id),
  match_score integer DEFAULT 0,
  status text DEFAULT 'suggested',
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE buyers ENABLE ROW LEVEL SECURITY;
ALTER TABLE registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;

-- Properties policies (public can view active, limited fields)
CREATE POLICY "Anyone can view active properties"
  ON properties FOR SELECT
  USING (status = 'active');

CREATE POLICY "Authenticated users can insert properties"
  ON properties FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update properties"
  ON properties FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Buyers policies (public can view active)
CREATE POLICY "Anyone can view active buyers"
  ON buyers FOR SELECT
  USING (status = 'active');

CREATE POLICY "Authenticated users can insert buyers"
  ON buyers FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update buyers"
  ON buyers FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Registrations policies (users can view their own)
CREATE POLICY "Users can view own registrations"
  ON registrations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Anyone can create registrations"
  ON registrations FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update own registrations"
  ON registrations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Matches policies (authenticated users only)
CREATE POLICY "Authenticated users can view matches"
  ON matches FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create matches"
  ON matches FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update matches"
  ON matches FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_properties_status ON properties(status);
CREATE INDEX IF NOT EXISTS idx_buyers_status ON buyers(status);
CREATE INDEX IF NOT EXISTS idx_registrations_user_id ON registrations(user_id);
CREATE INDEX IF NOT EXISTS idx_matches_property_id ON matches(property_id);
CREATE INDEX IF NOT EXISTS idx_matches_buyer_id ON matches(buyer_id);