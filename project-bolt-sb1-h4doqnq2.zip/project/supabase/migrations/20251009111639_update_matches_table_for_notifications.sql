/*
  # Update matches table for email notifications

  1. Changes
    - Add `match_reasons` array column to store why properties match
    - Add `notification_sent` boolean to track email status
    - Add `notification_sent_at` timestamp for when email was sent
    - Update status default and add index for notification filtering

  2. Security
    - No changes to RLS policies

  3. Indexes
    - Add index on notification_sent for filtering unsent notifications
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'matches' AND column_name = 'match_reasons'
  ) THEN
    ALTER TABLE matches ADD COLUMN match_reasons text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'matches' AND column_name = 'notification_sent'
  ) THEN
    ALTER TABLE matches ADD COLUMN notification_sent boolean DEFAULT false;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'matches' AND column_name = 'notification_sent_at'
  ) THEN
    ALTER TABLE matches ADD COLUMN notification_sent_at timestamptz DEFAULT NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'matches' AND column_name = 'updated_at'
  ) THEN
    ALTER TABLE matches ADD COLUMN updated_at timestamptz DEFAULT now();
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_matches_notification_sent ON matches(notification_sent);
