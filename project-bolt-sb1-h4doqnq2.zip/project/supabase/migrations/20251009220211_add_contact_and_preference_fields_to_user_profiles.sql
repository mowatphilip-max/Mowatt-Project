/*
  # Add Contact Details and Preferences to User Profiles

  1. New Columns for Contact Information
    - `phone` (text) - User's mobile/phone number
    - `address` (text) - User's current address
    - `postcode` (text) - User's postcode
    
  2. New Columns for Property Preferences
    - `bedrooms_min` (integer) - Minimum bedrooms required
    - `bathrooms_min` (integer) - Minimum bathrooms required
    - `price_min` (numeric) - Minimum budget
    - `price_max` (numeric) - Maximum budget
    - `property_type_preferences` (text[]) - Array of property types
    - `preferred_areas` (text[]) - Array of preferred locations
    - `must_haves` (text[]) - Essential features
    - `outdoor_space` (text[]) - Outdoor space preferences
    - `parking` (text[]) - Parking requirements
    - `property_condition` (text) - Desired property condition
    - `timeline` (text) - When looking to move
    
  3. Security
    - Maintains existing RLS policies
    
  4. Notes
    - All fields are nullable to support existing records
    - Enables proper match score calculation
    - Collects essential contact information for follow-up
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'phone'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN phone text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'address'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN address text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'postcode'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN postcode text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'bedrooms_min'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN bedrooms_min integer;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'bathrooms_min'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN bathrooms_min integer;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'price_min'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN price_min numeric;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'price_max'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN price_max numeric;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'property_type_preferences'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN property_type_preferences text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'preferred_areas'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN preferred_areas text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'must_haves'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN must_haves text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'outdoor_space'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN outdoor_space text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'parking'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN parking text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'property_condition'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN property_condition text;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'user_profiles' AND column_name = 'timeline'
  ) THEN
    ALTER TABLE user_profiles ADD COLUMN timeline text;
  END IF;
END $$;
