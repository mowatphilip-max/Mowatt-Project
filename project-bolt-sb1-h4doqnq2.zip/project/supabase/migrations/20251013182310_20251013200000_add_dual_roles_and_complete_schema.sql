/*
  # Complete Schema and Add Dual-Role Support

  ## Overview
  This migration completes the database schema with all necessary fields and adds support
  for users to be BOTH buyers AND sellers simultaneously.

  ## Key Changes

  ### 1. Create `user_profiles` table
  Central table for all user accounts with role tracking
  - `id` (uuid, primary key)
  - `user_id` (uuid, unique foreign key to auth.users)
  - `full_name` (text)
  - `email` (text)
  - `phone` (text)
  - `address` (text)
  - `postcode` (text)
  - `is_buyer` (boolean) - User is registered as a buyer
  - `is_seller` (boolean) - User is registered as a seller
  - `buyer_commission_agreed` (boolean) - Agreed to 1% buyer commission
  - `buyer_commission_date` (timestamptz)
  - Buyer preferences fields
  - Timestamps

  ### 2. Add missing columns to existing tables
  - Add `user_id` to `buyers` table (link to auth.users)
  - Add fields from other migrations (image_url, preferences, etc.)

  ### 3. Create `admins` table (if not exists)
  - Track admin users with roles

  ### 4. Create `seller_questionnaires` table (if not exists)
  - Store detailed seller questionnaire data

  ### 5. Update RLS policies for dual-role support

  ## Business Logic
  - Sellers list for FREE with NO commission
  - Buyers pay 1% commission on purchase
  - Users can be BOTH buyer and seller
  - Seamless transition between questionnaires

  ## Security
  - All tables have RLS enabled
  - Users can only access their own data
  - Admins have full access
*/

-- ============================================================================
-- 1. CREATE USER_PROFILES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) UNIQUE NOT NULL,
  full_name text,
  email text,
  phone text,
  address text,
  postcode text,
  
  -- Role tracking
  is_buyer boolean DEFAULT false,
  is_seller boolean DEFAULT false,
  
  -- Buyer commission agreement
  buyer_commission_agreed boolean DEFAULT false,
  buyer_commission_date timestamptz,
  
  -- Buyer preferences (from buyer questionnaire)
  bedrooms_min integer,
  bathrooms_min integer,
  price_min numeric,
  price_max numeric,
  property_type_preferences text[] DEFAULT '{}',
  preferred_areas text[] DEFAULT '{}',
  must_haves text[] DEFAULT '{}',
  outdoor_space text[] DEFAULT '{}',
  parking text[] DEFAULT '{}',
  property_condition text,
  timeline text,
  
  -- Timestamps
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 2. ADD MISSING COLUMNS TO EXISTING TABLES
-- ============================================================================

-- Add columns to buyers table
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'user_id') THEN
    ALTER TABLE buyers ADD COLUMN user_id uuid REFERENCES auth.users(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'email') THEN
    ALTER TABLE buyers ADD COLUMN email text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'phone') THEN
    ALTER TABLE buyers ADD COLUMN phone text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'buyer_position') THEN
    ALTER TABLE buyers ADD COLUMN buyer_position text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'street_preferences') THEN
    ALTER TABLE buyers ADD COLUMN street_preferences text[] DEFAULT '{}';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'property_types') THEN
    ALTER TABLE buyers ADD COLUMN property_types text[] DEFAULT '{}';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'must_haves') THEN
    ALTER TABLE buyers ADD COLUMN must_haves text[] DEFAULT '{}';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'outdoor_space_prefs') THEN
    ALTER TABLE buyers ADD COLUMN outdoor_space_prefs text[] DEFAULT '{}';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'parking_prefs') THEN
    ALTER TABLE buyers ADD COLUMN parking_prefs text[] DEFAULT '{}';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'condition_pref') THEN
    ALTER TABLE buyers ADD COLUMN condition_pref text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'timeline') THEN
    ALTER TABLE buyers ADD COLUMN timeline text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'buyers' AND column_name = 'location_circles') THEN
    ALTER TABLE buyers ADD COLUMN location_circles jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Add columns to properties table
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'image_url') THEN
    ALTER TABLE properties ADD COLUMN image_url text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'is_verified') THEN
    ALTER TABLE properties ADD COLUMN is_verified boolean DEFAULT false;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'verified_at') THEN
    ALTER TABLE properties ADD COLUMN verified_at timestamptz;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'verified_by') THEN
    ALTER TABLE properties ADD COLUMN verified_by uuid REFERENCES auth.users(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'questionnaire_id') THEN
    ALTER TABLE properties ADD COLUMN questionnaire_id uuid;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'user_id') THEN
    ALTER TABLE properties ADD COLUMN user_id uuid REFERENCES auth.users(id);
  END IF;
END $$;

-- Add columns to matches table
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'matches' AND column_name = 'buyer_notified') THEN
    ALTER TABLE matches ADD COLUMN buyer_notified boolean DEFAULT false;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'matches' AND column_name = 'seller_notified') THEN
    ALTER TABLE matches ADD COLUMN seller_notified boolean DEFAULT false;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'matches' AND column_name = 'notes') THEN
    ALTER TABLE matches ADD COLUMN notes text;
  END IF;
END $$;

-- ============================================================================
-- 3. CREATE ADMINS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) UNIQUE NOT NULL,
  full_name text NOT NULL,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'admin' CHECK (role IN ('admin', 'super_admin', 'viewer')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 4. CREATE SELLER_QUESTIONNAIRES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS seller_questionnaires (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'submitted', 'under_review', 'verified', 'rejected')),
  
  -- Property Basic Information
  property_address text,
  property_postcode text,
  property_type text CHECK (property_type IN ('detached', 'semi-detached', 'terraced', 'flat', 'bungalow', 'apartment', 'villa', 'other')),
  year_built integer,
  builder_name text,
  is_show_home boolean DEFAULT false,
  
  -- Property Details
  num_bedrooms integer,
  num_bathrooms integer,
  num_reception_rooms integer,
  square_meters numeric,
  square_feet numeric,
  
  -- Property Features
  kitchen_details text,
  heating_type text,
  glazing_type text,
  parking_details text,
  garage_details text,
  special_features jsonb DEFAULT '[]'::jsonb,
  
  -- Outdoor Space
  garden_description text,
  garden_size text,
  garden_orientation text,
  outdoor_features jsonb DEFAULT '[]'::jsonb,
  
  -- Condition & Upgrades
  property_condition text,
  recent_upgrades jsonb DEFAULT '[]'::jsonb,
  boiler_age integer,
  windows_condition text,
  
  -- Location & Amenities
  area_description text,
  nearby_amenities jsonb DEFAULT '[]'::jsonb,
  walking_distances jsonb DEFAULT '{}'::jsonb,
  
  -- Valuation
  desired_price_min numeric,
  desired_price_max numeric,
  valuation_low numeric,
  valuation_mid numeric,
  valuation_high numeric,
  price_per_sqft numeric,
  
  -- Seller Information
  seller_name text,
  seller_email text,
  seller_phone text,
  how_long_owned text,
  reason_for_selling text,
  timeline text,
  preferred_sale_route text CHECK (preferred_sale_route IN ('off_market', 'open_market', 'both')),
  
  -- Additional
  additional_notes text,
  comparable_properties jsonb DEFAULT '[]'::jsonb,
  images jsonb DEFAULT '[]'::jsonb,
  
  -- Timestamps
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  submitted_at timestamptz,
  verified_at timestamptz,
  verified_by uuid REFERENCES auth.users(id),
  report_id text
);

-- Add foreign key to properties if not exists
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'properties' AND column_name = 'questionnaire_id') THEN
    ALTER TABLE properties DROP CONSTRAINT IF EXISTS properties_questionnaire_id_fkey;
    ALTER TABLE properties ADD CONSTRAINT properties_questionnaire_id_fkey 
      FOREIGN KEY (questionnaire_id) REFERENCES seller_questionnaires(id);
  END IF;
END $$;

-- ============================================================================
-- 5. ENABLE RLS AND CREATE POLICIES
-- ============================================================================

-- Enable RLS on new tables
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE seller_questionnaires ENABLE ROW LEVEL SECURITY;

-- User Profiles Policies
CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own profile"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all profiles"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

CREATE POLICY "Admins can update all profiles"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

-- Admins Policies
CREATE POLICY "Admins can view all admins"
  ON admins FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

-- Seller Questionnaires Policies
CREATE POLICY "Sellers can view own questionnaires"
  ON seller_questionnaires FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Sellers can create questionnaires"
  ON seller_questionnaires FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Sellers can update own draft questionnaires"
  ON seller_questionnaires FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND status = 'draft')
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all questionnaires"
  ON seller_questionnaires FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

CREATE POLICY "Admins can update all questionnaires"
  ON seller_questionnaires FOR UPDATE
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

-- ============================================================================
-- 6. CREATE INDEXES
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_is_buyer ON user_profiles(is_buyer);
CREATE INDEX IF NOT EXISTS idx_user_profiles_is_seller ON user_profiles(is_seller);
CREATE INDEX IF NOT EXISTS idx_user_profiles_email ON user_profiles(email);
CREATE INDEX IF NOT EXISTS idx_buyers_user_id ON buyers(user_id);
CREATE INDEX IF NOT EXISTS idx_properties_user_id ON properties(user_id);
CREATE INDEX IF NOT EXISTS idx_properties_questionnaire_id ON properties(questionnaire_id);
CREATE INDEX IF NOT EXISTS idx_seller_questionnaires_user_id ON seller_questionnaires(user_id);
CREATE INDEX IF NOT EXISTS idx_seller_questionnaires_status ON seller_questionnaires(status);
CREATE INDEX IF NOT EXISTS idx_admins_user_id ON admins(user_id);