/*
  # Add street preferences and buyer position to buyers table

  1. Changes
    - Add `street_preferences` array column to store specific streets buyers are interested in
    - Add `buyer_position` column to indicate their purchasing position
  
  2. Buyer Position Options
    - "Home currently up for sale with Mowatts Matchlist"
    - "Home under offer with Mowatts Matchlist"
    - "Cash buyer - Nothing to sell"
    - null for unspecified

  3. Notes
    - Street preferences is optional and can be empty array
    - Buyer position helps estate agents understand urgency and feasibility
    - Default values set for existing records
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'street_preferences'
  ) THEN
    ALTER TABLE buyers ADD COLUMN street_preferences text[] DEFAULT '{}';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'buyers' AND column_name = 'buyer_position'
  ) THEN
    ALTER TABLE buyers ADD COLUMN buyer_position text DEFAULT NULL;
  END IF;
END $$;
