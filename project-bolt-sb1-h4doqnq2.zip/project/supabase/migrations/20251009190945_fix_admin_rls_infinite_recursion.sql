/*
  # Fix Admin RLS Infinite Recursion

  ## Changes
  - Drop existing admin policies that cause infinite recursion
  - Create new policies that directly check auth.uid() against user_id
  - This prevents the circular dependency where checking admin status requires querying admins table

  ## Security
  - Authenticated users can view their own admin record
  - Only users with admin records can view all admin records
*/

-- Drop old problematic policies
DROP POLICY IF EXISTS "Admins can view admin records" ON admins;
DROP POLICY IF EXISTS "Super admins can insert admins" ON admins;
DROP POLICY IF EXISTS "Super admins can update admins" ON admins;

-- Allow authenticated users to view their own admin record
CREATE POLICY "Users can view own admin record"
  ON admins FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Allow service role to insert admins (via edge functions)
CREATE POLICY "Service role can insert admins"
  ON admins FOR INSERT
  TO service_role
  WITH CHECK (true);

-- Allow admins to update their own last login
CREATE POLICY "Admins can update own record"
  ON admins FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());
