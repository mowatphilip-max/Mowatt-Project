/*
  # Legal Services Integration System

  ## Overview
  Complete legal conveyancing services integration allowing:
  - Legal firms to register and manage pricing
  - Users (buyers/sellers) to select legal services
  - 20% deposit collection by Mowatt
  - Price matrix based on property value

  ## New Tables

  ### 1. `legal_firms`
  Legal firms offering conveyancing services
  - `id` (uuid, primary key)
  - `user_id` (uuid, foreign key to auth.users) - For firm login
  - `firm_name` (text) - Legal firm name
  - `contact_name` (text) - Main contact person
  - `email` (text, unique) - Firm email
  - `phone` (text) - Contact phone
  - `address` (text) - Firm address
  - `registration_number` (text) - Legal registration/license number
  - `is_active` (boolean) - Firm is accepting new clients
  - `is_verified` (boolean) - Verified by Mowatt admin
  - `services_offered` (text[]) - e.g., ['buying', 'selling', 'remortgage']
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 2. `legal_pricing`
  Pricing matrix for each legal firm
  - `id` (uuid, primary key)
  - `legal_firm_id` (uuid, foreign key to legal_firms)
  - `service_type` (text) - 'buying' or 'selling'
  - `price_min` (numeric) - Property value range minimum
  - `price_max` (numeric) - Property value range maximum
  - `conveyancing_fee` (numeric) - Legal firm's fee
  - `mowatt_charge` (numeric) - 20% of conveyancing fee
  - `total_deposit_required` (numeric) - Amount user pays upfront (20%)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 3. `legal_service_requests`
  Track users requesting legal services
  - `id` (uuid, primary key)
  - `user_id` (uuid, foreign key to auth.users)
  - `legal_firm_id` (uuid, foreign key to legal_firms)
  - `service_type` (text) - 'buying' or 'selling'
  - `property_value` (numeric) - Expected property value
  - `conveyancing_fee` (numeric) - Fee quoted at time of request
  - `deposit_amount` (numeric) - 20% deposit amount
  - `deposit_paid` (boolean) - Whether deposit has been paid
  - `deposit_paid_at` (timestamptz)
  - `payment_intent_id` (text) - Stripe payment ID
  - `status` (text) - 'pending', 'deposit_paid', 'in_progress', 'completed', 'cancelled'
  - `property_address` (text) - Address of property
  - `notes` (text) - Additional notes from user
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ### 4. Update `user_profiles`
  Add legal service tracking
  - `has_legal_service_buyer` (boolean)
  - `has_legal_service_seller` (boolean)
  - `legal_firm_id_buyer` (uuid)
  - `legal_firm_id_seller` (uuid)

  ## Security
  - RLS enabled on all tables
  - Legal firms can only view/edit their own data
  - Users can view all active legal firms but only their own requests
  - Admins have full access

  ## Business Logic
  - Mowatt charges 20% of the legal fee as platform fee
  - Users pay 20% deposit upfront
  - Legal fees vary based on property value brackets
  - Each legal firm sets their own pricing matrix
*/

-- ============================================================================
-- 1. CREATE LEGAL_FIRMS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS legal_firms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) UNIQUE,
  firm_name text NOT NULL,
  contact_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  address text,
  registration_number text,
  is_active boolean DEFAULT true,
  is_verified boolean DEFAULT false,
  services_offered text[] DEFAULT ARRAY['buying', 'selling'],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 2. CREATE LEGAL_PRICING TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS legal_pricing (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_firm_id uuid REFERENCES legal_firms(id) ON DELETE CASCADE NOT NULL,
  service_type text NOT NULL CHECK (service_type IN ('buying', 'selling')),
  price_min numeric NOT NULL,
  price_max numeric NOT NULL,
  conveyancing_fee numeric NOT NULL,
  mowatt_charge numeric GENERATED ALWAYS AS (conveyancing_fee * 0.20) STORED,
  total_deposit_required numeric GENERATED ALWAYS AS (conveyancing_fee * 0.20) STORED,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_price_range CHECK (price_max > price_min),
  CONSTRAINT valid_fee CHECK (conveyancing_fee > 0)
);

-- ============================================================================
-- 3. CREATE LEGAL_SERVICE_REQUESTS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS legal_service_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  legal_firm_id uuid REFERENCES legal_firms(id) NOT NULL,
  service_type text NOT NULL CHECK (service_type IN ('buying', 'selling')),
  property_value numeric NOT NULL,
  conveyancing_fee numeric NOT NULL,
  deposit_amount numeric NOT NULL,
  deposit_paid boolean DEFAULT false,
  deposit_paid_at timestamptz,
  payment_intent_id text,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'deposit_paid', 'in_progress', 'completed', 'cancelled')),
  property_address text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- ============================================================================
-- 4. UPDATE USER_PROFILES TABLE
-- ============================================================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_profiles' AND column_name = 'has_legal_service_buyer') THEN
    ALTER TABLE user_profiles ADD COLUMN has_legal_service_buyer boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_profiles' AND column_name = 'has_legal_service_seller') THEN
    ALTER TABLE user_profiles ADD COLUMN has_legal_service_seller boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_profiles' AND column_name = 'legal_firm_id_buyer') THEN
    ALTER TABLE user_profiles ADD COLUMN legal_firm_id_buyer uuid REFERENCES legal_firms(id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'user_profiles' AND column_name = 'legal_firm_id_seller') THEN
    ALTER TABLE user_profiles ADD COLUMN legal_firm_id_seller uuid REFERENCES legal_firms(id);
  END IF;
END $$;

-- ============================================================================
-- 5. ENABLE RLS
-- ============================================================================

ALTER TABLE legal_firms ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal_pricing ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal_service_requests ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- 6. LEGAL_FIRMS POLICIES
-- ============================================================================

-- Anyone can view active verified legal firms
CREATE POLICY "Anyone can view active verified legal firms"
  ON legal_firms FOR SELECT
  USING (is_active = true AND is_verified = true);

-- Legal firms can view their own data
CREATE POLICY "Legal firms can view own data"
  ON legal_firms FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Legal firms can update their own data
CREATE POLICY "Legal firms can update own data"
  ON legal_firms FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Admins can view all legal firms
CREATE POLICY "Admins can view all legal firms"
  ON legal_firms FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

-- Admins can update all legal firms
CREATE POLICY "Admins can update all legal firms"
  ON legal_firms FOR UPDATE
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

-- Admins can insert legal firms
CREATE POLICY "Admins can insert legal firms"
  ON legal_firms FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

-- ============================================================================
-- 7. LEGAL_PRICING POLICIES
-- ============================================================================

-- Anyone can view pricing for active verified firms
CREATE POLICY "Anyone can view pricing for active firms"
  ON legal_pricing FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM legal_firms
      WHERE legal_firms.id = legal_pricing.legal_firm_id
      AND legal_firms.is_active = true
      AND legal_firms.is_verified = true
    )
  );

-- Legal firms can manage their own pricing
CREATE POLICY "Legal firms can manage own pricing"
  ON legal_pricing FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM legal_firms
      WHERE legal_firms.id = legal_pricing.legal_firm_id
      AND legal_firms.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM legal_firms
      WHERE legal_firms.id = legal_pricing.legal_firm_id
      AND legal_firms.user_id = auth.uid()
    )
  );

-- Admins can manage all pricing
CREATE POLICY "Admins can manage all pricing"
  ON legal_pricing FOR ALL
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

-- ============================================================================
-- 8. LEGAL_SERVICE_REQUESTS POLICIES
-- ============================================================================

-- Users can view their own requests
CREATE POLICY "Users can view own legal service requests"
  ON legal_service_requests FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Users can create requests
CREATE POLICY "Users can create legal service requests"
  ON legal_service_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own pending requests
CREATE POLICY "Users can update own pending requests"
  ON legal_service_requests FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND status = 'pending')
  WITH CHECK (auth.uid() = user_id);

-- Legal firms can view their requests
CREATE POLICY "Legal firms can view their requests"
  ON legal_service_requests FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM legal_firms
      WHERE legal_firms.id = legal_service_requests.legal_firm_id
      AND legal_firms.user_id = auth.uid()
    )
  );

-- Legal firms can update their requests
CREATE POLICY "Legal firms can update their requests"
  ON legal_service_requests FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM legal_firms
      WHERE legal_firms.id = legal_service_requests.legal_firm_id
      AND legal_firms.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM legal_firms
      WHERE legal_firms.id = legal_service_requests.legal_firm_id
      AND legal_firms.user_id = auth.uid()
    )
  );

-- Admins can view all requests
CREATE POLICY "Admins can view all legal service requests"
  ON legal_service_requests FOR SELECT
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

-- Admins can update all requests
CREATE POLICY "Admins can update all legal service requests"
  ON legal_service_requests FOR UPDATE
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM admins WHERE admins.user_id = auth.uid())
  );

-- ============================================================================
-- 9. CREATE INDEXES
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_legal_firms_user_id ON legal_firms(user_id);
CREATE INDEX IF NOT EXISTS idx_legal_firms_is_active ON legal_firms(is_active);
CREATE INDEX IF NOT EXISTS idx_legal_firms_is_verified ON legal_firms(is_verified);
CREATE INDEX IF NOT EXISTS idx_legal_pricing_firm_id ON legal_pricing(legal_firm_id);
CREATE INDEX IF NOT EXISTS idx_legal_pricing_service_type ON legal_pricing(service_type);
CREATE INDEX IF NOT EXISTS idx_legal_service_requests_user_id ON legal_service_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_legal_service_requests_firm_id ON legal_service_requests(legal_firm_id);
CREATE INDEX IF NOT EXISTS idx_legal_service_requests_status ON legal_service_requests(status);

-- ============================================================================
-- 10. INSERT SAMPLE LEGAL FIRM (Watermans Legal)
-- ============================================================================

-- Insert Watermans Legal as sample firm
INSERT INTO legal_firms (
  firm_name,
  contact_name,
  email,
  phone,
  address,
  is_active,
  is_verified,
  services_offered
) VALUES (
  'Watermans Legal',
  'Contact Name',
  'contact@watermanslegal.co.uk',
  '01234567890',
  'Legal Address',
  true,
  true,
  ARRAY['buying', 'selling']
) ON CONFLICT (email) DO NOTHING
RETURNING id;

-- Insert Watermans pricing matrix for buying
DO $$
DECLARE
  firm_id uuid;
BEGIN
  SELECT id INTO firm_id FROM legal_firms WHERE email = 'contact@watermanslegal.co.uk';
  
  IF firm_id IS NOT NULL THEN
    INSERT INTO legal_pricing (legal_firm_id, service_type, price_min, price_max, conveyancing_fee) VALUES
    (firm_id, 'buying', 50000, 149999.99, 1134.00),
    (firm_id, 'buying', 150000, 249999.99, 1194.00),
    (firm_id, 'buying', 250000, 349999.99, 1134.00),
    (firm_id, 'buying', 350000, 499999.99, 1434.00),
    (firm_id, 'buying', 500000, 599999.99, 1554.00),
    (firm_id, 'buying', 600000, 749999.99, 1674.00),
    (firm_id, 'buying', 750000, 999999.99, 1794.00),
    (firm_id, 'buying', 1000000, 2000000.00, 2154.00)
    ON CONFLICT DO NOTHING;
    
    -- Insert same pricing for selling
    INSERT INTO legal_pricing (legal_firm_id, service_type, price_min, price_max, conveyancing_fee) VALUES
    (firm_id, 'selling', 50000, 149999.99, 1134.00),
    (firm_id, 'selling', 150000, 249999.99, 1194.00),
    (firm_id, 'selling', 250000, 349999.99, 1134.00),
    (firm_id, 'selling', 350000, 499999.99, 1434.00),
    (firm_id, 'selling', 500000, 599999.99, 1554.00),
    (firm_id, 'selling', 600000, 749999.99, 1674.00),
    (firm_id, 'selling', 750000, 999999.99, 1794.00),
    (firm_id, 'selling', 1000000, 2000000.00, 2154.00)
    ON CONFLICT DO NOTHING;
  END IF;
END $$;