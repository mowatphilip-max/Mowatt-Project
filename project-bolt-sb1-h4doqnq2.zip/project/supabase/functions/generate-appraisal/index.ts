import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface AppraisalData {
  questionnaire_id: string;
  property_address: string;
  property_postcode: string;
  property_type: string;
  num_bedrooms: number;
  num_bathrooms: number;
  square_feet: number;
  seller_name: string;
  valuation_low: number;
  valuation_mid: number;
  valuation_high: number;
  special_features: string[];
  garden_description: string;
  kitchen_details: string;
  recent_upgrades: any[];
  area_description: string;
  comparable_properties: any[];
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { questionnaire_id } = await req.json();

    if (!questionnaire_id) {
      throw new Error("questionnaire_id is required");
    }

    const { data: questionnaire, error: fetchError } = await supabase
      .from("seller_questionnaires")
      .select("*")
      .eq("id", questionnaire_id)
      .single();

    if (fetchError) throw fetchError;
    if (!questionnaire) throw new Error("Questionnaire not found");

    const reportData = generateReportData(questionnaire);
    const googleSheetUrl = await createGoogleSheet(reportData);
    const pdfContent = generatePDFMarkdown(reportData);

    const reportId = `MOW-${String(Math.floor(Math.random() * 1000)).padStart(3, "0")}`;

    const appraisalDocument = {
      report_id: reportId,
      generated_date: new Date().toISOString(),
      property_address: reportData.property_address,
      property_postcode: reportData.property_postcode,
      property_type: reportData.property_type,
      num_bedrooms: reportData.num_bedrooms,
      num_bathrooms: reportData.num_bathrooms,
      square_feet: reportData.square_feet,
      seller_name: reportData.seller_name,
      valuation_low: reportData.valuation_low,
      valuation_mid: reportData.valuation_mid,
      valuation_high: reportData.valuation_high,
      special_features: reportData.special_features,
      garden_description: reportData.garden_description,
      kitchen_details: reportData.kitchen_details,
      recent_upgrades: reportData.recent_upgrades,
      area_description: reportData.area_description,
      google_sheet_url: googleSheetUrl,
      pdf_markdown: pdfContent
    };

    const { error: updateError } = await supabase
      .from("seller_questionnaires")
      .update({
        report_id: reportId,
        appraisal_document: appraisalDocument,
        appraisal_generated_at: new Date().toISOString(),
        appraisal_status: 'generated'
      })
      .eq("id", questionnaire_id);

    if (updateError) throw updateError;

    return new Response(
      JSON.stringify({
        success: true,
        report_id: reportId,
        message: "Appraisal report generated and stored for admin review",
      }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error: any) {
    console.error("Error generating appraisal:", error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});

function generateReportData(q: any): AppraisalData {
  return {
    questionnaire_id: q.id,
    property_address: q.property_address,
    property_postcode: q.property_postcode,
    property_type: q.property_type,
    num_bedrooms: q.num_bedrooms,
    num_bathrooms: q.num_bathrooms,
    square_feet: q.square_feet,
    seller_name: q.seller_name,
    valuation_low: q.desired_price_min || q.valuation_low,
    valuation_mid: ((q.desired_price_min + q.desired_price_max) / 2) || q.valuation_mid,
    valuation_high: q.desired_price_max || q.valuation_high,
    special_features: q.special_features || [],
    garden_description: q.garden_description,
    kitchen_details: q.kitchen_details,
    recent_upgrades: q.recent_upgrades || [],
    area_description: q.area_description,
    comparable_properties: q.comparable_properties || [],
  };
}

async function createGoogleSheet(data: AppraisalData): Promise<string> {
  const sheetData = [
    ["MOWATT PROPERTY APPRAISAL REPORT"],
    [""],
    ["Report ID", `MOW-${String(Math.floor(Math.random() * 1000)).padStart(3, "0")}`],
    ["Generated Date", new Date().toLocaleDateString()],
    [""],
    ["PROPERTY BASICS"],
    ["Address", data.property_address],
    ["Postcode", data.property_postcode],
    ["Property Type", data.property_type],
    ["Bedrooms", data.num_bedrooms],
    ["Bathrooms", data.num_bathrooms],
    ["Square Feet", data.square_feet],
    [""],
    ["SELLER INFORMATION"],
    ["Seller Name", data.seller_name],
    [""],
    ["VALUATION"],
    ["Low", `£${data.valuation_low?.toLocaleString()}`],
    ["Mid", `£${data.valuation_mid?.toLocaleString()}`],
    ["High", `£${data.valuation_high?.toLocaleString()}`],
    [""],
    ["FEATURES"],
    ["Kitchen", data.kitchen_details],
    ["Garden", data.garden_description],
    ["Special Features", data.special_features?.join(", ")],
    [""],
    ["UPGRADES"],
    ...data.recent_upgrades.map((u: any) => [u.description, u.year]),
    [""],
    ["LOCATION"],
    ["Area Description", data.area_description],
    [""],
    ["NOTES"],
    ["This is an editable Google Sheet. Make changes as needed."],
    ["Export to PDF when complete for client delivery."],
  ];

  const csvContent = sheetData.map(row => row.map(cell => `\"${cell}\"`).join(",")).join("\\n");
  const encodedData = encodeURIComponent(csvContent);
  const googleSheetUrl = `https://docs.google.com/spreadsheets/d/create?usp=sharing&data=${encodedData}`;

  return googleSheetUrl;
}

function generatePDFMarkdown(data: AppraisalData): string {
  return `
# Property Appraisal Report

**Address:** ${data.property_address}, ${data.property_postcode}
**Prepared for:** ${data.seller_name}
**Date:** ${new Date().toLocaleDateString()}
**Report ID:** MOW-${String(Math.floor(Math.random() * 1000)).padStart(3, "0")}

---

## Property Description

${data.property_type} with ${data.num_bedrooms} bedrooms and ${data.num_bathrooms} bathrooms.
Total area: ${data.square_feet} sq ft

### Key Features
${data.special_features?.map(f => `- ${f}`).join("\\n")}

### Kitchen
${data.kitchen_details}

### Outdoor Space
${data.garden_description}

---

## Valuation Range

Taking into account property size, comparable sales data, location, property condition and desirability,
Mowatt appraises a likely achievable sale value within the following range:

**£${data.valuation_low?.toLocaleString()} - £${data.valuation_mid?.toLocaleString()} - £${data.valuation_high?.toLocaleString()}**
(low, med, high)

---

## Recent Upgrades

${data.recent_upgrades?.map((u: any) => `- ${u.description} (${u.year})`).join("\\n")}

---

## Location & Amenities

${data.area_description}

---

## Next Steps

This home will appeal to families relocating within East Lothian, as well as to those moving from Edinburgh
for more space and coastal living. Its features and location ensure it stands out in today's market.

---

*Generated by Mowatt - Move Smarter*
*01620 491 192 | office@mowatt.uk | www.mowatt.uk*
`;
}
