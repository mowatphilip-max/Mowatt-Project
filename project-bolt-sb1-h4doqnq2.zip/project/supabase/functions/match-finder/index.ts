import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface Property {
  id: string;
  title: string;
  property_type: string;
  bedrooms: number;
  bathrooms: number;
  price_min: number;
  price_max: number;
  area_name: string;
  exact_address: string;
  description: string;
  key_features: string[];
}

interface Buyer {
  id: string;
  seeker_name: string;
  looking_for: string;
  bedrooms_min: number | null;
  bedrooms_max: number | null;
  budget_min: number;
  budget_max: number;
  area_preferences: string[];
  street_preferences: string[];
  requirements: string | null;
  buyer_position: string | null;
}

interface Match {
  property_id: string;
  buyer_id: string;
  match_score: number;
  match_reasons: string[];
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch all active properties
    const { data: properties, error: propError } = await supabase
      .from('properties')
      .select('*')
      .eq('status', 'active');

    if (propError) throw propError;

    // Fetch all active buyers
    const { data: buyers, error: buyerError } = await supabase
      .from('buyers')
      .select('*')
      .eq('status', 'active');

    if (buyerError) throw buyerError;

    const matches: Match[] = [];

    // Find matches
    for (const property of properties as Property[]) {
      for (const buyer of buyers as Buyer[]) {
        const matchResult = calculateMatch(property, buyer);
        if (matchResult.score >= 50) {
          matches.push({
            property_id: property.id,
            buyer_id: buyer.id,
            match_score: matchResult.score,
            match_reasons: matchResult.reasons,
          });
        }
      }
    }

    // Insert matches (ignore duplicates)
    if (matches.length > 0) {
      const { error: insertError } = await supabase
        .from('matches')
        .upsert(
          matches.map(m => ({
            property_id: m.property_id,
            buyer_id: m.buyer_id,
            match_score: m.match_score,
            match_reasons: m.match_reasons,
            notification_sent: false,
            status: 'new',
          })),
          { onConflict: 'property_id,buyer_id', ignoreDuplicates: true }
        );

      if (insertError) throw insertError;
    }

    // Fetch unsent matches with property and buyer details
    const { data: unsentMatches, error: matchError } = await supabase
      .from('matches')
      .select(`
        *,
        properties (*),
        buyers (*)
      `)
      .eq('notification_sent', false);

    if (matchError) throw matchError;

    // Send email notifications for each match
    const notificationResults = [];
    for (const match of unsentMatches || []) {
      try {
        await sendMatchEmail(match);
        
        // Mark notification as sent
        await supabase
          .from('matches')
          .update({
            notification_sent: true,
            notification_sent_at: new Date().toISOString(),
          })
          .eq('id', match.id);

        notificationResults.push({
          match_id: match.id,
          status: 'sent',
        });
      } catch (emailError) {
        notificationResults.push({
          match_id: match.id,
          status: 'failed',
          error: emailError.message,
        });
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        matches_found: matches.length,
        notifications_sent: notificationResults.filter(r => r.status === 'sent').length,
        notifications_failed: notificationResults.filter(r => r.status === 'failed').length,
        details: notificationResults,
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

function calculateMatch(property: Property, buyer: Buyer): { score: number; reasons: string[] } {
  let score = 0;
  const reasons: string[] = [];

  // Area match (30 points)
  if (buyer.area_preferences.includes(property.area_name)) {
    score += 30;
    reasons.push(`Located in desired area: ${property.area_name}`);
  }

  // Street match (40 points - high priority)
  if (buyer.street_preferences && buyer.street_preferences.length > 0) {
    const propertyStreet = property.exact_address.split(',')[0].trim().toLowerCase();
    const matchingStreet = buyer.street_preferences.find(
      street => propertyStreet.includes(street.toLowerCase())
    );
    if (matchingStreet) {
      score += 40;
      reasons.push(`Located on preferred street: ${matchingStreet}`);
    }
  }

  // Budget match (25 points)
  const priceOverlap = (
    Math.min(property.price_max, buyer.budget_max) - 
    Math.max(property.price_min, buyer.budget_min)
  );
  if (priceOverlap > 0) {
    score += 25;
    reasons.push(`Price within budget range`);
  }

  // Bedroom match (20 points)
  if (buyer.bedrooms_min && buyer.bedrooms_max) {
    if (property.bedrooms >= buyer.bedrooms_min && property.bedrooms <= buyer.bedrooms_max) {
      score += 20;
      reasons.push(`${property.bedrooms} bedrooms matches requirement`);
    }
  } else {
    // Flexible bedroom requirement
    score += 10;
    reasons.push(`Flexible bedroom requirement`);
  }

  // Property type match (15 points)
  if (buyer.looking_for.toLowerCase().includes(property.property_type.toLowerCase()) ||
      property.property_type.toLowerCase().includes(buyer.looking_for.toLowerCase())) {
    score += 15;
    reasons.push(`Property type matches: ${property.property_type}`);
  }

  return { score, reasons };
}

async function sendMatchEmail(match: any): Promise<void> {
  // In production, integrate with an email service like Resend, SendGrid, or AWS SES
  // For now, we'll log the email that would be sent
  
  const emailContent = {
    to: 'mowatts@example.com', // Replace with actual Mowatts email
    subject: `New Property Match: ${match.buyers.seeker_name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #1e293b;">New Property Match Found!</h2>
        
        <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #334155; margin-top: 0;">Buyer Information</h3>
          <p><strong>Name:</strong> ${match.buyers.seeker_name}</p>
          <p><strong>Looking for:</strong> ${match.buyers.looking_for}</p>
          <p><strong>Budget:</strong> £${match.buyers.budget_min.toLocaleString()} - £${match.buyers.budget_max.toLocaleString()}</p>
          <p><strong>Preferred Areas:</strong> ${match.buyers.area_preferences.join(', ')}</p>
          ${match.buyers.street_preferences?.length > 0 ? `<p><strong>Preferred Streets:</strong> ${match.buyers.street_preferences.join(', ')}</p>` : ''}
          ${match.buyers.buyer_position ? `<p><strong>Position:</strong> ${match.buyers.buyer_position}</p>` : ''}
        </div>

        <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #334155; margin-top: 0;">Matched Property</h3>
          <p><strong>Title:</strong> ${match.properties.title}</p>
          <p><strong>Type:</strong> ${match.properties.property_type}</p>
          <p><strong>Location:</strong> ${match.properties.area_name}, East Lothian</p>
          <p><strong>Bedrooms:</strong> ${match.properties.bedrooms}</p>
          <p><strong>Price Range:</strong> £${match.properties.price_min.toLocaleString()} - £${match.properties.price_max.toLocaleString()}</p>
        </div>

        <div style="background: #ecfdf5; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #334155; margin-top: 0;">Match Details</h3>
          <p><strong>Match Score:</strong> ${match.match_score}%</p>
          <p><strong>Reasons:</strong></p>
          <ul>
            ${match.match_reasons.map((reason: string) => `<li>${reason}</li>`).join('')}
          </ul>
        </div>

        <p style="color: #64748b; font-size: 14px; margin-top: 30px;">
          This is an automated notification from Mowatts Matchlist.<br>
          Please follow up with the buyer to arrange a viewing.
        </p>
      </div>
    `,
  };

  // Log the email (in production, replace this with actual email sending)
  console.log('Email to be sent:', JSON.stringify(emailContent, null, 2));
  
  // Example integration with Resend (uncomment when ready):
  /*
  const resendApiKey = Deno.env.get('RESEND_API_KEY');
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${resendApiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: 'Mowatts Matchlist <notifications@mowatts.com>',
      ...emailContent,
    }),
  });
  
  if (!response.ok) {
    throw new Error('Failed to send email');
  }
  */
}
