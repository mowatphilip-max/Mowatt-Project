import { useState, useEffect } from 'react';
import { Home, Users, Map, Search, UserPlus, LogIn, User as UserIcon, TrendingUp, Heart } from 'lucide-react';
import { supabase } from './lib/supabase';
import { PropertyCard } from './components/PropertyCard';
import { BuyerCard } from './components/BuyerCard';
import { RegistrationModal } from './components/RegistrationModal';
import { BuyerQuestionnaire, type BuyerQuestionnaireData } from './components/BuyerQuestionnaire';
import { AuthModal } from './components/auth/AuthModal';
import { SignupForm } from './components/auth/SignupForm';
import { ViewingRequestModal } from './components/ViewingRequestModal';
import type { Property, Buyer } from './lib/supabase';
import { useAdmin } from './contexts/AdminContext';
import { useAuth } from './contexts/AuthContext';
import { AdminLogin } from './pages/AdminLogin';
import { AdminDashboard } from './pages/AdminDashboard';
import { UserProfile } from './pages/UserProfile';
import SellerQuestionnaire from './pages/SellerQuestionnaire';
import LegalServices from './pages/LegalServices';
import { LegalFirmLogin } from './pages/LegalFirmLogin';
import { LegalFirmDashboard } from './pages/LegalFirmDashboard';
import { useLegalFirm } from './contexts/LegalFirmContext';

export function AppRouter() {
  const { user: adminUser, admin, loading: adminLoading } = useAdmin();
  const { user: authUser, profile } = useAuth();
  const { user: legalUser, firm, loading: legalLoading } = useLegalFirm();
  const isAdminRoute = window.location.pathname.startsWith('/admin');
  const isProfileRoute = window.location.pathname.startsWith('/profile');
  const isSellerQuestionnaireRoute = window.location.pathname.startsWith('/sell');
  const isBuyerQuestionnaireRoute = window.location.pathname.startsWith('/buyer-questionnaire');
  const isLegalServicesRoute = window.location.pathname.startsWith('/legal-services');
  const isLegalFirmRoute = window.location.pathname.startsWith('/legal-firm');

  const [properties, setProperties] = useState<Property[]>([]);
  const [buyers, setBuyers] = useState<Buyer[]>([]);
  const [activeTab, setActiveTab] = useState<'properties' | 'buyers'>('properties');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Property | Buyer | null>(null);
  const [modalType, setModalType] = useState<'property' | 'buyer'>('property');
  const [searchTerm, setSearchTerm] = useState('');
  const [isQuestionnaireOpen, setIsQuestionnaireOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'signin' | 'signup'>('signin');
  const [isSignupFormOpen, setIsSignupFormOpen] = useState(false);
  const [selectedPropertyForViewing, setSelectedPropertyForViewing] = useState<Property | null>(null);

  useEffect(() => {
    if (!isAdminRoute) {
      fetchProperties();
      fetchBuyers();
    }
  }, [isAdminRoute]);

  const fetchProperties = async () => {
    const { data, error } = await supabase
      .from('properties')
      .select('*')
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching properties:', error);
    } else {
      setProperties(data || []);
    }
  };

  const fetchBuyers = async () => {
    const { data, error } = await supabase
      .from('buyers')
      .select('*')
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching buyers:', error);
    } else {
      setBuyers(data || []);
    }
  };

  const handlePropertyInterest = (property: Property) => {
    setSelectedItem(property);
    setModalType('property');
    setIsModalOpen(true);
  };

  const handleBuyerInterest = (buyer: Buyer) => {
    setSelectedItem(buyer);
    setModalType('buyer');
    setIsModalOpen(true);
  };

  const filteredProperties = properties.filter((property) =>
    property.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    property.area_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    property.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredBuyers = buyers.filter((buyer) =>
    buyer.seeker_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    buyer.looking_for.toLowerCase().includes(searchTerm.toLowerCase()) ||
    buyer.area_preferences.some(area => area.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleQuestionnaireSubmit = async (data: BuyerQuestionnaireData) => {
    console.log('Submitting questionnaire data:', data);

    const flattenedStreetPreferences = Object.values(data.street_preferences).flat();
    const buyerStatus = data.list_in_quiet_seekers ? 'pending_approval' : 'unlisted';
    const lookingFor = data.property_type.length > 0
      ? data.property_type.join(', ')
      : 'Any property type';

    const buyerData = {
      seeker_name: data.seeker_name,
      email: data.email,
      phone: data.phone,
      looking_for: lookingFor,
      bedrooms_min: data.bedrooms_min,
      bedrooms_max: data.bedrooms_max,
      bathrooms_min: data.bathrooms_min,
      budget_min: data.budget_min,
      budget_max: data.budget_max,
      area_preferences: data.area_preferences,
      street_preferences: flattenedStreetPreferences,
      property_type_preferences: data.property_type,
      must_haves: data.must_haves,
      outdoor_space: data.outdoor_space,
      parking: data.parking,
      property_condition: data.property_condition,
      timeline: data.timeline,
      buyer_position: data.buyer_position,
      requirements: data.additional_requirements,
      status: buyerStatus,
      location_circles: data.location_circles || [],
      latitude: null,
      longitude: null,
      approximate_lat: null,
      approximate_lng: null,
      user_id: authUser?.id || null,
    };

    console.log('Inserting buyer data:', buyerData);

    const { data: insertedData, error } = await supabase.from('buyers').insert(buyerData).select();

    if (error) {
      console.error('Error submitting questionnaire:', error);
      alert(`There was an error submitting your questionnaire: ${error.message}\n\nPlease try again or contact support.`);
    } else {
      console.log('Successfully inserted buyer:', insertedData);

      if (authUser) {
        const { error: profileError } = await supabase
          .from('user_profiles')
          .upsert({
            user_id: authUser.id,
            is_buyer: true,
            buyer_commission_agreed: data.commission_agreed,
            buyer_commission_date: data.commission_agreed ? new Date().toISOString() : null,
            email: data.email,
            phone: data.phone,
            full_name: data.seeker_name,
            price_min: data.budget_min,
            price_max: data.budget_max,
            bedrooms_min: data.bedrooms_min,
            property_type_preferences: data.property_type,
            preferred_areas: data.area_preferences,
            must_haves: data.must_haves,
            outdoor_space: data.outdoor_space,
            parking: data.parking,
            property_condition: data.property_condition,
            timeline: data.timeline,
            updated_at: new Date().toISOString(),
          }, {
            onConflict: 'user_id'
          });

        if (profileError) console.error('Error updating profile:', profileError);
      }

      const message = data.list_in_quiet_seekers
        ? 'Thank you! Your preferences have been saved. Your anonymous listing is pending approval and will appear in Quiet Seekers once reviewed by our team. We\'ll be in touch soon with matching properties.'
        : 'Thank you! Your preferences have been saved. We\'ll be in touch privately with matching properties.';
      alert(message);
      setIsQuestionnaireOpen(false);
      fetchBuyers();

      if (isBuyerQuestionnaireRoute) {
        window.location.pathname = '/profile';
      }
    }
  };

  if (adminLoading || legalLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-slate-600">Loading...</div>
      </div>
    );
  }

  if (isLegalFirmRoute) {
    if (window.location.pathname === '/legal-firm/login') {
      if (legalUser && firm) {
        window.location.pathname = '/legal-firm/dashboard';
        return null;
      }
      return <LegalFirmLogin />;
    }

    if (window.location.pathname === '/legal-firm/dashboard') {
      if (!legalUser || !firm) {
        window.location.pathname = '/legal-firm/login';
        return null;
      }
      return <LegalFirmDashboard />;
    }

    window.location.pathname = '/legal-firm/login';
    return null;
  }

  if (isAdminRoute) {
    if (!adminUser || !admin) {
      return <AdminLogin />;
    }
    return <AdminDashboard />;
  }

  if (isProfileRoute) {
    if (!authUser) {
      window.location.pathname = '/';
      return null;
    }
    return <UserProfile />;
  }

  if (isSellerQuestionnaireRoute) {
    if (!authUser) {
      alert('Please sign in to create a property listing');
      window.location.pathname = '/';
      return null;
    }
    return <SellerQuestionnaire />;
  }

  if (isBuyerQuestionnaireRoute) {
    if (!authUser) {
      alert('Please sign in to register as a buyer');
      window.location.pathname = '/';
      return null;
    }
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-12">
        <div className="max-w-5xl mx-auto">
          <BuyerQuestionnaire
            isOpen={true}
            onClose={() => window.location.pathname = '/profile'}
            onSubmit={handleQuestionnaireSubmit}
          />
        </div>
      </div>
    );
  }

  if (isLegalServicesRoute) {
    if (!authUser) {
      alert('Please sign in to access legal services');
      window.location.pathname = '/';
      return null;
    }
    return <LegalServices />;
  }

  return (
    <div className="min-h-screen bg-mowatt-cream">
      <header className="bg-white shadow-sm sticky top-0 z-50 border-b border-mowatt-sand">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-8">
              <img
                src="/Landscape Mowatt Logo copy.jpg"
                alt="Mowatt"
                className="h-12 object-contain"
              />
              <div className="hidden md:flex items-center gap-1">
                <h1 className="text-xl font-serif font-medium text-mowatt-blue">Matchlist</h1>
                <span className="text-mowatt-charcoal/70 text-sm ml-2">— Discreet property matchmaking</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {authUser && profile ? (
                <button
                  onClick={() => window.location.pathname = '/profile'}
                  className="flex items-center gap-2 text-mowatt-charcoal hover:text-mowatt-orange transition-colors font-medium text-sm"
                >
                  <UserIcon className="w-4 h-4" />
                  {profile.full_name || 'Profile'}
                </button>
              ) : (
                <>
                  <button
                    onClick={() => {
                      setAuthModalMode('signin');
                      setIsAuthModalOpen(true);
                    }}
                    className="text-mowatt-charcoal hover:text-mowatt-orange transition-colors font-medium text-sm"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => setIsSignupFormOpen(true)}
                    className="bg-mowatt-orange hover:bg-mowatt-orange-dark text-white px-5 py-2 rounded-md font-medium text-sm transition-all"
                  >
                    Get Started
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <section className="relative bg-gradient-to-br from-mowatt-blue via-mowatt-blue-light to-mowatt-blue-dark py-24 md:py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{backgroundImage: 'url(/Landscape Gullane Newbuilds Drone.jpg)', backgroundSize: 'cover', backgroundPosition: 'center'}}></div>
        </div>
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-serif font-medium text-white mb-6 leading-tight">
            Connecting Quiet Seekers<br />with Hush Homes
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-10 max-w-3xl mx-auto font-light">
            Discreet property matchmaking for homeowners and buyers who move smarter
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => window.location.pathname = '/sell'}
              className="group bg-white hover:bg-mowatt-cream text-mowatt-charcoal px-8 py-4 rounded-md font-medium text-base transition-all inline-flex items-center justify-center gap-2"
            >
              <Home className="w-5 h-5 text-mowatt-orange" />
              List Your Home
            </button>
            <button
              onClick={() => setIsQuestionnaireOpen(true)}
              className="group bg-mowatt-orange hover:bg-mowatt-orange-dark text-white px-8 py-4 rounded-md font-medium text-base transition-all inline-flex items-center justify-center gap-2"
            >
              <Search className="w-5 h-5" />
              Quiet Seeker Registration
            </button>
          </div>
        </div>
      </section>

      <section className="bg-white py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-medium text-mowatt-blue mb-4">
              A Smarter Way to Move
            </h2>
            <div className="w-16 h-0.5 bg-mowatt-orange mx-auto mb-6"></div>
            <p className="text-lg text-mowatt-charcoal/70 max-w-2xl mx-auto">
              Mowatt Matchlist brings together off-market properties with serious buyers through a discreet, locally-focused platform
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-mowatt-orange/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-mowatt-orange" />
              </div>
              <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-3">Local & Trusted</h3>
              <p className="text-mowatt-charcoal/70">
                East Lothian specialists connecting buyers and sellers who value discretion
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-mowatt-orange/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-mowatt-orange" />
              </div>
              <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-3">Off-Market Access</h3>
              <p className="text-mowatt-charcoal/70">
                Exclusive properties not listed elsewhere, matched directly with serious buyers
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-mowatt-orange/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-mowatt-orange" />
              </div>
              <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-3">Only 1% Fee</h3>
              <p className="text-mowatt-charcoal/70">
                No sale, no fee. We only charge 1% on successful matches
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-mowatt-sand py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-medium text-mowatt-blue mb-4">
              How It Works
            </h2>
            <div className="w-16 h-0.5 bg-mowatt-orange mx-auto"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg">
              <div className="text-4xl font-serif text-mowatt-orange mb-4">01</div>
              <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-3">Share Your Goals</h3>
              <p className="text-mowatt-charcoal/70">
                Tell us what you're looking for or what you're selling through our simple questionnaire
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg">
              <div className="text-4xl font-serif text-mowatt-orange mb-4">02</div>
              <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-3">We Match Privately</h3>
              <p className="text-mowatt-charcoal/70">
                Our platform connects Hush Homes with Quiet Seekers behind the scenes
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg">
              <div className="text-4xl font-serif text-mowatt-orange mb-4">03</div>
              <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-3">Move Smarter</h3>
              <p className="text-mowatt-charcoal/70">
                Complete your transaction with local expertise and transparent 1% commission
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="text-3xl font-serif font-medium text-mowatt-blue mb-2">Browse Current Opportunities</h2>
            <p className="text-mowatt-charcoal/70">Explore off-market homes and active buyers</p>
          </div>
          <div className="relative hidden md:block">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-mowatt-charcoal/30 w-5 h-5" />
            <input
              type="text"
              placeholder="Search locations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-11 pr-4 py-2.5 border border-mowatt-sand rounded-md focus:ring-2 focus:ring-mowatt-orange focus:border-mowatt-orange transition-all bg-white text-mowatt-charcoal"
            />
          </div>
        </div>

        <div className="flex gap-3 mb-8 border-b border-mowatt-sand pb-4">
          <button
            onClick={() => setActiveTab('properties')}
            className={`px-6 py-3 rounded-md font-medium transition-all ${
              activeTab === 'properties'
                ? 'bg-mowatt-orange text-white'
                : 'text-mowatt-charcoal hover:text-mowatt-orange'
            }`}
          >
            Hush Homes ({properties.length})
          </button>
          <button
            onClick={() => setActiveTab('buyers')}
            className={`px-6 py-3 rounded-md font-medium transition-all ${
              activeTab === 'buyers'
                ? 'bg-mowatt-orange text-white'
                : 'text-mowatt-charcoal hover:text-mowatt-orange'
            }`}
          >
            Quiet Seekers ({buyers.length})
          </button>
        </div>

        {activeTab === 'properties' ? (
          <div>
            {filteredProperties.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProperties.map((property) => (
                  <PropertyCard
                    key={property.id}
                    property={property}
                    onRegisterInterest={handlePropertyInterest}
                    onRequestViewing={authUser ? setSelectedPropertyForViewing : undefined}
                  />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg p-16 text-center border border-mowatt-sand">
                <Home className="w-16 h-16 text-mowatt-charcoal/20 mx-auto mb-4" />
                <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-2">No properties found</h3>
                <p className="text-mowatt-charcoal/70">Try adjusting your search or check back soon</p>
              </div>
            )}
          </div>
        ) : (
          <div>
            {filteredBuyers.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredBuyers.map((buyer) => (
                  <BuyerCard
                    key={buyer.id}
                    buyer={buyer}
                    onRegisterInterest={handleBuyerInterest}
                  />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg p-16 text-center border border-mowatt-sand">
                <Users className="w-16 h-16 text-mowatt-charcoal/20 mx-auto mb-4" />
                <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-2">No seekers found</h3>
                <p className="text-mowatt-charcoal/70">Try adjusting your search or check back soon</p>
              </div>
            )}
          </div>
        )}
      </div>

      <RegistrationModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        item={selectedItem}
        type={modalType}
      />

      <BuyerQuestionnaire
        isOpen={isQuestionnaireOpen}
        onClose={() => setIsQuestionnaireOpen(false)}
        onSubmit={handleQuestionnaireSubmit}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        defaultMode={authModalMode}
      />

      <SignupForm
        isOpen={isSignupFormOpen}
        onClose={() => setIsSignupFormOpen(false)}
      />

      {selectedPropertyForViewing && (
        <ViewingRequestModal
          isOpen={!!selectedPropertyForViewing}
          onClose={() => setSelectedPropertyForViewing(null)}
          property={selectedPropertyForViewing}
        />
      )}

      <footer className="bg-mowatt-charcoal mt-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="md:col-span-2">
              <img
                src="/Landscape Mowatt Logo copy.jpg"
                alt="Mowatt"
                className="h-10 object-contain mb-4 brightness-0 invert opacity-90"
              />
              <p className="text-white/70 text-sm leading-relaxed max-w-md">
                Mowatt Matchlist connects off-market properties with serious buyers through discreet, local expertise. Move smarter with East Lothian's trusted property matchmakers.
              </p>
            </div>
            <div>
              <h4 className="font-serif font-medium text-white mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-white/70 hover:text-mowatt-orange transition-colors">About</a></li>
                <li><a href="#" className="text-white/70 hover:text-mowatt-orange transition-colors">How It Works</a></li>
                <li><a href="/sell" className="text-white/70 hover:text-mowatt-orange transition-colors">List Your Home</a></li>
                <li><a href="#" onClick={(e) => { e.preventDefault(); setIsQuestionnaireOpen(true); }} className="text-white/70 hover:text-mowatt-orange transition-colors">Quiet Seeker Registration</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-serif font-medium text-white mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li>East Lothian</li>
                <li>Scotland</li>
                <li className="pt-2">
                  <a href="https://mowatt.uk" target="_blank" rel="noopener noreferrer" className="hover:text-mowatt-orange transition-colors">
                    mowatt.uk
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-white/50 text-sm">
              © {new Date().getFullYear()} Mowatt. All rights reserved.
            </p>
            <p className="text-white/70 text-sm font-medium">
              Move Smarter
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
