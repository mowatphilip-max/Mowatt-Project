import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

interface LegalFirm {
  id: string;
  user_id: string;
  firm_name: string;
  contact_name: string;
  email: string;
  phone: string;
  address: string;
  registration_number: string;
  is_active: boolean;
  is_verified: boolean;
  services_offered: string[];
  created_at: string;
  updated_at: string;
}

interface LegalFirmContextType {
  user: User | null;
  firm: LegalFirm | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
}

const LegalFirmContext = createContext<LegalFirmContextType | undefined>(undefined);

export function LegalFirmProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [firm, setFirm] = useState<LegalFirm | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUser();

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      (async () => {
        if (session?.user) {
          setUser(session.user);
          await fetchFirm(session.user.id);
        } else {
          setUser(null);
          setFirm(null);
        }
      })();
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  const checkUser = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user || null);

      if (session?.user) {
        await fetchFirm(session.user.id);
      }
    } catch (error) {
      console.error('Error checking user:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchFirm = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('legal_firms')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) throw error;
      setFirm(data);
    } catch (error) {
      console.error('Error fetching firm:', error);
      setFirm(null);
    }
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { error };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setFirm(null);
  };

  return (
    <LegalFirmContext.Provider value={{ user, firm, loading, signIn, signOut }}>
      {children}
    </LegalFirmContext.Provider>
  );
}

export function useLegalFirm() {
  const context = useContext(LegalFirmContext);
  if (context === undefined) {
    throw new Error('useLegalFirm must be used within a LegalFirmProvider');
  }
  return context;
}
