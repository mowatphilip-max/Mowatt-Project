import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Property = {
  id: string;
  title: string;
  property_type: string;
  bedrooms: number;
  bathrooms: number;
  price_min: number;
  price_max: number;
  area_name: string;
  exact_address: string;
  latitude: number;
  longitude: number;
  approximate_lat: number;
  approximate_lng: number;
  description: string;
  key_features: string[];
  square_feet: number | null;
  image_url: string;
  status: string;
  created_at: string;
  updated_at: string;
};

export type Buyer = {
  id: string;
  seeker_name: string;
  looking_for: string;
  bedrooms_min: number | null;
  bedrooms_max: number | null;
  budget_min: number;
  budget_max: number;
  area_preferences: string[];
  street_preferences: string[];
  latitude: number | null;
  longitude: number | null;
  approximate_lat: number | null;
  approximate_lng: number | null;
  requirements: string | null;
  buyer_position: string | null;
  status: string;
  created_at: string;
  updated_at: string;
};
