import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { LegalServicesSelector } from '../components/LegalServicesSelector';
import { Scale, CheckCircle, Clock, X, ArrowLeft } from 'lucide-react';

interface LegalServiceRequest {
  id: string;
  legal_firm_id: string;
  service_type: 'buying' | 'selling';
  property_value: number;
  conveyancing_fee: number;
  deposit_amount: number;
  deposit_paid: boolean;
  status: string;
  property_address: string | null;
  created_at: string;
  legal_firm: {
    firm_name: string;
    contact_name: string;
    email: string;
    phone: string;
  };
}

export default function LegalServices() {
  const { user, profile } = useAuth();
  const [requests, setRequests] = useState<LegalServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [showBuyingSelector, setShowBuyingSelector] = useState(false);
  const [showSellingSelector, setShowSellingSelector] = useState(false);
  const [selectedBuyingFirm, setSelectedBuyingFirm] = useState('');
  const [selectedBuyingQuote, setSelectedBuyingQuote] = useState<any>(null);
  const [selectedSellingFirm, setSelectedSellingFirm] = useState('');
  const [selectedSellingQuote, setSelectedSellingQuote] = useState<any>(null);

  useEffect(() => {
    if (user) {
      fetchRequests();
    }
  }, [user]);

  const fetchRequests = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('legal_service_requests')
        .select(`
          *,
          legal_firm:legal_firms(firm_name, contact_name, email, phone)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRequests(data || []);
    } catch (error) {
      console.error('Error fetching legal service requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveBuyingService = async () => {
    if (!user || !selectedBuyingFirm || !selectedBuyingQuote) return;

    try {
      const { error } = await supabase
        .from('legal_service_requests')
        .insert({
          user_id: user.id,
          legal_firm_id: selectedBuyingFirm,
          service_type: 'buying',
          property_value: selectedBuyingQuote.price_max || 0,
          conveyancing_fee: selectedBuyingQuote.conveyancing_fee,
          deposit_amount: selectedBuyingQuote.total_deposit_required,
          status: 'pending'
        });

      if (error) throw error;

      await supabase
        .from('user_profiles')
        .update({ has_legal_service_buyer: true, legal_firm_id_buyer: selectedBuyingFirm })
        .eq('user_id', user.id);

      alert('Legal service request created! You will receive payment instructions via email.');
      setShowBuyingSelector(false);
      fetchRequests();
    } catch (error: any) {
      alert('Error saving legal service: ' + error.message);
    }
  };

  const handleSaveSellingService = async () => {
    if (!user || !selectedSellingFirm || !selectedSellingQuote) return;

    try {
      const { error } = await supabase
        .from('legal_service_requests')
        .insert({
          user_id: user.id,
          legal_firm_id: selectedSellingFirm,
          service_type: 'selling',
          property_value: selectedSellingQuote.price_max || 0,
          conveyancing_fee: selectedSellingQuote.conveyancing_fee,
          deposit_amount: selectedSellingQuote.total_deposit_required,
          status: 'pending'
        });

      if (error) throw error;

      await supabase
        .from('user_profiles')
        .update({ has_legal_service_seller: true, legal_firm_id_seller: selectedSellingFirm })
        .eq('user_id', user.id);

      alert('Legal service request created! You will receive payment instructions via email.');
      setShowSellingSelector(false);
      fetchRequests();
    } catch (error: any) {
      alert('Error saving legal service: ' + error.message);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'deposit_paid':
        return 'bg-blue-100 text-blue-800';
      case 'in_progress':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-slate-100 text-slate-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-orange-100 text-orange-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-slate-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-mowatt-cream">
      <header className="bg-white shadow-md border-b-4 border-mowatt-orange">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <img
                src="/Landscape Mowatt Logo copy.jpg"
                alt="Mowatt"
                className="h-14 object-contain"
              />
              <div>
                <h1 className="text-2xl font-serif font-bold text-mowatt-blue">Legal Services</h1>
                <p className="text-mowatt-charcoal text-sm">Manage your conveyancing services</p>
              </div>
            </div>
            <button
              onClick={() => window.location.pathname = '/profile'}
              className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-mowatt-sand text-mowatt-blue border-2 border-mowatt-blue rounded-lg transition-all font-semibold"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Profile
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md border-2 border-mowatt-sand p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-mowatt-blue flex items-center gap-2">
                  <Scale className="w-6 h-6" />
                  Buying Services
                </h3>
                <p className="text-sm text-slate-600 mt-1">Conveyancing for property purchase</p>
              </div>
              {profile?.has_legal_service_buyer ? (
                <CheckCircle className="w-8 h-8 text-green-600" />
              ) : (
                <Clock className="w-8 h-8 text-slate-400" />
              )}
            </div>
            {!showBuyingSelector && !profile?.has_legal_service_buyer && (
              <button
                onClick={() => setShowBuyingSelector(true)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-all shadow-md"
              >
                Add Buying Legal Services
              </button>
            )}
          </div>

          <div className="bg-white rounded-xl shadow-md border-2 border-mowatt-sand p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-mowatt-blue flex items-center gap-2">
                  <Scale className="w-6 h-6" />
                  Selling Services
                </h3>
                <p className="text-sm text-slate-600 mt-1">Conveyancing for property sale</p>
              </div>
              {profile?.has_legal_service_seller ? (
                <CheckCircle className="w-8 h-8 text-green-600" />
              ) : (
                <Clock className="w-8 h-8 text-slate-400" />
              )}
            </div>
            {!showSellingSelector && !profile?.has_legal_service_seller && (
              <button
                onClick={() => setShowSellingSelector(true)}
                className="w-full bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-all shadow-md"
              >
                Add Selling Legal Services
              </button>
            )}
          </div>
        </div>

        {showBuyingSelector && (
          <div className="bg-white rounded-xl shadow-lg border-2 border-blue-200 p-6 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Add Buying Legal Services</h2>
              <button
                onClick={() => setShowBuyingSelector(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <LegalServicesSelector
              serviceType="buying"
              onSelect={(firmId, quote) => {
                setSelectedBuyingFirm(firmId);
                setSelectedBuyingQuote(quote);
              }}
              selectedFirmId={selectedBuyingFirm}
            />
            {selectedBuyingFirm && selectedBuyingQuote && (
              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleSaveBuyingService}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-all shadow-md"
                >
                  Request Legal Services
                </button>
              </div>
            )}
          </div>
        )}

        {showSellingSelector && (
          <div className="bg-white rounded-xl shadow-lg border-2 border-green-200 p-6 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-slate-900">Add Selling Legal Services</h2>
              <button
                onClick={() => setShowSellingSelector(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <LegalServicesSelector
              serviceType="selling"
              onSelect={(firmId, quote) => {
                setSelectedSellingFirm(firmId);
                setSelectedSellingQuote(quote);
              }}
              selectedFirmId={selectedSellingFirm}
            />
            {selectedSellingFirm && selectedSellingQuote && (
              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleSaveSellingService}
                  className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg font-semibold transition-all shadow-md"
                >
                  Request Legal Services
                </button>
              </div>
            )}
          </div>
        )}

        {requests.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Your Legal Service Requests</h2>
            <div className="space-y-4">
              {requests.map((request) => (
                <div
                  key={request.id}
                  className="bg-white rounded-xl shadow-md border-2 border-mowatt-sand p-6"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900">
                        {request.legal_firm.firm_name}
                      </h3>
                      <p className="text-sm text-slate-600">
                        {request.service_type === 'buying' ? 'Purchase' : 'Sale'} Conveyancing
                      </p>
                    </div>
                    <span className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize ${getStatusColor(request.status)}`}>
                      {request.status.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-xs text-slate-600 mb-1">Property Value</p>
                      <p className="text-lg font-bold text-slate-900">
                        £{request.property_value.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-600 mb-1">Conveyancing Fee</p>
                      <p className="text-lg font-bold text-slate-900">
                        £{request.conveyancing_fee.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-600 mb-1">Deposit Amount</p>
                      <p className="text-lg font-bold text-blue-600">
                        £{request.deposit_amount.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-600 mb-1">Deposit Status</p>
                      <p className={`text-sm font-semibold ${request.deposit_paid ? 'text-green-600' : 'text-orange-600'}`}>
                        {request.deposit_paid ? 'Paid' : 'Pending'}
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-xs text-slate-600 mb-2">Contact</p>
                    <p className="text-sm font-semibold text-slate-900">{request.legal_firm.contact_name}</p>
                    <p className="text-sm text-slate-600">{request.legal_firm.email}</p>
                    {request.legal_firm.phone && (
                      <p className="text-sm text-slate-600">{request.legal_firm.phone}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {requests.length === 0 && !showBuyingSelector && !showSellingSelector && (
          <div className="bg-white rounded-xl shadow-md border-2 border-slate-200 p-12 text-center">
            <Scale className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-slate-700 mb-2">No Legal Services Yet</h3>
            <p className="text-slate-500">
              Add legal services to help with your property transactions
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
