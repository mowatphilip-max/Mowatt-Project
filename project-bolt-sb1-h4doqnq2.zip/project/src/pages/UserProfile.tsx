import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { PropertyCard } from '../components/PropertyCard';
import { BuyerQuestionnaire, type BuyerQuestionnaireData } from '../components/BuyerQuestionnaire';
import { User, LogOut, Settings, Heart, TrendingUp, Calendar, ClipboardList, Home, ShoppingBag, CheckCircle, Scale } from 'lucide-react';
import type { Property } from '../lib/supabase';

interface PropertyMatch {
  id: string;
  property_id: string;
  match_score: number;
  score_breakdown: any;
  property: Property;
}

interface ViewingRequest {
  id: string;
  property_id: string;
  status: string;
  preferred_date: string | null;
  scheduled_viewing_time: string | null;
  created_at: string;
  property: Property;
}

export function UserProfile() {
  const { user, profile, signOut } = useAuth();
  const [matches, setMatches] = useState<PropertyMatch[]>([]);
  const [viewingRequests, setViewingRequests] = useState<ViewingRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [calculatingScores, setCalculatingScores] = useState(false);
  const [showQuestionnaire, setShowQuestionnaire] = useState(false);

  const isQuestionnaireComplete = profile &&
    profile.bedrooms_min &&
    profile.budget_min &&
    profile.budget_max &&
    profile.property_type_preferences &&
    profile.property_type_preferences.length > 0;

  useEffect(() => {
    if (user) {
      fetchMatches();
      fetchViewingRequests();
    }
  }, [user]);

  const fetchMatches = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('property_matches')
      .select(`
        *,
        property:properties(*)
      `)
      .eq('user_id', user.id)
      .order('match_score', { ascending: false });

    if (!error && data) {
      setMatches(data as any);
    }
    setLoading(false);
  };

  const fetchViewingRequests = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('viewing_requests')
      .select(`
        *,
        property:properties(*)
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setViewingRequests(data as any);
    }
  };

  const handleQuestionnaireSubmit = async (data: BuyerQuestionnaireData, legalData?: { firmId: string; quote: any }) => {
    if (!user) return;

    const { error } = await supabase
      .from('user_profiles')
      .update({
        bedrooms_min: data.bedrooms,
        bathrooms_min: data.bathrooms || 1,
        price_min: data.budgetMin,
        price_max: data.budgetMax,
        property_type_preferences: data.propertyTypes,
        preferred_areas: data.preferredAreas,
        must_haves: data.mustHaves || [],
        outdoor_space: data.outdoorSpace || [],
        parking: data.parking || [],
        property_condition: data.propertyCondition || null,
        timeline: data.timeline || null,
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', user.id);

    if (legalData) {
      const { error: legalError } = await supabase
        .from('legal_service_requests')
        .insert({
          user_id: user.id,
          legal_firm_id: legalData.firmId,
          service_type: 'buying',
          property_value: data.budgetMax || data.budgetMin || 0,
          conveyancing_fee: legalData.quote.conveyancing_fee,
          deposit_amount: legalData.quote.total_deposit_required,
          status: 'pending'
        });

      if (legalError) console.error('Error creating legal service request:', legalError);

      await supabase
        .from('user_profiles')
        .update({ has_legal_service_buyer: true, legal_firm_id_buyer: legalData.firmId })
        .eq('user_id', user.id);
    }

    if (!error) {
      setShowQuestionnaire(false);
      window.location.reload();
    } else {
      alert('Error saving preferences. Please try again.');
    }
  };

  const calculateMatchScores = async () => {
    if (!user || !profile) return;

    setCalculatingScores(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/calculate-match-score`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: user.id }),
      });

      if (response.ok) {
        await fetchMatches();
        alert('Match scores calculated successfully!');
      } else {
        const error = await response.json();
        alert(`Error calculating scores: ${error.error}`);
      }
    } catch (error: any) {
      alert(`Error: ${error.message}`);
    } finally {
      setCalculatingScores(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-600 bg-emerald-50';
    if (score >= 60) return 'text-blue-600 bg-blue-50';
    if (score >= 40) return 'text-orange-600 bg-orange-50';
    return 'text-slate-600 bg-slate-50';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent Match';
    if (score >= 60) return 'Good Match';
    if (score >= 40) return 'Fair Match';
    return 'Low Match';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-emerald-100 text-emerald-800';
      case 'pending':
        return 'bg-orange-100 text-orange-800';
      case 'declined':
        return 'bg-red-100 text-red-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'cancelled':
        return 'bg-slate-100 text-slate-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-slate-600">Loading your profile...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-mowatt-cream">
      <header className="bg-white shadow-md border-b-4 border-mowatt-orange">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <img
                src="/Landscape Mowatt Logo copy.jpg"
                alt="Mowatt"
                className="h-14 object-contain"
              />
              <div>
                <h1 className="text-2xl font-serif font-bold text-mowatt-blue">My Profile</h1>
                <p className="text-mowatt-charcoal text-sm">{profile?.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => window.location.pathname = '/'}
                className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-mowatt-sand text-mowatt-blue border-2 border-mowatt-blue rounded-lg transition-all font-semibold"
              >
                Back to Home
              </button>
              <button
                onClick={signOut}
                className="flex items-center gap-2 px-4 py-2 bg-mowatt-orange hover:bg-mowatt-orange-dark text-white rounded-lg transition-all font-semibold shadow-md"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-md border-2 border-mowatt-orange p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xl font-serif font-bold text-mowatt-blue mb-1">Your Account</h3>
              <p className="text-mowatt-charcoal text-sm">{profile?.full_name || 'Guest User'}</p>
            </div>
            <User className="w-10 h-10 text-mowatt-blue" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg p-4 border-2 border-green-200">
              <div className="flex items-center gap-3 mb-2">
                <Home className="w-6 h-6 text-green-600" />
                <div>
                  <h4 className="font-bold text-slate-900">Seller</h4>
                  <p className="text-xs text-slate-600">List properties FREE</p>
                </div>
              </div>
              {profile?.is_seller ? (
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm font-semibold">Active</span>
                </div>
              ) : (
                <button
                  onClick={() => window.location.pathname = '/sell'}
                  className="mt-2 w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-all"
                >
                  List Your Property
                </button>
              )}
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg p-4 border-2 border-blue-200">
              <div className="flex items-center gap-3 mb-2">
                <ShoppingBag className="w-6 h-6 text-blue-600" />
                <div>
                  <h4 className="font-bold text-slate-900">Buyer</h4>
                  <p className="text-xs text-slate-600">1% commission</p>
                </div>
              </div>
              {profile?.is_buyer ? (
                <div className="flex items-center gap-2 text-blue-700">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm font-semibold">Active</span>
                  {profile?.buyer_commission_agreed && (
                    <span className="text-xs bg-blue-100 px-2 py-0.5 rounded">Commission Agreed</span>
                  )}
                </div>
              ) : (
                <button
                  onClick={() => window.location.pathname = '/buyer-questionnaire'}
                  className="mt-2 w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-all"
                >
                  Register as Buyer
                </button>
              )}
            </div>
          </div>

          {(profile?.is_buyer || profile?.is_seller) && (
            <div className="mt-4 pt-4 border-t border-slate-200">
              <button
                onClick={() => setShowQuestionnaire(true)}
                className="flex items-center gap-2 text-mowatt-orange hover:text-mowatt-orange-dark font-semibold text-sm"
              >
                <Settings className="w-4 h-4" />
                {isQuestionnaireComplete ? 'Edit Buyer Preferences' : 'Complete Buyer Preferences'}
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">

          <div className="bg-white rounded-lg shadow-md border-2 border-mowatt-sand p-6">
            <div className="flex items-center gap-3 mb-2">
              <Heart className="w-5 h-5 text-mowatt-orange" />
              <h3 className="text-lg font-serif font-semibold text-mowatt-blue">Property Matches</h3>
            </div>
            <p className="text-3xl font-bold text-mowatt-blue">{matches.length}</p>
            <p className="text-mowatt-charcoal text-sm mt-1">Properties scored</p>
          </div>

          <div className="bg-white rounded-lg shadow-md border-2 border-mowatt-sand p-6">
            <div className="flex items-center gap-3 mb-2">
              <Calendar className="w-5 h-5 text-mowatt-orange" />
              <h3 className="text-lg font-serif font-semibold text-mowatt-blue">Viewing Requests</h3>
            </div>
            <p className="text-3xl font-bold text-mowatt-blue">{viewingRequests.length}</p>
            <p className="text-mowatt-charcoal text-sm mt-1">Total requests</p>
          </div>

          <button
            onClick={() => window.location.pathname = '/legal-services'}
            className="bg-gradient-to-br from-blue-600 to-slate-700 rounded-lg shadow-md border-2 border-blue-500 p-6 hover:shadow-xl transition-all text-left"
          >
            <div className="flex items-center gap-3 mb-2">
              <Scale className="w-6 h-6 text-white" />
              <h3 className="text-lg font-serif font-semibold text-white">Legal Services</h3>
            </div>
            <p className="text-white/90 text-sm mt-2">
              Manage conveyancing services for buying or selling properties
            </p>
            <div className="mt-4 flex items-center gap-2 text-white font-semibold text-sm">
              <span>View Services</span>
              <span>→</span>
            </div>
          </button>
        </div>

        {!isQuestionnaireComplete ? (
          <div className="bg-gradient-to-br from-mowatt-orange/10 to-mowatt-blue/10 rounded-lg shadow-md border-2 border-mowatt-orange p-8 mb-8">
            <div className="text-center">
              <ClipboardList className="w-20 h-20 text-mowatt-orange mx-auto mb-4" />
              <h3 className="text-2xl font-serif font-bold text-mowatt-blue mb-2">
                Complete Your Quiet Seekers Questionnaire
              </h3>
              <p className="text-mowatt-charcoal mb-6 max-w-2xl mx-auto">
                Help us understand what you're looking for in your perfect coastal home. Once complete, we'll calculate personalized match scores for all properties.
              </p>
              <button
                onClick={() => setShowQuestionnaire(true)}
                className="bg-mowatt-orange hover:bg-mowatt-orange-dark text-white px-8 py-3 rounded-lg font-semibold transition-all shadow-md hover:shadow-lg inline-flex items-center gap-2"
              >
                <ClipboardList className="w-5 h-5" />
                Start Questionnaire
              </button>
            </div>
          </div>
        ) : matches.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 mb-8">
            <div className="text-center">
              <TrendingUp className="w-16 h-16 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Calculate Your Match Scores
              </h3>
              <p className="text-slate-600 mb-6">
                Get personalized Mowatt Match Factor scores for all active properties based on your preferences.
              </p>
              <button
                onClick={calculateMatchScores}
                disabled={calculatingScores}
                className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-8 py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-600 transition-all shadow-lg hover:shadow-xl disabled:opacity-50"
              >
                {calculatingScores ? 'Calculating...' : 'Calculate Match Scores'}
              </button>
            </div>
          </div>
        ) : null}

        {matches.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Your Property Matches</h2>
                <p className="text-slate-600 mt-1">Sorted by Mowatt Match Factor</p>
              </div>
              <button
                onClick={calculateMatchScores}
                disabled={calculatingScores}
                className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                <TrendingUp className="w-4 h-4" />
                {calculatingScores ? 'Updating...' : 'Recalculate Scores'}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {matches.map((match) => (
                <div key={match.id} className="relative">
                  <div className={`absolute -top-3 -right-3 z-10 px-4 py-2 rounded-full shadow-lg font-bold text-lg ${getScoreColor(match.match_score)}`}>
                    {match.match_score}%
                  </div>
                  <div className="mb-2">
                    <span className={`inline-block px-3 py-1 rounded-lg text-xs font-semibold ${getScoreColor(match.match_score)}`}>
                      {getScoreLabel(match.match_score)}
                    </span>
                  </div>
                  <PropertyCard
                    property={match.property}
                    onRegisterInterest={() => {}}
                    matchScore={match.match_score}
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {viewingRequests.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Viewing Requests</h2>
            <div className="space-y-4">
              {viewingRequests.map((request) => (
                <div
                  key={request.id}
                  className="bg-white rounded-xl shadow-sm border border-slate-200 p-6"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900">
                        {request.property.title}
                      </h3>
                      <p className="text-slate-600 text-sm">{request.property.area_name}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize ${getStatusColor(request.status)}`}>
                      {request.status}
                    </span>
                  </div>
                  {request.scheduled_viewing_time && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <p className="text-sm font-semibold text-blue-900">
                        Scheduled: {new Date(request.scheduled_viewing_time).toLocaleString()}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <BuyerQuestionnaire
        isOpen={showQuestionnaire}
        onClose={() => setShowQuestionnaire(false)}
        onSubmit={handleQuestionnaireSubmit}
      />
    </div>
  );
}
