import { useState, useEffect } from 'react';
import { useLegalFirm } from '../contexts/LegalFirmContext';
import { supabase } from '../lib/supabase';
import {
  Scale, LogOut, Settings, Users, PoundSterling, Plus, Edit2,
  Trash2, Save, X, CheckCircle, Clock, TrendingUp
} from 'lucide-react';

interface LegalPricing {
  id: string;
  service_type: 'buying' | 'selling';
  price_min: number;
  price_max: number;
  conveyancing_fee: number;
  mowatt_charge: number;
  total_deposit_required: number;
}

interface ServiceRequest {
  id: string;
  user_id: string;
  service_type: 'buying' | 'selling';
  property_value: number;
  conveyancing_fee: number;
  deposit_amount: number;
  deposit_paid: boolean;
  status: string;
  property_address: string | null;
  created_at: string;
  user_profile: {
    full_name: string;
    email: string;
    phone: string;
  } | null;
}

export function LegalFirmDashboard() {
  const { firm, signOut } = useLegalFirm();
  const [pricing, setPricing] = useState<LegalPricing[]>([]);
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'pricing' | 'requests'>('overview');
  const [editingPricing, setEditingPricing] = useState<LegalPricing | null>(null);
  const [showAddPricing, setShowAddPricing] = useState(false);
  const [newPricing, setNewPricing] = useState({
    service_type: 'buying' as 'buying' | 'selling',
    price_min: 0,
    price_max: 0,
    conveyancing_fee: 0
  });

  useEffect(() => {
    if (firm) {
      fetchData();
    }
  }, [firm]);

  const fetchData = async () => {
    if (!firm) return;

    setLoading(true);
    try {
      await Promise.all([fetchPricing(), fetchRequests()]);
    } finally {
      setLoading(false);
    }
  };

  const fetchPricing = async () => {
    if (!firm) return;

    const { data, error } = await supabase
      .from('legal_pricing')
      .select('*')
      .eq('legal_firm_id', firm.id)
      .order('service_type', { ascending: true })
      .order('price_min', { ascending: true });

    if (error) {
      console.error('Error fetching pricing:', error);
    } else {
      setPricing(data || []);
    }
  };

  const fetchRequests = async () => {
    if (!firm) return;

    const { data, error } = await supabase
      .from('legal_service_requests')
      .select(`
        *,
        user_profile:user_profiles!legal_service_requests_user_id_fkey(full_name, email, phone)
      `)
      .eq('legal_firm_id', firm.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching requests:', error);
    } else {
      setRequests(data || []);
    }
  };

  const handleAddPricing = async () => {
    if (!firm) return;

    try {
      const { error } = await supabase
        .from('legal_pricing')
        .insert({
          legal_firm_id: firm.id,
          ...newPricing
        });

      if (error) throw error;

      alert('Pricing added successfully!');
      setShowAddPricing(false);
      setNewPricing({
        service_type: 'buying',
        price_min: 0,
        price_max: 0,
        conveyancing_fee: 0
      });
      fetchPricing();
    } catch (error: any) {
      alert('Error adding pricing: ' + error.message);
    }
  };

  const handleUpdatePricing = async () => {
    if (!editingPricing) return;

    try {
      const { error } = await supabase
        .from('legal_pricing')
        .update({
          price_min: editingPricing.price_min,
          price_max: editingPricing.price_max,
          conveyancing_fee: editingPricing.conveyancing_fee
        })
        .eq('id', editingPricing.id);

      if (error) throw error;

      alert('Pricing updated successfully!');
      setEditingPricing(null);
      fetchPricing();
    } catch (error: any) {
      alert('Error updating pricing: ' + error.message);
    }
  };

  const handleDeletePricing = async (id: string) => {
    if (!confirm('Are you sure you want to delete this pricing tier?')) return;

    try {
      const { error } = await supabase
        .from('legal_pricing')
        .delete()
        .eq('id', id);

      if (error) throw error;

      alert('Pricing deleted successfully!');
      fetchPricing();
    } catch (error: any) {
      alert('Error deleting pricing: ' + error.message);
    }
  };

  const handleUpdateRequestStatus = async (requestId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('legal_service_requests')
        .update({ status: newStatus })
        .eq('id', requestId);

      if (error) throw error;

      alert('Request status updated!');
      fetchRequests();
    } catch (error: any) {
      alert('Error updating status: ' + error.message);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-slate-600">Loading...</div>
      </div>
    );
  }

  if (!firm) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <Scale className="w-16 h-16 text-slate-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-700 mb-2">No Firm Found</h2>
          <p className="text-slate-600 mb-4">Your account is not associated with a legal firm.</p>
          <button
            onClick={() => signOut()}
            className="text-blue-600 hover:text-blue-700 font-semibold"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  const pendingRequests = requests.filter(r => r.status === 'pending');
  const activeRequests = requests.filter(r => ['deposit_paid', 'in_progress'].includes(r.status));
  const totalRevenue = requests
    .filter(r => r.deposit_paid)
    .reduce((sum, r) => sum + r.deposit_amount, 0);

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white shadow-md border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Scale className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900">{firm.firm_name}</h1>
                <p className="text-sm text-slate-600">{firm.contact_name}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {firm.is_verified ? (
                <span className="flex items-center gap-2 text-sm font-semibold text-green-600 bg-green-50 px-3 py-1.5 rounded-lg">
                  <CheckCircle className="w-4 h-4" />
                  Verified
                </span>
              ) : (
                <span className="flex items-center gap-2 text-sm font-semibold text-orange-600 bg-orange-50 px-3 py-1.5 rounded-lg">
                  <Clock className="w-4 h-4" />
                  Pending Verification
                </span>
              )}
              <button
                onClick={() => signOut()}
                className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold transition-all"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                activeTab === 'overview'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-slate-600 hover:bg-slate-100'
              }`}
            >
              <TrendingUp className="w-5 h-5 inline mr-2" />
              Overview
            </button>
            <button
              onClick={() => setActiveTab('pricing')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                activeTab === 'pricing'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-slate-600 hover:bg-slate-100'
              }`}
            >
              <PoundSterling className="w-5 h-5 inline mr-2" />
              Pricing
            </button>
            <button
              onClick={() => setActiveTab('requests')}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                activeTab === 'requests'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Users className="w-5 h-5 inline mr-2" />
              Requests ({requests.length})
            </button>
          </div>
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center gap-3 mb-2">
                  <Clock className="w-5 h-5 text-orange-600" />
                  <h3 className="text-sm font-semibold text-slate-600">Pending Requests</h3>
                </div>
                <p className="text-4xl font-bold text-slate-900">{pendingRequests.length}</p>
              </div>

              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center gap-3 mb-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  <h3 className="text-sm font-semibold text-slate-600">Active Clients</h3>
                </div>
                <p className="text-4xl font-bold text-slate-900">{activeRequests.length}</p>
              </div>

              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center gap-3 mb-2">
                  <PoundSterling className="w-5 h-5 text-green-600" />
                  <h3 className="text-sm font-semibold text-slate-600">Deposits Received</h3>
                </div>
                <p className="text-4xl font-bold text-slate-900">£{totalRevenue.toLocaleString()}</p>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-lg font-bold text-slate-900 mb-4">Recent Requests</h3>
              {requests.slice(0, 5).length > 0 ? (
                <div className="space-y-3">
                  {requests.slice(0, 5).map((request) => (
                    <div key={request.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                      <div>
                        <p className="font-semibold text-slate-900">
                          {request.user_profile?.full_name || 'Unknown User'}
                        </p>
                        <p className="text-sm text-slate-600">
                          {request.service_type === 'buying' ? 'Purchase' : 'Sale'} - £{request.property_value.toLocaleString()}
                        </p>
                      </div>
                      <span className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize ${
                        request.status === 'pending' ? 'bg-orange-100 text-orange-800' :
                        request.status === 'deposit_paid' ? 'bg-blue-100 text-blue-800' :
                        request.status === 'in_progress' ? 'bg-green-100 text-green-800' :
                        'bg-slate-100 text-slate-800'
                      }`}>
                        {request.status.replace('_', ' ')}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-500 text-center py-8">No requests yet</p>
              )}
            </div>
          </div>
        )}

        {activeTab === 'pricing' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-slate-900">Pricing Matrix</h2>
              <button
                onClick={() => setShowAddPricing(true)}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold transition-all"
              >
                <Plus className="w-4 h-4" />
                Add Pricing Tier
              </button>
            </div>

            {showAddPricing && (
              <div className="bg-white rounded-xl shadow-lg border-2 border-blue-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-bold text-slate-900">Add New Pricing Tier</h3>
                  <button
                    onClick={() => setShowAddPricing(false)}
                    className="text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Service Type</label>
                    <select
                      value={newPricing.service_type}
                      onChange={(e) => setNewPricing({ ...newPricing, service_type: e.target.value as 'buying' | 'selling' })}
                      className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="buying">Buying</option>
                      <option value="selling">Selling</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Conveyancing Fee (£)</label>
                    <input
                      type="number"
                      value={newPricing.conveyancing_fee || ''}
                      onChange={(e) => setNewPricing({ ...newPricing, conveyancing_fee: parseFloat(e.target.value) || 0 })}
                      className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="1194"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Property Value Min (£)</label>
                    <input
                      type="number"
                      value={newPricing.price_min || ''}
                      onChange={(e) => setNewPricing({ ...newPricing, price_min: parseFloat(e.target.value) || 0 })}
                      className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="150000"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Property Value Max (£)</label>
                    <input
                      type="number"
                      value={newPricing.price_max || ''}
                      onChange={(e) => setNewPricing({ ...newPricing, price_max: parseFloat(e.target.value) || 0 })}
                      className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="249999"
                    />
                  </div>
                </div>

                <button
                  onClick={handleAddPricing}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
                >
                  Add Pricing Tier
                </button>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pricing.map((price) => (
                <div key={price.id} className="bg-white rounded-xl shadow-md p-6">
                  {editingPricing?.id === price.id ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Conveyancing Fee</label>
                        <input
                          type="number"
                          value={editingPricing.conveyancing_fee}
                          onChange={(e) => setEditingPricing({ ...editingPricing, conveyancing_fee: parseFloat(e.target.value) })}
                          className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-2">Min Value</label>
                          <input
                            type="number"
                            value={editingPricing.price_min}
                            onChange={(e) => setEditingPricing({ ...editingPricing, price_min: parseFloat(e.target.value) })}
                            className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-slate-700 mb-2">Max Value</label>
                          <input
                            type="number"
                            value={editingPricing.price_max}
                            onChange={(e) => setEditingPricing({ ...editingPricing, price_max: parseFloat(e.target.value) })}
                            className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg"
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={handleUpdatePricing}
                          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-semibold"
                        >
                          <Save className="w-4 h-4 inline mr-2" />
                          Save
                        </button>
                        <button
                          onClick={() => setEditingPricing(null)}
                          className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 px-4 py-2 rounded-lg font-semibold"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center justify-between mb-4">
                        <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-lg text-sm font-semibold capitalize">
                          {price.service_type}
                        </span>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setEditingPricing(price)}
                            className="text-blue-600 hover:text-blue-700"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeletePricing(price.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div>
                          <p className="text-xs text-slate-600">Property Value Range</p>
                          <p className="text-lg font-bold text-slate-900">
                            £{price.price_min.toLocaleString()} - £{price.price_max.toLocaleString()}
                          </p>
                        </div>
                        <div className="grid grid-cols-2 gap-4 pt-3 border-t border-slate-200">
                          <div>
                            <p className="text-xs text-slate-600">Conveyancing Fee</p>
                            <p className="text-lg font-bold text-slate-900">£{price.conveyancing_fee.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-xs text-slate-600">Mowatt Charge (20%)</p>
                            <p className="text-lg font-bold text-blue-600">£{price.mowatt_charge.toLocaleString()}</p>
                          </div>
                        </div>
                        <div className="pt-3 border-t border-slate-200">
                          <p className="text-xs text-slate-600">Deposit Required</p>
                          <p className="text-2xl font-bold text-green-600">£{price.total_deposit_required.toLocaleString()}</p>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>

            {pricing.length === 0 && !showAddPricing && (
              <div className="bg-white rounded-xl shadow-md p-12 text-center">
                <PoundSterling className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-slate-700 mb-2">No Pricing Set</h3>
                <p className="text-slate-500 mb-6">Add your first pricing tier to start receiving requests</p>
                <button
                  onClick={() => setShowAddPricing(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-all"
                >
                  Add Pricing Tier
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'requests' && (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Service Requests</h2>

            {requests.length > 0 ? (
              requests.map((request) => (
                <div key={request.id} className="bg-white rounded-xl shadow-md p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900">
                        {request.user_profile?.full_name || 'Unknown User'}
                      </h3>
                      <p className="text-sm text-slate-600">
                        {request.service_type === 'buying' ? 'Purchase' : 'Sale'} Conveyancing
                      </p>
                    </div>
                    <select
                      value={request.status}
                      onChange={(e) => handleUpdateRequestStatus(request.id, e.target.value)}
                      className={`px-3 py-1 rounded-lg text-sm font-semibold border-2 ${
                        request.status === 'pending' ? 'border-orange-200 bg-orange-50 text-orange-800' :
                        request.status === 'deposit_paid' ? 'border-blue-200 bg-blue-50 text-blue-800' :
                        request.status === 'in_progress' ? 'border-green-200 bg-green-50 text-green-800' :
                        request.status === 'completed' ? 'border-slate-200 bg-slate-50 text-slate-800' :
                        'border-red-200 bg-red-50 text-red-800'
                      }`}
                    >
                      <option value="pending">Pending</option>
                      <option value="deposit_paid">Deposit Paid</option>
                      <option value="in_progress">In Progress</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-xs text-slate-600 mb-1">Property Value</p>
                      <p className="text-lg font-bold text-slate-900">£{request.property_value.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-600 mb-1">Conveyancing Fee</p>
                      <p className="text-lg font-bold text-slate-900">£{request.conveyancing_fee.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-600 mb-1">Deposit Amount</p>
                      <p className="text-lg font-bold text-blue-600">£{request.deposit_amount.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-600 mb-1">Deposit Status</p>
                      <p className={`text-sm font-semibold ${request.deposit_paid ? 'text-green-600' : 'text-orange-600'}`}>
                        {request.deposit_paid ? 'Paid' : 'Pending'}
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-xs text-slate-600 mb-2">Client Contact</p>
                    <p className="text-sm font-semibold text-slate-900">{request.user_profile?.full_name}</p>
                    <p className="text-sm text-slate-600">{request.user_profile?.email}</p>
                    {request.user_profile?.phone && (
                      <p className="text-sm text-slate-600">{request.user_profile.phone}</p>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-white rounded-xl shadow-md p-12 text-center">
                <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-slate-700 mb-2">No Requests Yet</h3>
                <p className="text-slate-500">Service requests will appear here once clients select your firm</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
