import { useState, useEffect } from 'react';
import {
  Home, MapPin, Ruler, Bed, Bath, Car, TreePine, Hammer,
  PoundSterling, User, CheckCircle, ArrowRight, ArrowLeft, Save,
  Upload, X, Scale
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { ImageUpload } from '../components/ImageUpload';
import { LegalServicesSelector } from '../components/LegalServicesSelector';

interface QuestionnaireData {
  property_address?: string;
  property_postcode?: string;
  property_type?: string;
  year_built?: number;
  builder_name?: string;
  is_show_home?: boolean;
  num_bedrooms?: number;
  num_bathrooms?: number;
  num_reception_rooms?: number;
  square_meters?: number;
  square_feet?: number;
  kitchen_details?: string;
  heating_type?: string;
  glazing_type?: string;
  parking_details?: string;
  garage_details?: string;
  special_features?: string[];
  garden_description?: string;
  garden_size?: string;
  garden_orientation?: string;
  outdoor_features?: string[];
  property_condition?: string;
  recent_upgrades?: Array<{description: string, year: number}>;
  boiler_age?: number;
  windows_condition?: string;
  area_description?: string;
  nearby_amenities?: string[];
  walking_distances?: {[key: string]: string};
  desired_price_min?: number;
  desired_price_max?: number;
  seller_name?: string;
  seller_email?: string;
  seller_phone?: string;
  how_long_owned?: string;
  reason_for_selling?: string;
  timeline?: string;
  preferred_sale_route?: string;
  additional_notes?: string;
  images?: string[];
}

const STEPS = [
  { id: 1, title: 'Property Basics', icon: Home },
  { id: 2, title: 'Property Details', icon: Ruler },
  { id: 3, title: 'Features & Amenities', icon: Bed },
  { id: 4, title: 'Outdoor Space', icon: TreePine },
  { id: 5, title: 'Condition & Upgrades', icon: Hammer },
  { id: 6, title: 'Location', icon: MapPin },
  { id: 7, title: 'Pricing', icon: PoundSterling },
  { id: 8, title: 'Your Information', icon: User },
  { id: 9, title: 'Photos', icon: Upload },
  { id: 10, title: 'Legal Services', icon: Scale },
  { id: 11, title: 'Also Buying?', icon: User },
];

export default function SellerQuestionnaire() {
  const { user } = useAuth();
  const questionnaireId = new URLSearchParams(window.location.search).get('id');

  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<QuestionnaireData>({});
  const [loading, setLoading] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(questionnaireId);
  const [alsoBuying, setAlsoBuying] = useState<string>('');
  const [legalFirmId, setLegalFirmId] = useState<string>('');
  const [legalQuote, setLegalQuote] = useState<any>(null);

  useEffect(() => {
    if (questionnaireId) {
      loadQuestionnaire(questionnaireId);
    }
  }, [questionnaireId]);

  const loadQuestionnaire = async (id: string) => {
    try {
      const { data, error } = await supabase
        .from('seller_questionnaires')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      if (data) {
        setFormData(data);
      }
    } catch (error) {
      console.error('Error loading questionnaire:', error);
    }
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayAdd = (field: string, value: string) => {
    const currentArray = (formData[field as keyof QuestionnaireData] as string[]) || [];
    handleInputChange(field, [...currentArray, value]);
  };

  const handleArrayRemove = (field: string, index: number) => {
    const currentArray = (formData[field as keyof QuestionnaireData] as string[]) || [];
    handleInputChange(field, currentArray.filter((_, i) => i !== index));
  };

  const saveDraft = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const dataToSave = {
        ...formData,
        user_id: user.id,
        status: 'draft',
        updated_at: new Date().toISOString(),
      };

      if (savedId) {
        const { error } = await supabase
          .from('seller_questionnaires')
          .update(dataToSave)
          .eq('id', savedId);

        if (error) throw error;
        alert('Draft saved successfully!');
      } else {
        const { data, error } = await supabase
          .from('seller_questionnaires')
          .insert(dataToSave)
          .select()
          .single();

        if (error) throw error;
        setSavedId(data.id);
        alert('Draft saved successfully!');
      }
    } catch (error: any) {
      alert(`Error saving draft: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const submitQuestionnaire = async () => {
    if (!user || !savedId) {
      alert('Please save as draft first');
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('seller_questionnaires')
        .update({
          status: 'submitted',
          submitted_at: new Date().toISOString(),
        })
        .eq('id', savedId);

      if (error) throw error;

      const { error: profileError } = await supabase
        .from('user_profiles')
        .upsert({
          user_id: user.id,
          is_seller: true,
          email: formData.seller_email,
          phone: formData.seller_phone,
          full_name: formData.seller_name,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'user_id'
        });

      if (profileError) console.error('Error updating profile:', profileError);

      if (legalFirmId && legalQuote) {
        const { error: legalError } = await supabase
          .from('legal_service_requests')
          .insert({
            user_id: user.id,
            legal_firm_id: legalFirmId,
            service_type: 'selling',
            property_value: formData.desired_price_max || formData.desired_price_min || 0,
            conveyancing_fee: legalQuote.conveyancing_fee,
            deposit_amount: legalQuote.total_deposit_required,
            property_address: formData.property_address,
            status: 'pending'
          });

        if (legalError) console.error('Error creating legal service request:', legalError);

        await supabase
          .from('user_profiles')
          .update({ has_legal_service_seller: true, legal_firm_id_seller: legalFirmId })
          .eq('user_id', user.id);
      }

      if (alsoBuying === 'yes') {
        window.location.href = '/buyer-questionnaire?from=seller';
      } else if (alsoBuying === 'no' || alsoBuying === 'later') {
        alert('Questionnaire submitted successfully! Our team will review it and create your listing.');
        window.location.pathname = '/profile';
      } else {
        alert('Please select an option on the final step');
        setCurrentStep(11);
      }
    } catch (error: any) {
      alert(`Error submitting questionnaire: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const nextStep = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return <Step1BasicInfo formData={formData} onChange={handleInputChange} />;
      case 2:
        return <Step2PropertyDetails formData={formData} onChange={handleInputChange} />;
      case 3:
        return <Step3Features formData={formData} onChange={handleInputChange} onArrayAdd={handleArrayAdd} onArrayRemove={handleArrayRemove} />;
      case 4:
        return <Step4OutdoorSpace formData={formData} onChange={handleInputChange} onArrayAdd={handleArrayAdd} onArrayRemove={handleArrayRemove} />;
      case 5:
        return <Step5Condition formData={formData} onChange={handleInputChange} onArrayAdd={handleArrayAdd} onArrayRemove={handleArrayRemove} />;
      case 6:
        return <Step6Location formData={formData} onChange={handleInputChange} onArrayAdd={handleArrayAdd} onArrayRemove={handleArrayRemove} />;
      case 7:
        return <Step7Pricing formData={formData} onChange={handleInputChange} />;
      case 8:
        return <Step8SellerInfo formData={formData} onChange={handleInputChange} />;
      case 9:
        return <Step9Photos formData={formData} onChange={handleInputChange} />;
      case 10:
        return (
          <LegalServicesSelector
            serviceType="selling"
            propertyValue={formData.desired_price_max || formData.desired_price_min}
            onSelect={(firmId, quote) => {
              setLegalFirmId(firmId);
              setLegalQuote(quote);
            }}
            selectedFirmId={legalFirmId}
          />
        );
      case 11:
        return <Step11AlsoBuying alsoBuying={alsoBuying} setAlsoBuying={setAlsoBuying} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Property Listing Questionnaire</h1>
          <p className="text-slate-600 mb-8">
            Help us create your property appraisal report and listing. Fill in as much detail as possible.
          </p>

          {/* Progress Steps */}
          <div className="mb-10">
            <div className="flex justify-between items-center mb-4">
              {STEPS.map((step, index) => (
                <div key={step.id} className="flex items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                      currentStep >= step.id
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {currentStep > step.id ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      <step.icon className="w-5 h-5" />
                    )}
                  </div>
                  {index < STEPS.length - 1 && (
                    <div
                      className={`h-1 w-8 mx-2 transition-all ${
                        currentStep > step.id ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
            <p className="text-center text-sm text-slate-600">
              Step {currentStep} of {STEPS.length}: {STEPS[currentStep - 1].title}
            </p>
          </div>

          {/* Form Content */}
          <div className="mb-8">{renderStepContent()}</div>

          {/* Navigation Buttons */}
          <div className="flex justify-between items-center pt-6 border-t">
            <button
              onClick={prevStep}
              disabled={currentStep === 1}
              className="flex items-center gap-2 px-6 py-3 rounded-lg border-2 border-gray-300 text-gray-700 font-semibold hover:bg-gray-50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ArrowLeft className="w-5 h-5" />
              Previous
            </button>

            <div className="flex gap-3">
              <button
                onClick={saveDraft}
                disabled={loading || currentStep === 9}
                className="flex items-center gap-2 px-6 py-3 rounded-lg border-2 border-blue-600 text-blue-600 font-semibold hover:bg-blue-50 transition-all disabled:opacity-50"
              >
                <Save className="w-5 h-5" />
                Save Draft
              </button>

              {currentStep < STEPS.length ? (
                <button
                  onClick={nextStep}
                  className="flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold hover:from-blue-700 hover:to-blue-600 transition-all shadow-lg"
                >
                  Next
                  <ArrowRight className="w-5 h-5" />
                </button>
              ) : (
                <button
                  onClick={submitQuestionnaire}
                  disabled={loading || !savedId || currentStep === 9}
                  className="flex items-center gap-2 px-8 py-3 rounded-lg bg-gradient-to-r from-green-600 to-green-500 text-white font-semibold hover:from-green-700 hover:to-green-600 transition-all shadow-lg disabled:opacity-50"
                >
                  <CheckCircle className="w-5 h-5" />
                  Submit for Review
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Step Components
function Step1BasicInfo({ formData, onChange }: any) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Property Basics</h2>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Postcode of Property *
        </label>
        <input
          type="text"
          value={formData.property_postcode || ''}
          onChange={(e) => onChange('property_postcode', e.target.value)}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="e.g., EH31 2ES"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Property Address *
        </label>
        <input
          type="text"
          value={formData.property_address || ''}
          onChange={(e) => onChange('property_address', e.target.value)}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="e.g., 31 Fenton Gait East"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Property Type *
        </label>
        <select
          value={formData.property_type || ''}
          onChange={(e) => onChange('property_type', e.target.value)}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          required
        >
          <option value="">Select type...</option>
          <option value="detached">Detached</option>
          <option value="semi-detached">Semi-Detached</option>
          <option value="terraced">Terraced</option>
          <option value="flat">Flat</option>
          <option value="apartment">Apartment</option>
          <option value="bungalow">Bungalow</option>
          <option value="villa">Villa</option>
          <option value="other">Other</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Year Built (roughly)
          </label>
          <select
            value={formData.year_built || ''}
            onChange={(e) => onChange('year_built', e.target.value === 'Unknown' ? 'Unknown' : parseInt(e.target.value))}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select year...</option>
            <option value="Unknown">Unknown</option>
            {Array.from({ length: 100 }, (_, i) => new Date().getFullYear() - i).map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Builder Name (if known)
          </label>
          <input
            type="text"
            value={formData.builder_name || ''}
            onChange={(e) => onChange('builder_name', e.target.value)}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., Cala Homes (optional)"
          />
        </div>
      </div>

      <div className="flex items-center gap-3">
        <input
          type="checkbox"
          id="is_show_home"
          checked={formData.is_show_home || false}
          onChange={(e) => onChange('is_show_home', e.target.checked)}
          className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
        />
        <label htmlFor="is_show_home" className="text-sm font-semibold text-slate-700">
          This property was a show home
        </label>
      </div>
    </div>
  );
}

function Step2PropertyDetails({ formData, onChange }: any) {
  const calculateSqFt = (sqm: number) => {
    return Math.round(sqm * 10.764);
  };

  const calculateSqM = (sqft: number) => {
    return Math.round(sqft / 10.764);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Property Details</h2>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Bedrooms *
          </label>
          <input
            type="number"
            value={formData.num_bedrooms || ''}
            onChange={(e) => onChange('num_bedrooms', parseInt(e.target.value))}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            min="0"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Bathrooms *
          </label>
          <input
            type="number"
            value={formData.num_bathrooms || ''}
            onChange={(e) => onChange('num_bathrooms', parseInt(e.target.value))}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            min="0"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Reception Rooms
          </label>
          <input
            type="number"
            value={formData.num_reception_rooms || ''}
            onChange={(e) => onChange('num_reception_rooms', parseInt(e.target.value))}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            min="0"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Square Meters
          </label>
          <input
            type="number"
            value={formData.square_meters || ''}
            onChange={(e) => {
              const sqm = parseFloat(e.target.value);
              onChange('square_meters', sqm);
              if (sqm) {
                onChange('square_feet', calculateSqFt(sqm));
              }
            }}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., 227"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Square Feet
          </label>
          <input
            type="number"
            value={formData.square_feet || ''}
            onChange={(e) => {
              const sqft = parseFloat(e.target.value);
              onChange('square_feet', sqft);
              if (sqft) {
                onChange('square_meters', calculateSqM(sqft));
              }
            }}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., 2443"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Kitchen Details
        </label>
        <textarea
          value={formData.kitchen_details || ''}
          onChange={(e) => onChange('kitchen_details', e.target.value)}
          rows={4}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Describe your kitchen (e.g., upgraded with marble worktops, modern appliances, open-plan design...)"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Heating Type
          </label>
          <select
            value={formData.heating_type || ''}
            onChange={(e) => onChange('heating_type', e.target.value)}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select...</option>
            <option value="gas_central">Gas Central Heating</option>
            <option value="electric">Electric Heating</option>
            <option value="oil">Oil Heating</option>
            <option value="heat_pump">Heat Pump</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Window Type
          </label>
          <select
            value={formData.glazing_type || ''}
            onChange={(e) => onChange('glazing_type', e.target.value)}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select...</option>
            <option value="double_glazed">Double Glazed</option>
            <option value="single_glazed">Single Glazed</option>
            <option value="triple_glazed">Triple Glazed</option>
            <option value="mixed">Mixed</option>
          </select>
        </div>
      </div>
    </div>
  );
}

function Step3Features({ formData, onChange, onArrayAdd, onArrayRemove }: any) {
  const [newFeature, setNewFeature] = useState('');

  const handleAddFeature = () => {
    if (newFeature.trim()) {
      onArrayAdd('special_features', newFeature.trim());
      setNewFeature('');
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Features & Amenities</h2>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Parking Details
        </label>
        <textarea
          value={formData.parking_details || ''}
          onChange={(e) => onChange('parking_details', e.target.value)}
          rows={3}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Describe parking arrangements (e.g., driveway for 3 cars, street parking, garage...)"
        />
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Garage Details
        </label>
        <textarea
          value={formData.garage_details || ''}
          onChange={(e) => onChange('garage_details', e.target.value)}
          rows={3}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Describe garage (e.g., double garage, converted to gym...)"
        />
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Special Features
        </label>
        <p className="text-sm text-slate-600 mb-3">
          Add standout features like media walls, log burners, fitted wardrobes, etc.
        </p>

        <div className="flex gap-2 mb-3">
          <input
            type="text"
            value={newFeature}
            onChange={(e) => setNewFeature(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddFeature()}
            className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., Media wall with electric fire"
          />
          <button
            type="button"
            onClick={handleAddFeature}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all"
          >
            Add
          </button>
        </div>

        <div className="space-y-2">
          {((formData.special_features as string[]) || []).map((feature, index) => (
            <div key={index} className="flex items-center justify-between bg-blue-50 px-4 py-2 rounded-lg">
              <span className="text-slate-700">{feature}</span>
              <button
                type="button"
                onClick={() => onArrayRemove('special_features', index)}
                className="text-red-600 hover:text-red-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Step4OutdoorSpace({ formData, onChange, onArrayAdd, onArrayRemove }: any) {
  const [newOutdoorFeature, setNewOutdoorFeature] = useState('');

  const handleAddFeature = () => {
    if (newOutdoorFeature.trim()) {
      onArrayAdd('outdoor_features', newOutdoorFeature.trim());
      setNewOutdoorFeature('');
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Outdoor Space</h2>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Garden Description
        </label>
        <textarea
          value={formData.garden_description || ''}
          onChange={(e) => onChange('garden_description', e.target.value)}
          rows={4}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Describe your garden and outdoor spaces in detail..."
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Garden Size
          </label>
          <select
            value={formData.garden_size || ''}
            onChange={(e) => onChange('garden_size', e.target.value)}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select...</option>
            <option value="small">Small</option>
            <option value="medium">Medium</option>
            <option value="large">Large</option>
            <option value="very_large">Very Large</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Garden Orientation
          </label>
          <select
            value={formData.garden_orientation || ''}
            onChange={(e) => onChange('garden_orientation', e.target.value)}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select...</option>
            <option value="north">North Facing</option>
            <option value="south">South Facing</option>
            <option value="east">East Facing</option>
            <option value="west">West Facing</option>
            <option value="mixed">Mixed</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Outdoor Features
        </label>
        <p className="text-sm text-slate-600 mb-3">
          Add features like patio, decking, shed, greenhouse, etc.
        </p>

        <div className="flex gap-2 mb-3">
          <input
            type="text"
            value={newOutdoorFeature}
            onChange={(e) => setNewOutdoorFeature(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddFeature()}
            className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., Large patio with seating area"
          />
          <button
            type="button"
            onClick={handleAddFeature}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all"
          >
            Add
          </button>
        </div>

        <div className="space-y-2">
          {((formData.outdoor_features as string[]) || []).map((feature, index) => (
            <div key={index} className="flex items-center justify-between bg-green-50 px-4 py-2 rounded-lg">
              <span className="text-slate-700">{feature}</span>
              <button
                type="button"
                onClick={() => onArrayRemove('outdoor_features', index)}
                className="text-red-600 hover:text-red-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Step5Condition({ formData, onChange, onArrayAdd, onArrayRemove }: any) {
  const [newUpgrade, setNewUpgrade] = useState({ description: '', year: new Date().getFullYear() });

  const handleAddUpgrade = () => {
    if (newUpgrade.description.trim()) {
      onArrayAdd('recent_upgrades', newUpgrade);
      setNewUpgrade({ description: '', year: new Date().getFullYear() });
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Condition & Upgrades</h2>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Overall Property Condition
        </label>
        <select
          value={formData.property_condition || ''}
          onChange={(e) => onChange('property_condition', e.target.value)}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">Select...</option>
          <option value="excellent">Excellent - Move-in ready</option>
          <option value="good">Good - Well maintained</option>
          <option value="fair">Fair - Some updates needed</option>
          <option value="needs_work">Needs Work - Requires renovation</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Boiler Age (years)
          </label>
          <input
            type="number"
            value={formData.boiler_age || ''}
            onChange={(e) => onChange('boiler_age', parseInt(e.target.value))}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., 9"
            min="0"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Window Condition
          </label>
          <select
            value={formData.windows_condition || ''}
            onChange={(e) => onChange('windows_condition', e.target.value)}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select...</option>
            <option value="new">New</option>
            <option value="refurbished">Refurbished</option>
            <option value="good">Good Condition</option>
            <option value="fair">Fair Condition</option>
            <option value="needs_replacement">Needs Replacement</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Recent Upgrades
        </label>
        <p className="text-sm text-slate-600 mb-3">
          List any major improvements or upgrades you've made
        </p>

        <div className="flex gap-2 mb-3">
          <input
            type="text"
            value={newUpgrade.description}
            onChange={(e) => setNewUpgrade({ ...newUpgrade, description: e.target.value })}
            className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., New kitchen installed"
          />
          <input
            type="number"
            value={newUpgrade.year}
            onChange={(e) => setNewUpgrade({ ...newUpgrade, year: parseInt(e.target.value) })}
            className="w-32 px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Year"
            min="1900"
            max={new Date().getFullYear()}
          />
          <button
            type="button"
            onClick={handleAddUpgrade}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all"
          >
            Add
          </button>
        </div>

        <div className="space-y-2">
          {((formData.recent_upgrades as any[]) || []).map((upgrade, index) => (
            <div key={index} className="flex items-center justify-between bg-amber-50 px-4 py-2 rounded-lg">
              <span className="text-slate-700">
                {upgrade.description} ({upgrade.year})
              </span>
              <button
                type="button"
                onClick={() => onArrayRemove('recent_upgrades', index)}
                className="text-red-600 hover:text-red-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Step6Location({ formData, onChange, onArrayAdd, onArrayRemove }: any) {
  const [newAmenity, setNewAmenity] = useState('');
  const [walkingDistance, setWalkingDistance] = useState({ place: '', distance: '' });

  const handleAddAmenity = () => {
    if (newAmenity.trim()) {
      onArrayAdd('nearby_amenities', newAmenity.trim());
      setNewAmenity('');
    }
  };

  const handleAddDistance = () => {
    if (walkingDistance.place.trim() && walkingDistance.distance.trim()) {
      const current = formData.walking_distances || {};
      onChange('walking_distances', { ...current, [walkingDistance.place]: walkingDistance.distance });
      setWalkingDistance({ place: '', distance: '' });
    }
  };

  const handleRemoveDistance = (place: string) => {
    const current = { ...(formData.walking_distances || {}) };
    delete current[place];
    onChange('walking_distances', current);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Location & Amenities</h2>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Unique Selling Points of My Locale
        </label>
        <textarea
          value={formData.area_description || ''}
          onChange={(e) => onChange('area_description', e.target.value)}
          rows={4}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Describe the location, neighborhood, and what makes it special..."
        />
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Nearby Amenities
        </label>
        <p className="text-sm text-slate-600 mb-3">
          Add nearby facilities like shops, schools, parks, etc.
        </p>

        <div className="flex gap-2 mb-3">
          <input
            type="text"
            value={newAmenity}
            onChange={(e) => setNewAmenity(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddAmenity()}
            className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., Margiotta minimarket"
          />
          <button
            type="button"
            onClick={handleAddAmenity}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all"
          >
            Add
          </button>
        </div>

        <div className="space-y-2">
          {((formData.nearby_amenities as string[]) || []).map((amenity, index) => (
            <div key={index} className="flex items-center justify-between bg-purple-50 px-4 py-2 rounded-lg">
              <span className="text-slate-700">{amenity}</span>
              <button
                type="button"
                onClick={() => onArrayRemove('nearby_amenities', index)}
                className="text-red-600 hover:text-red-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Walking Distances
        </label>
        <p className="text-sm text-slate-600 mb-3">
          Add walking distances to key locations
        </p>

        <div className="flex gap-2 mb-3">
          <input
            type="text"
            value={walkingDistance.place}
            onChange={(e) => setWalkingDistance({ ...walkingDistance, place: e.target.value })}
            className="flex-1 px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Place (e.g., Beach)"
          />
          <input
            type="text"
            value={walkingDistance.distance}
            onChange={(e) => setWalkingDistance({ ...walkingDistance, distance: e.target.value })}
            className="w-40 px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., 5 minutes"
          />
          <button
            type="button"
            onClick={handleAddDistance}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all"
          >
            Add
          </button>
        </div>

        <div className="space-y-2">
          {Object.entries((formData.walking_distances as {[key: string]: string}) || {}).map(([place, distance]) => (
            <div key={place} className="flex items-center justify-between bg-teal-50 px-4 py-2 rounded-lg">
              <span className="text-slate-700">
                {place}: {distance}
              </span>
              <button
                type="button"
                onClick={() => handleRemoveDistance(place)}
                className="text-red-600 hover:text-red-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Step7Pricing({ formData, onChange }: any) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Pricing Expectations</h2>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <p className="text-sm text-blue-900">
          We'll provide you with a professional valuation based on comparable sales data and market conditions.
          However, it's helpful to know your expectations.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Minimum Acceptable Price
          </label>
          <div className="relative">
            <span className="absolute left-4 top-3.5 text-slate-600">£</span>
            <input
              type="number"
              value={formData.desired_price_min || ''}
              onChange={(e) => onChange('desired_price_min', parseFloat(e.target.value))}
              className="w-full pl-8 pr-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., 750000"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Maximum Desired Price
          </label>
          <div className="relative">
            <span className="absolute left-4 top-3.5 text-slate-600">£</span>
            <input
              type="number"
              value={formData.desired_price_max || ''}
              onChange={(e) => onChange('desired_price_max', parseFloat(e.target.value))}
              className="w-full pl-8 pr-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., 800000"
            />
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Sale Timeline
        </label>
        <select
          value={formData.timeline || ''}
          onChange={(e) => onChange('timeline', e.target.value)}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">Select...</option>
          <option value="asap">As soon as possible</option>
          <option value="1-3_months">1-3 months</option>
          <option value="3-6_months">3-6 months</option>
          <option value="6-12_months">6-12 months</option>
          <option value="flexible">Flexible</option>
          <option value="just_testing">Just testing the market</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Preferred Sale Route
        </label>
        <select
          value={formData.preferred_sale_route || ''}
          onChange={(e) => onChange('preferred_sale_route', e.target.value)}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">Select...</option>
          <option value="off_market">Off Market (Hush Home) - Discreet, no public listing</option>
          <option value="open_market">Open Market - Full public marketing</option>
          <option value="both">Try Off Market first, then Open Market if needed</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Reason for Selling
        </label>
        <textarea
          value={formData.reason_for_selling || ''}
          onChange={(e) => onChange('reason_for_selling', e.target.value)}
          rows={3}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Optional: Share why you're selling (helps us find the right buyer)..."
        />
      </div>
    </div>
  );
}

function Step8SellerInfo({ formData, onChange }: any) {
  const { profile } = useAuth();
  const [showSecondOwner, setShowSecondOwner] = useState(false);

  useEffect(() => {
    if (profile && !formData.seller_name) {
      onChange('seller_name', profile.full_name || '');
      onChange('seller_email', profile.email || '');
      onChange('seller_phone', profile.phone || '');
    }
  }, [profile]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Your Information</h2>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
        <label className="flex items-center gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={formData.jointly_owned || false}
            onChange={(e) => {
              onChange('jointly_owned', e.target.checked);
              if (!e.target.checked) {
                setShowSecondOwner(false);
              }
            }}
            className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
          />
          <span className="font-semibold text-blue-900">
            I/we own this property:
          </span>
        </label>
        <div className="ml-8 mt-2 space-y-2">
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="ownership_type"
              value="jointly"
              checked={formData.ownership_type === 'jointly'}
              onChange={(e) => {
                onChange('ownership_type', e.target.value);
                setShowSecondOwner(true);
              }}
              className="w-4 h-4 text-blue-600"
            />
            <span className="text-blue-900">Jointly</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="ownership_type"
              value="solely"
              checked={formData.ownership_type === 'solely'}
              onChange={(e) => {
                onChange('ownership_type', e.target.value);
                setShowSecondOwner(false);
              }}
              className="w-4 h-4 text-blue-600"
            />
            <span className="text-blue-900">Solely</span>
          </label>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Full Name (Owner 1) *
        </label>
        <input
          type="text"
          value={formData.seller_name || ''}
          onChange={(e) => onChange('seller_name', e.target.value)}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="e.g., Elena Wright"
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Email *
          </label>
          <input
            type="email"
            value={formData.seller_email || ''}
            onChange={(e) => onChange('seller_email', e.target.value)}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="your@email.com"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Phone Number
          </label>
          <input
            type="tel"
            value={formData.seller_phone || ''}
            onChange={(e) => onChange('seller_phone', e.target.value)}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="07XXX XXXXXX"
          />
        </div>
      </div>

      {showSecondOwner && formData.ownership_type === 'jointly' && (
        <div className="mt-6 p-4 bg-slate-50 rounded-lg border-2 border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 mb-4">Second Owner Information</h3>

          <div className="mb-4">
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Full Name (Owner 2) *
            </label>
            <input
              type="text"
              value={formData.second_owner_name || ''}
              onChange={(e) => onChange('second_owner_name', e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., David Wright"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Email
              </label>
              <input
                type="email"
                value={formData.second_owner_email || ''}
                onChange={(e) => onChange('second_owner_email', e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="second@email.com"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Phone Number
              </label>
              <input
                type="tel"
                value={formData.second_owner_phone || ''}
                onChange={(e) => onChange('second_owner_phone', e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="07XXX XXXXXX"
              />
            </div>
          </div>
        </div>
      )}

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          How Long Have You Owned This Property?
        </label>
        <select
          value={formData.how_long_owned || ''}
          onChange={(e) => onChange('how_long_owned', e.target.value)}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="">Select...</option>
          <option value="less_1">Less than 1 year</option>
          <option value="1-3">1-3 years</option>
          <option value="3-5">3-5 years</option>
          <option value="5-10">5-10 years</option>
          <option value="10-20">10-20 years</option>
          <option value="20+">20+ years</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Additional Notes
        </label>
        <textarea
          value={formData.additional_notes || ''}
          onChange={(e) => onChange('additional_notes', e.target.value)}
          rows={5}
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Any other information you'd like to share about the property or your requirements..."
        />
      </div>
    </div>
  );
}

function Step9Photos({ formData, onChange }: any) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Property Photos</h2>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
        <p className="text-sm text-amber-900 mb-2">
          <strong>Photo Upload Coming Soon</strong>
        </p>
        <p className="text-sm text-amber-900">
          Photo upload functionality will be activated after submission. We'll arrange a professional photography session for your property.
        </p>
      </div>

      <div className="opacity-50 pointer-events-none">
        <ImageUpload
          images={formData.images || []}
          onChange={(images) => onChange('images', images)}
          maxImages={20}
        />
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <h3 className="font-semibold text-green-900 mb-2">What Happens Next?</h3>
        <ol className="space-y-2 text-sm text-green-900">
          <li>1. Submit this questionnaire for review</li>
          <li>2. We'll contact you within 24 hours to schedule a property visit</li>
          <li>3. During the visit, we'll verify details and may take additional professional photos</li>
          <li>4. We'll generate your Property Appraisal Report (PDF) and Google Sheet</li>
          <li>5. Your listing will be created and added to Matchlist</li>
          <li>6. Once verified, a "Verified by Mowatt" badge will appear on your listing</li>
        </ol>
      </div>
    </div>
  );
}

function Step11AlsoBuying({ alsoBuying, setAlsoBuying }: any) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Are You Also Looking to Buy?</h2>

      <div className="bg-gradient-to-br from-blue-50 to-teal-50 border border-blue-200 rounded-xl p-6 mb-6">
        <h3 className="text-lg font-bold text-slate-900 mb-3">Free Seller Listing + 1% Buyer Commission</h3>
        <div className="space-y-3 text-slate-700">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Selling is FREE</p>
              <p className="text-sm">No fees, no commission, no costs to list your property</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Buying costs 1% commission</p>
              <p className="text-sm">Only pay when you successfully purchase through Matchlist</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-teal-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">One account for both</p>
              <p className="text-sm">Manage your property sale and search all in one place</p>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <label className="block text-lg font-semibold text-slate-900 mb-4">
          Are you also looking to buy a property?
        </label>

        <div className="space-y-3">
          <label className="flex items-center gap-4 p-5 border-2 border-slate-200 rounded-xl cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all">
            <input
              type="radio"
              name="alsoBuying"
              value="yes"
              checked={alsoBuying === 'yes'}
              onChange={(e) => setAlsoBuying(e.target.value)}
              className="w-5 h-5 text-blue-600"
            />
            <div>
              <p className="font-semibold text-slate-900">Yes, take me to the Buyer Questionnaire</p>
              <p className="text-sm text-slate-600">Complete your seller listing, then seamlessly register as a buyer</p>
            </div>
          </label>

          <label className="flex items-center gap-4 p-5 border-2 border-slate-200 rounded-xl cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all">
            <input
              type="radio"
              name="alsoBuying"
              value="no"
              checked={alsoBuying === 'no'}
              onChange={(e) => setAlsoBuying(e.target.value)}
              className="w-5 h-5 text-blue-600"
            />
            <div>
              <p className="font-semibold text-slate-900">No, I'm only selling</p>
              <p className="text-sm text-slate-600">Complete your seller questionnaire and finish</p>
            </div>
          </label>

          <label className="flex items-center gap-4 p-5 border-2 border-slate-200 rounded-xl cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all">
            <input
              type="radio"
              name="alsoBuying"
              value="later"
              checked={alsoBuying === 'later'}
              onChange={(e) => setAlsoBuying(e.target.value)}
              className="w-5 h-5 text-blue-600"
            />
            <div>
              <p className="font-semibold text-slate-900">Maybe later</p>
              <p className="text-sm text-slate-600">Finish seller registration. You can register as a buyer anytime from your profile</p>
            </div>
          </label>
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="text-sm text-amber-900">
          <strong>Note:</strong> You can change this decision later. Access the buyer questionnaire anytime from your profile dashboard.
        </p>
      </div>
    </div>
  );
}
