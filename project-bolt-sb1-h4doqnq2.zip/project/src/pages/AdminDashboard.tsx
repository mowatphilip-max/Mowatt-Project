import { useState } from 'react';
import { useAdmin } from '../contexts/AdminContext';
import {
  Home, Users, Building, TrendingUp, LogOut, Menu, X,
  Bell, Settings, FileText, CheckCircle2, ClipboardList
} from 'lucide-react';
import { PropertiesManagement } from '../components/admin/PropertiesManagement';
import { BuyersManagement } from '../components/admin/BuyersManagement';
import { MatchesManagement } from '../components/admin/MatchesManagement';
import { DashboardOverview } from '../components/admin/DashboardOverview';
import { PendingApprovals } from '../components/admin/PendingApprovals';
import { SellerQuestionnairesManagement } from '../components/admin/SellerQuestionnairesManagement';

type TabType = 'overview' | 'properties' | 'buyers' | 'matches' | 'approvals' | 'questionnaires';

export function AdminDashboard() {
  const { admin, signOut } = useAdmin();
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const navigation = [
    { id: 'overview', name: 'Overview', icon: Home },
    { id: 'properties', name: 'Properties', icon: Building },
    { id: 'buyers', name: 'Buyers', icon: Users },
    { id: 'matches', name: 'Matches', icon: TrendingUp },
    { id: 'questionnaires', name: 'Seller Questionnaires', icon: ClipboardList },
    { id: 'approvals', name: 'Pending Approvals', icon: CheckCircle2 },
  ];

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors lg:hidden"
            >
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Mowatt's Matchlist</h1>
              <p className="text-sm text-slate-600">Admin Dashboard</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors relative">
              <Bell className="w-5 h-5 text-slate-600" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>

            <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
              <div className="text-right">
                <p className="text-sm font-semibold text-slate-900">{admin?.full_name}</p>
                <p className="text-xs text-slate-600 capitalize">{admin?.role.replace('_', ' ')}</p>
              </div>
              <button
                onClick={handleSignOut}
                className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors"
                title="Sign Out"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`fixed lg:sticky top-16 lg:top-0 left-0 h-[calc(100vh-4rem)] lg:h-screen bg-white border-r border-slate-200 transition-transform duration-300 z-30 ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          } w-64`}
        >
          <nav className="p-4 space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as TabType);
                    if (window.innerWidth < 1024) setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-all ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-lg'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {item.name}
                </button>
              );
            })}
          </nav>

          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-200">
            <div className="flex items-center gap-3 px-4 py-3 bg-slate-50 rounded-lg">
              <Settings className="w-5 h-5 text-slate-600" />
              <div className="flex-1">
                <p className="text-sm font-semibold text-slate-900">Settings</p>
                <p className="text-xs text-slate-600">Manage account</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 lg:p-8 overflow-auto">
          {activeTab === 'overview' && <DashboardOverview onNavigate={(tab) => setActiveTab(tab as TabType)} />}
          {activeTab === 'properties' && <PropertiesManagement />}
          {activeTab === 'buyers' && <BuyersManagement />}
          {activeTab === 'matches' && <MatchesManagement />}
          {activeTab === 'questionnaires' && <SellerQuestionnairesManagement />}
          {activeTab === 'approvals' && <PendingApprovals />}
        </main>
      </div>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
