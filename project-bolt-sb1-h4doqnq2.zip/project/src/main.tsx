import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { AdminProvider } from './contexts/AdminContext';
import { AuthProvider } from './contexts/AuthContext';
import { LegalFirmProvider } from './contexts/LegalFirmContext';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AdminProvider>
      <AuthProvider>
        <LegalFirmProvider>
          <App />
        </LegalFirmProvider>
      </AuthProvider>
    </AdminProvider>
  </StrictMode>
);
