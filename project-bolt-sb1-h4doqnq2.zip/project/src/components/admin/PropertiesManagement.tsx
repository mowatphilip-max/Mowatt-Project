export function PropertiesManagement() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Properties Management</h2>
      <p className="text-slate-600">Properties management interface coming soon.</p>
    </div>
  );
}
