export function PendingApprovals() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold text-slate-900 mb-4">Pending Approvals</h2>
      <p className="text-slate-600">Pending approvals interface coming soon.</p>
    </div>
  );
}
