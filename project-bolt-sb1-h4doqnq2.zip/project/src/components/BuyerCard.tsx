import { MapPin, Bed, Banknote, User, CheckCircle2 } from 'lucide-react';
import type { Buyer } from '../lib/supabase';

interface BuyerCardProps {
  buyer: Buyer;
  onRegisterInterest: (buyer: Buyer) => void;
}

export function BuyerCard({ buyer, onRegisterInterest }: BuyerCardProps) {
  const formatBudget = (min: number, max: number) => {
    const formatter = new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    });

    if (min === max) {
      return formatter.format(min);
    }
    return `${formatter.format(min)} - ${formatter.format(max)}`;
  };

  const formatBedrooms = () => {
    if (buyer.bedrooms_min === null || buyer.bedrooms_max === null) {
      return 'Flexible';
    }
    if (buyer.bedrooms_min === buyer.bedrooms_max) {
      return `${buyer.bedrooms_min}`;
    }
    return `${buyer.bedrooms_min}-${buyer.bedrooms_max}`;
  };

  const getPositionBadge = (position: string | null) => {
    if (!position) return null;

    const badgeStyles: { [key: string]: string } = {
      'Home currently up for sale with Mowatts Matchlist': 'bg-emerald-50 text-emerald-700 border-emerald-200',
      'Home under offer with Mowatts Matchlist': 'bg-amber-50 text-amber-700 border-amber-200',
      'Cash buyer - Nothing to sell': 'bg-blue-50 text-blue-700 border-blue-200',
    };

    return (
      <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-md border text-xs font-medium ${badgeStyles[position] || 'bg-mowatt-charcoal/5 text-mowatt-charcoal border-mowatt-sand'}`}>
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span className="line-clamp-1">{position}</span>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg overflow-hidden border border-mowatt-sand hover:shadow-2xl transition-all duration-500 group">
      <div className="relative h-40 bg-gradient-to-br from-mowatt-blue to-mowatt-blue-light flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(233,113,71,0.1),transparent)]"></div>
        <User className="w-16 h-16 text-white/80 group-hover:scale-110 transition-transform duration-500 relative z-10" />
        <div className="absolute top-4 right-4 bg-mowatt-orange/95 backdrop-blur-sm px-3 py-1.5 rounded-md shadow-lg">
          <span className="text-xs font-medium text-white">Active</span>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-4">
          {buyer.seeker_name}
        </h3>

        {buyer.buyer_position && (
          <div className="mb-4">
            {getPositionBadge(buyer.buyer_position)}
          </div>
        )}

        <div className="space-y-4 mb-5">
          <div className="flex items-start gap-3">
            <MapPin className="w-4 h-4 text-mowatt-orange mt-0.5 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-xs text-mowatt-charcoal/70 mb-1.5 uppercase tracking-wider font-medium">
                Looking In
              </p>
              <div className="flex flex-wrap gap-2">
                {buyer.area_preferences.slice(0, 3).map((area, index) => (
                  <span
                    key={index}
                    className="text-xs font-medium text-mowatt-orange bg-mowatt-orange/5 px-2.5 py-1 rounded-md border border-mowatt-orange/10"
                  >
                    {area}
                  </span>
                ))}
                {buyer.area_preferences.length > 3 && (
                  <span className="text-xs font-medium text-mowatt-charcoal/70 bg-mowatt-charcoal/5 px-2.5 py-1 rounded-md">
                    +{buyer.area_preferences.length - 3}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Bed className="w-4 h-4 text-mowatt-orange mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-xs text-mowatt-charcoal/70 mb-1 uppercase tracking-wider font-medium">
                Bedrooms
              </p>
              <p className="text-sm font-medium text-mowatt-charcoal">{formatBedrooms()}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Banknote className="w-4 h-4 text-mowatt-orange mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-xs text-mowatt-charcoal/70 mb-1 uppercase tracking-wider font-medium">
                Budget
              </p>
              <p className="text-sm font-medium text-mowatt-charcoal">
                {formatBudget(buyer.budget_min, buyer.budget_max)}
              </p>
            </div>
          </div>
        </div>

        <div className="pt-5 border-t border-mowatt-sand/50">
          <p className="text-xs text-mowatt-charcoal/70 mb-2 uppercase tracking-wider font-medium">
            Property Type
          </p>
          <p className="text-sm font-medium text-mowatt-charcoal mb-5">
            {buyer.looking_for}
          </p>

          <button
            onClick={() => onRegisterInterest(buyer)}
            className="w-full bg-mowatt-orange hover:bg-mowatt-orange-dark text-white px-4 py-2.5 rounded-md font-medium text-sm transition-all duration-200"
          >
            Express Interest
          </button>
        </div>
      </div>
    </div>
  );
}
