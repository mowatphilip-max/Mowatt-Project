import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Scale, CheckCircle, Info, AlertCircle } from 'lucide-react';

interface LegalFirm {
  id: string;
  firm_name: string;
  contact_name: string;
  email: string;
  phone: string;
}

interface LegalPricing {
  id: string;
  legal_firm_id: string;
  service_type: 'buying' | 'selling';
  price_min: number;
  price_max: number;
  conveyancing_fee: number;
  mowatt_charge: number;
  total_deposit_required: number;
}

interface LegalServicesSelectorProps {
  serviceType: 'buying' | 'selling';
  propertyValue?: number;
  onSelect?: (firmId: string, pricing: LegalPricing | null) => void;
  selectedFirmId?: string;
}

export function LegalServicesSelector({
  serviceType,
  propertyValue,
  onSelect,
  selectedFirmId
}: LegalServicesSelectorProps) {
  const [legalFirms, setLegalFirms] = useState<LegalFirm[]>([]);
  const [pricing, setPricing] = useState<{ [firmId: string]: LegalPricing[] }>({});
  const [loading, setLoading] = useState(true);
  const [wantsLegal, setWantsLegal] = useState<string>('');
  const [selectedFirm, setSelectedFirm] = useState<string>(selectedFirmId || '');
  const [estimatedValue, setEstimatedValue] = useState<number>(propertyValue || 0);

  useEffect(() => {
    fetchLegalFirms();
  }, []);

  useEffect(() => {
    if (legalFirms.length > 0) {
      fetchPricing();
    }
  }, [legalFirms, serviceType]);

  const fetchLegalFirms = async () => {
    try {
      const { data, error } = await supabase
        .from('legal_firms')
        .select('*')
        .eq('is_active', true)
        .eq('is_verified', true);

      if (error) throw error;
      setLegalFirms(data || []);
    } catch (error) {
      console.error('Error fetching legal firms:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPricing = async () => {
    try {
      const firmIds = legalFirms.map(f => f.id);
      const { data, error } = await supabase
        .from('legal_pricing')
        .select('*')
        .in('legal_firm_id', firmIds)
        .eq('service_type', serviceType)
        .order('price_min', { ascending: true });

      if (error) throw error;

      const pricingByFirm: { [firmId: string]: LegalPricing[] } = {};
      (data || []).forEach(p => {
        if (!pricingByFirm[p.legal_firm_id]) {
          pricingByFirm[p.legal_firm_id] = [];
        }
        pricingByFirm[p.legal_firm_id].push(p);
      });

      setPricing(pricingByFirm);
    } catch (error) {
      console.error('Error fetching pricing:', error);
    }
  };

  const getQuoteForValue = (firmId: string, value: number): LegalPricing | null => {
    const firmPricing = pricing[firmId] || [];
    return firmPricing.find(p => value >= p.price_min && value <= p.price_max) || null;
  };

  const handleFirmSelect = (firmId: string) => {
    setSelectedFirm(firmId);
    const quote = estimatedValue > 0 ? getQuoteForValue(firmId, estimatedValue) : null;
    onSelect?.(firmId, quote);
  };

  const selectedQuote = selectedFirm && estimatedValue > 0
    ? getQuoteForValue(selectedFirm, estimatedValue)
    : null;

  const serviceTypeLabel = serviceType === 'buying' ? 'Purchase' : 'Sale';

  if (loading) {
    return <div className="text-center py-8 text-slate-600">Loading legal services...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-slate-50 to-blue-50 border-2 border-slate-200 rounded-xl p-6">
        <div className="flex items-start gap-3 mb-4">
          <Scale className="w-8 h-8 text-blue-600 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">
              {serviceType === 'buying' ? 'Buying' : 'Selling'} Conveyancing Services
            </h3>
            <p className="text-slate-700 text-sm">
              {serviceType === 'buying'
                ? 'Let us arrange a solicitor to handle your property purchase conveyancing.'
                : 'Let us arrange a solicitor to handle your property sale conveyancing.'}
            </p>
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 mb-4">
          <div className="flex items-start gap-2">
            <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-slate-700">
              <p className="font-semibold mb-1">How it works:</p>
              <ul className="space-y-1 list-disc list-inside">
                <li>Choose a legal firm from our verified partners</li>
                <li>Pay a 20% deposit to secure your solicitor</li>
                <li>Your solicitor will contact you within 24 hours</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <label className="block text-lg font-semibold text-slate-900">
          Would you like legal conveyancing services for this {serviceTypeLabel.toLowerCase()}?
        </label>

        <div className="space-y-3">
          <label className="flex items-center gap-4 p-4 border-2 border-slate-200 rounded-xl cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all">
            <input
              type="radio"
              name="wantsLegal"
              value="yes"
              checked={wantsLegal === 'yes'}
              onChange={(e) => setWantsLegal(e.target.value)}
              className="w-5 h-5 text-blue-600"
            />
            <div>
              <p className="font-semibold text-slate-900">Yes, arrange legal services</p>
              <p className="text-sm text-slate-600">Get a solicitor through our platform</p>
            </div>
          </label>

          <label className="flex items-center gap-4 p-4 border-2 border-slate-200 rounded-xl cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all">
            <input
              type="radio"
              name="wantsLegal"
              value="no"
              checked={wantsLegal === 'no'}
              onChange={(e) => setWantsLegal(e.target.value)}
              className="w-5 h-5 text-blue-600"
            />
            <div>
              <p className="font-semibold text-slate-900">No, I have my own solicitor</p>
              <p className="text-sm text-slate-600">I understand. Let us arrange a discounted fee for handling your {serviceType === 'buying' ? 'Buying' : 'Selling'} Conveyancing services.</p>
            </div>
          </label>
        </div>
      </div>

      {wantsLegal === 'yes' && (
        <>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Estimated Property Value *
            </label>
            <div className="relative">
              <span className="absolute left-4 top-3.5 text-slate-600">£</span>
              <input
                type="number"
                value={estimatedValue || ''}
                onChange={(e) => setEstimatedValue(parseFloat(e.target.value) || 0)}
                className="w-full pl-8 pr-4 py-3 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="e.g., 250000"
                required
              />
            </div>
            <p className="text-sm text-slate-600 mt-1">
              Enter the {serviceType === 'buying' ? 'purchase' : 'sale'} price to see accurate legal fees
            </p>
          </div>

          {estimatedValue > 0 && (
            <div>
              <h4 className="text-lg font-semibold text-slate-900 mb-3">Select a Legal Firm</h4>
              <div className="space-y-3">
                {legalFirms.map((firm) => {
                  const quote = getQuoteForValue(firm.id, estimatedValue);
                  const isSelected = selectedFirm === firm.id;

                  return (
                    <div
                      key={firm.id}
                      onClick={() => quote && handleFirmSelect(firm.id)}
                      className={`p-5 border-2 rounded-xl cursor-pointer transition-all ${
                        isSelected
                          ? 'border-blue-500 bg-blue-50 shadow-md'
                          : quote
                          ? 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
                          : 'border-slate-100 bg-slate-50 opacity-60 cursor-not-allowed'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h5 className="text-lg font-bold text-slate-900">{firm.firm_name}</h5>
                            {isSelected && <CheckCircle className="w-5 h-5 text-blue-600" />}
                          </div>
                          <p className="text-sm text-slate-600 mb-3">Contact: {firm.contact_name}</p>

                          {quote ? (
                            <div className="grid grid-cols-2 gap-4 bg-white rounded-lg p-4">
                              <div>
                                <p className="text-xs text-slate-600 mb-1">Conveyancing Fee</p>
                                <p className="text-xl font-bold text-slate-900">
                                  £{quote.conveyancing_fee.toLocaleString()}
                                </p>
                              </div>
                              <div>
                                <p className="text-xs text-slate-600 mb-1">Platform Fee (20%)</p>
                                <p className="text-xl font-bold text-blue-600">
                                  £{quote.mowatt_charge.toLocaleString()}
                                </p>
                              </div>
                              <div className="col-span-2 pt-3 border-t border-slate-200">
                                <p className="text-xs text-slate-600 mb-1">Deposit Required (20% of fee)</p>
                                <p className="text-2xl font-bold text-green-600">
                                  £{quote.total_deposit_required.toLocaleString()}
                                </p>
                                <p className="text-xs text-slate-500 mt-1">
                                  Pay this deposit to secure your solicitor
                                </p>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 text-sm text-slate-500">
                              <AlertCircle className="w-4 h-4" />
                              <span>No pricing available for this property value</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {selectedQuote && (
            <div className="bg-green-50 border-2 border-green-200 rounded-xl p-5">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-lg font-bold text-green-900 mb-2">Legal Services Selected</h4>
                  <p className="text-sm text-green-800 mb-3">
                    You'll be prompted to pay the £{selectedQuote.total_deposit_required.toLocaleString()} deposit
                    after completing this questionnaire.
                  </p>
                  <div className="bg-white rounded-lg p-3 text-sm text-slate-700">
                    <p><strong>What happens next:</strong></p>
                    <ol className="list-decimal list-inside space-y-1 mt-2">
                      <li>Complete and submit your questionnaire</li>
                      <li>Pay the 20% deposit (£{selectedQuote.total_deposit_required.toLocaleString()})</li>
                      <li>Your solicitor will contact you within 24 hours</li>
                      <li>They'll guide you through the conveyancing process</li>
                    </ol>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {wantsLegal === 'no' && (
        <div className="bg-slate-50 border-2 border-slate-200 rounded-xl p-5">
          <p className="text-slate-700">
            No problem! You can arrange your own legal services or add this later from your profile.
          </p>
        </div>
      )}
    </div>
  );
}
