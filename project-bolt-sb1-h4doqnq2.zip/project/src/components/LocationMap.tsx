import { useState } from 'react';
import { MapContainer, TileLayer, Circle as LeafletCircle, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { MapPin, Trash2 } from 'lucide-react';
import L from 'leaflet';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface Circle {
  id: string;
  lat: number;
  lng: number;
  radius: number;
  label?: string;
}

interface LocationMapProps {
  circles: Circle[];
  onCirclesChange: (circles: Circle[]) => void;
  center?: [number, number];
}

function MapClickHandler({
  isDrawing,
  onAddCircle,
  onDrawingComplete
}: {
  isDrawing: boolean;
  onAddCircle: (lat: number, lng: number) => void;
  onDrawingComplete: () => void;
}) {
  useMapEvents({
    click: (e) => {
      if (isDrawing) {
        onAddCircle(e.latlng.lat, e.latlng.lng);
        onDrawingComplete();
      }
    },
  });
  return null;
}

export function LocationMap({ circles, onCirclesChange, center = [55.9533, -3.1883] }: LocationMapProps) {
  const [isDrawing, setIsDrawing] = useState(false);

  const addCircle = (lat: number, lng: number) => {
    const newCircle: Circle = {
      id: crypto.randomUUID(),
      lat,
      lng,
      radius: 3000,
    };
    onCirclesChange([...circles, newCircle]);
  };

  const removeCircle = (id: string) => {
    onCirclesChange(circles.filter((c) => c.id !== id));
  };

  const updateCircleRadius = (id: string, radius: number) => {
    onCirclesChange(
      circles.map((c) => (c.id === id ? { ...c, radius } : c))
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-slate-700" />
          <h3 className="font-semibold text-slate-900">Select Your Preferred Areas</h3>
        </div>
        <button
          type="button"
          onClick={() => setIsDrawing(!isDrawing)}
          className={`px-4 py-2 rounded-lg font-medium transition-all ${
            isDrawing
              ? 'bg-slate-900 text-white'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          {isDrawing ? 'Click on map to place circle' : 'Add Area'}
        </button>
      </div>

      <div
        className={`w-full h-96 rounded-lg border-2 overflow-hidden ${
          isDrawing ? 'border-slate-900 border-dashed' : 'border-slate-200'
        }`}
        style={{
          cursor: isDrawing ? 'crosshair' : 'default'
        }}
      >
        <MapContainer
          center={center}
          zoom={11}
          style={{ height: '100%', width: '100%' }}
          zoomControl={true}
          scrollWheelZoom={true}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapClickHandler
            isDrawing={isDrawing}
            onAddCircle={addCircle}
            onDrawingComplete={() => setIsDrawing(false)}
          />
          {circles.map((circle) => (
            <LeafletCircle
              key={circle.id}
              center={[circle.lat, circle.lng]}
              radius={circle.radius}
              pathOptions={{
                color: '#1e293b',
                fillColor: '#64748b',
                fillOpacity: 0.3,
                weight: 2,
              }}
            />
          ))}
        </MapContainer>
      </div>

      {circles.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium text-slate-900">Selected Areas ({circles.length})</h4>
          <div className="space-y-2">
            {circles.map((circle, index) => (
              <div
                key={circle.id}
                className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200"
              >
                <div className="flex-1">
                  <p className="font-medium text-slate-900">Area {index + 1}</p>
                  <p className="text-sm text-slate-600">
                    {circle.lat.toFixed(4)}, {circle.lng.toFixed(4)}
                  </p>
                  <div className="mt-2">
                    <label className="text-sm text-slate-700">
                      Radius: {(circle.radius / 1000).toFixed(1)}km
                    </label>
                    <input
                      type="range"
                      min="1000"
                      max="10000"
                      step="500"
                      value={circle.radius}
                      onChange={(e) =>
                        updateCircleRadius(circle.id, parseInt(e.target.value))
                      }
                      className="w-full mt-1"
                    />
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => removeCircle(circle.id)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {circles.length === 0 && (
        <div className="text-center py-8 text-slate-500">
          <MapPin className="w-12 h-12 mx-auto mb-2 opacity-20" />
          <p>Click "Add Area" then click on the map to select your preferred locations</p>
        </div>
      )}
    </div>
  );
}
