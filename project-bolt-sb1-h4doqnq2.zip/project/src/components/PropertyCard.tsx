import { MapPin, Bed, Bath, Maximize, Calendar, BadgeCheck } from 'lucide-react';
import type { Property } from '../lib/supabase';

interface PropertyCardProps {
  property: Property;
  onRegisterInterest: (property: Property) => void;
  matchScore?: number;
  onRequestViewing?: (property: Property) => void;
}

export function PropertyCard({ property, onRegisterInterest, matchScore, onRequestViewing }: PropertyCardProps) {
  const formatPrice = (min: number, max: number) => {
    const formatter = new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0,
    });

    if (min === max) {
      return formatter.format(min);
    }
    return `${formatter.format(min)} - ${formatter.format(max)}`;
  };

  return (
    <div className="bg-white rounded-lg overflow-hidden border border-mowatt-sand hover:shadow-2xl transition-all duration-500 group">
      <div className="relative h-64 overflow-hidden bg-mowatt-charcoal/5">
        {property.image_url ? (
          <>
            <img
              src={property.image_url}
              alt={property.title}
              className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          </>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-mowatt-charcoal/5 to-mowatt-sand/30">
            <MapPin className="w-16 h-16 text-mowatt-charcoal/20" />
          </div>
        )}

        <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm px-3 py-1.5 rounded-md shadow-lg">
          <span className="text-xs font-medium text-mowatt-charcoal">{property.area_name}</span>
        </div>

        {property.is_verified && (
          <div className="absolute top-4 right-4 bg-mowatt-orange/95 backdrop-blur-sm px-3 py-1.5 rounded-md shadow-lg flex items-center gap-1.5">
            <BadgeCheck className="w-3.5 h-3.5 text-white" />
            <span className="text-xs font-medium text-white">Verified</span>
          </div>
        )}

        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-white/95 backdrop-blur-md px-4 py-2 rounded-md shadow-lg">
            <span className="text-sm font-medium text-mowatt-charcoal">{property.property_type}</span>
          </div>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-serif font-medium text-mowatt-blue mb-4 line-clamp-2 leading-snug">
          {property.title}
        </h3>

        <div className="flex items-center gap-5 mb-5 pb-5 border-b border-mowatt-sand/50">
          <div className="flex items-center text-mowatt-charcoal/70">
            <Bed className="w-4 h-4 mr-1.5 text-mowatt-orange" />
            <span className="text-sm">{property.bedrooms}</span>
          </div>
          <div className="flex items-center text-mowatt-charcoal/70">
            <Bath className="w-4 h-4 mr-1.5 text-mowatt-orange" />
            <span className="text-sm">{property.bathrooms}</span>
          </div>
          {property.square_feet && (
            <div className="flex items-center text-mowatt-charcoal/70">
              <Maximize className="w-4 h-4 mr-1.5 text-mowatt-orange" />
              <span className="text-sm">{property.square_feet.toLocaleString()} ft²</span>
            </div>
          )}
        </div>

        <p className="text-mowatt-charcoal/70 text-sm mb-5 line-clamp-3 leading-relaxed">
          {property.description}
        </p>

        {property.key_features.length > 0 && (
          <div className="mb-5">
            <div className="flex flex-wrap gap-2">
              {property.key_features.slice(0, 3).map((feature, index) => (
                <span
                  key={index}
                  className="text-xs bg-mowatt-orange/5 text-mowatt-orange-dark px-3 py-1 rounded-md font-medium border border-mowatt-orange/10"
                >
                  {feature}
                </span>
              ))}
              {property.key_features.length > 3 && (
                <span className="text-xs bg-mowatt-charcoal/5 text-mowatt-charcoal/70 px-3 py-1 rounded-md font-medium">
                  +{property.key_features.length - 3}
                </span>
              )}
            </div>
          </div>
        )}

        <div className="mb-5">
          <p className="text-xs text-mowatt-charcoal/70 mb-1.5 font-medium uppercase tracking-wider">
            Asking Price
          </p>
          <p className="text-2xl font-serif font-medium text-mowatt-blue">
            {formatPrice(property.price_min, property.price_max)}
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => onRegisterInterest(property)}
            className="flex-1 bg-mowatt-orange hover:bg-mowatt-orange-dark text-white px-4 py-2.5 rounded-md font-medium text-sm transition-all duration-200"
          >
            View Details
          </button>
          {onRequestViewing && (
            <button
              onClick={() => onRequestViewing(property)}
              className="flex items-center justify-center gap-2 bg-mowatt-blue hover:bg-mowatt-blue-dark text-white px-4 py-2.5 rounded-md font-medium text-sm transition-all duration-200"
            >
              <Calendar className="w-4 h-4" />
              <span className="hidden sm:inline">View</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
