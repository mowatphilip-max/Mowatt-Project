import { X, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Property, Buyer } from '../lib/supabase';

interface RegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: Property | Buyer | null;
  type: 'property' | 'buyer';
}

export function RegistrationModal({ isOpen, onClose, item, type }: RegistrationModalProps) {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    commissionAgreed: false,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen || !item) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { error } = await supabase.from('registrations').insert({
        full_name: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        interested_in_type: type,
        interested_in_id: item.id,
        commission_agreed: formData.commissionAgreed,
        commission_percentage: 1.0,
        agreement_date: formData.commissionAgreed ? new Date().toISOString() : null,
      });

      if (error) throw error;

      setSubmitted(true);
    } catch (error) {
      console.error('Error submitting registration:', error);
      alert('Failed to submit registration. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setFormData({ fullName: '', email: '', phone: '', commissionAgreed: false });
    setSubmitted(false);
    onClose();
  };

  const itemTitle = type === 'property'
    ? (item as Property).title
    : (item as Buyer).seeker_name;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-slate-900">Register Your Interest</h2>
          <button
            onClick={handleClose}
            className="text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900 font-medium mb-2">
                You're interested in: <span className="font-bold">{itemTitle}</span>
              </p>
              <p className="text-xs text-blue-700">
                Complete the form below to unlock full details and connect with {type === 'property' ? 'the seller' : 'this buyer'}.
              </p>
            </div>

            <div>
              <label htmlFor="fullName" className="block text-sm font-semibold text-slate-700 mb-2">
                Full Name *
              </label>
              <input
                type="text"
                id="fullName"
                required
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="John Smith"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-slate-700 mb-2">
                Email Address *
              </label>
              <input
                type="email"
                id="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="john@example.com"
              />
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-semibold text-slate-700 mb-2">
                Phone Number *
              </label>
              <input
                type="tel"
                id="phone"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="+44 7700 900000"
              />
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-lg p-6">
              <h3 className="text-lg font-bold text-slate-900 mb-3">Commission Agreement</h3>
              <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                By registering, you agree to pay Mowatt a <strong>1% commission</strong> of the {type === 'property' ? 'purchase price' : 'sale price'}
                if this match leads to a successful transaction. This significantly lower fee compared to traditional estate agents
                (typically 1.5-3%) helps keep more money in your pocket.
              </p>

              <label className="flex items-start space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={formData.commissionAgreed}
                  onChange={(e) => setFormData({ ...formData, commissionAgreed: e.target.checked })}
                  className="mt-1 w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="text-sm text-slate-700">
                  I agree to pay a 1% commission to Mowatt upon successful completion of this transaction *
                </span>
              </label>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={handleClose}
                className="flex-1 px-6 py-3 border border-gray-300 text-slate-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || !formData.commissionAgreed}
                className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors shadow-md hover:shadow-lg"
              >
                {isSubmitting ? 'Submitting...' : 'Register Interest'}
              </button>
            </div>
          </form>
        ) : (
          <div className="p-8 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
              <CheckCircle2 className="w-12 h-12 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-3">Registration Successful!</h3>
            <p className="text-slate-600 mb-6 max-w-md mx-auto">
              Thank you for registering. Our team will review your request and contact you within 24 hours with full details and next steps.
            </p>
            <button
              onClick={handleClose}
              className="px-8 py-3 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 transition-colors shadow-md"
            >
              Close
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
