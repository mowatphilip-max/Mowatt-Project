import { useState } from 'react';
import { X, Calendar, Clock, MessageSquare, Send } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import type { Property } from '../lib/supabase';

interface ViewingRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  property: Property;
}

export function ViewingRequestModal({ isOpen, onClose, property }: ViewingRequestModalProps) {
  const { user } = useAuth();
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTime, setPreferredTime] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    try {
      const { data: insertedRequest, error } = await supabase
        .from('viewing_requests')
        .insert({
          user_id: user.id,
          property_id: property.id,
          preferred_date: preferredDate ? new Date(preferredDate).toISOString() : null,
          preferred_time: preferredTime,
          message: message,
          status: 'pending',
        })
        .select()
        .single();

      if (error) throw error;

      const { data: userData } = await supabase
        .from('user_profiles')
        .select('email, full_name')
        .eq('id', user.id)
        .single();

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-email`;
      const headers = {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };

      const formattedDate = new Date(preferredDate).toLocaleDateString('en-GB', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });

      const timeSlotMap: Record<string, string> = {
        morning: '9am - 12pm',
        afternoon: '12pm - 5pm',
        evening: '5pm - 7pm'
      };

      const emailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #1e40af;">Viewing Request Confirmation</h2>
          <p>Hi ${userData?.full_name || 'there'},</p>
          <p>Thank you for requesting a viewing for <strong>${property.title}</strong> in ${property.area_name}.</p>

          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #1f2937;">Viewing Details</h3>
            <p><strong>Property:</strong> ${property.title}</p>
            <p><strong>Location:</strong> ${property.area_name}</p>
            <p><strong>Preferred Date:</strong> ${formattedDate}</p>
            <p><strong>Preferred Time:</strong> ${timeSlotMap[preferredTime]}</p>
            ${message ? `<p><strong>Your Message:</strong> ${message}</p>` : ''}
          </div>

          <p>Our team will review your request and contact you within 24 hours to confirm the viewing time.</p>
          <p>If you have any questions in the meantime, please don't hesitate to reach out.</p>

          <p>Best regards,<br>The Matchlist Team</p>
        </div>
      `;

      if (userData?.email) {
        await fetch(apiUrl, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            to: userData.email,
            subject: `Viewing Request Confirmation - ${property.title}`,
            html: emailHtml,
          }),
        });
      }

      alert('Viewing request submitted successfully! Check your email for confirmation.');
      onClose();
      setPreferredDate('');
      setPreferredTime('');
      setMessage('');
    } catch (error: any) {
      alert(`Error submitting request: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const minDate = new Date().toISOString().split('T')[0];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-8 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="mb-6">
          <h2 className="text-3xl font-bold text-slate-900 mb-2">Request a Viewing</h2>
          <p className="text-slate-600">
            {property.title} - {property.area_name}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              <Calendar className="inline w-4 h-4 mr-2" />
              Preferred Date
            </label>
            <input
              type="date"
              value={preferredDate}
              onChange={(e) => setPreferredDate(e.target.value)}
              min={minDate}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              <Clock className="inline w-4 h-4 mr-2" />
              Preferred Time
            </label>
            <select
              value={preferredTime}
              onChange={(e) => setPreferredTime(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="">Select a time</option>
              <option value="morning">Morning (9am - 12pm)</option>
              <option value="afternoon">Afternoon (12pm - 5pm)</option>
              <option value="evening">Evening (5pm - 7pm)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              <MessageSquare className="inline w-4 h-4 mr-2" />
              Additional Message (Optional)
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Any specific questions or requirements for the viewing..."
            />
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              <strong>Note:</strong> Your viewing request will be reviewed by our team. We'll contact you within 24 hours to confirm the viewing time.
            </p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-500 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-600 transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              'Submitting...'
            ) : (
              <>
                <Send className="w-5 h-5" />
                Submit Request
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
