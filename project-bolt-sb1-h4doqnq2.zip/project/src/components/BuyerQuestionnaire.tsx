import { useState, useMemo, useCallback } from 'react';
import { Home, MapPin, DollarSign, Bed, CheckCircle, X, Users, Scale } from 'lucide-react';
import { LocationMap } from './LocationMap';
import { getTownsInCircles } from '../utils/geoUtils';
import { LegalServicesSelector } from './LegalServicesSelector';

interface BuyerQuestionnaireProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: BuyerQuestionnaireData, legalData?: { firmId: string; quote: any }) => void;
}

export interface BuyerQuestionnaireData {
  seeker_name: string;
  email: string;
  phone: string;
  property_type: string[];
  bedrooms_min: number | null;
  bedrooms_max: number | null;
  bathrooms_min: number | null;
  budget_min: number;
  budget_max: number;
  area_preferences: string[];
  street_preferences: { [town: string]: string[] };
  location_circles: Array<{ id: string; lat: number; lng: number; radius: number; label?: string }>;
  must_haves: string[];
  outdoor_space: string[];
  parking: string[];
  property_condition: string;
  timeline: string;
  buyer_position: string;
  additional_requirements: string;
  list_in_quiet_seekers: boolean;
  commission_agreed: boolean;
  opt_out_communication?: boolean;
}

const TOWN_STREETS: { [key: string]: string[] } = {
  'North Berwick': [
    'High Street',
    'Quality Street',
    'Forth Street',
    'Westgate',
    'Melbourne Road',
    'Dirleton Avenue',
    'Beach Road',
    'St Baldred\'s Road',
    'Law Road',
    'Hamilton Road',
    'Tantallon Road',
    'Glenorchy Road',
    'Victoria Road',
    'Rhodes Avenue',
    'Abbotsford Park',
  ],
  'Gullane': [
    'Main Street',
    'West Links Road',
    'East Links Road',
    'Sandy Loan',
    'Saltcoats Road',
    'Muirfield Drive',
    'Greywalls Road',
    'Goose Green',
    'Rosebery Avenue',
    'Bisset Avenue',
  ],
  'East Linton': [
    'High Street',
    'Bridge Street',
    'Station Road',
    'The Glebe',
    'Samuelston Road',
    'Hailes Gardens',
    'Preston Road',
    'Mill Wynd',
  ],
  'Aberlady': [
    'Main Street',
    'Kilspindie Road',
    'High Street',
    'Luffness Road',
    'Haddington Road',
    'The Wynd',
  ],
  'Longniddry': [
    'Main Street',
    'Links Road',
    'Station Road',
    'Elcho Terrace',
    'Gosford Road',
    'Marine Parade',
  ],
};

export function BuyerQuestionnaire({ isOpen, onClose, onSubmit }: BuyerQuestionnaireProps) {
  const [step, setStep] = useState(1);
  const [customStreetInputs, setCustomStreetInputs] = useState<{ [town: string]: string }>({});
  const [legalFirmId, setLegalFirmId] = useState<string>('');
  const [legalQuote, setLegalQuote] = useState<any>(null);
  const [formData, setFormData] = useState<BuyerQuestionnaireData>({
    seeker_name: '',
    email: '',
    phone: '',
    property_type: [],
    bedrooms_min: null,
    bedrooms_max: null,
    bathrooms_min: null,
    budget_min: 0,
    budget_max: 0,
    area_preferences: [],
    street_preferences: {},
    location_circles: [],
    must_haves: [],
    outdoor_space: [],
    parking: [],
    property_condition: '',
    timeline: '',
    buyer_position: '',
    additional_requirements: '',
    list_in_quiet_seekers: false,
    commission_agreed: false,
  });

  const totalSteps = 11;

  const availableTowns = useMemo(() => {
    const townsInCircles = getTownsInCircles(formData.location_circles);
    return Object.keys(TOWN_STREETS).filter((town) => townsInCircles.includes(town));
  }, [formData.location_circles]);

  const handleCirclesChange = useCallback((circles: any) => {
    setFormData((prev) => ({ ...prev, location_circles: circles }));
  }, []);

  if (!isOpen) return null;

  const handleNext = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = () => {
    const legalData = legalFirmId && legalQuote ? { firmId: legalFirmId, quote: legalQuote } : undefined;
    onSubmit(formData, legalData);
  };

  const toggleArrayValue = (field: keyof BuyerQuestionnaireData, value: string) => {
    const currentArray = formData[field] as string[];
    if (currentArray.includes(value)) {
      setFormData({ ...formData, [field]: currentArray.filter(v => v !== value) });
    } else {
      setFormData({ ...formData, [field]: [...currentArray, value] });
    }
  };

  const toggleStreetPreference = (town: string, street: string) => {
    const currentStreets = formData.street_preferences[town] || [];
    if (currentStreets.includes(street)) {
      setFormData({
        ...formData,
        street_preferences: {
          ...formData.street_preferences,
          [town]: currentStreets.filter(s => s !== street),
        },
      });
    } else {
      setFormData({
        ...formData,
        street_preferences: {
          ...formData.street_preferences,
          [town]: [...currentStreets, street],
        },
      });
    }
  };

  const addCustomStreet = (town: string) => {
    const customStreet = customStreetInputs[town]?.trim();
    if (!customStreet) return;

    const currentStreets = formData.street_preferences[town] || [];
    if (!currentStreets.includes(customStreet)) {
      setFormData({
        ...formData,
        street_preferences: {
          ...formData.street_preferences,
          [town]: [...currentStreets, customStreet],
        },
      });
    }

    setCustomStreetInputs({ ...customStreetInputs, [town]: '' });
  };

  const removeCustomStreet = (town: string, street: string) => {
    const currentStreets = formData.street_preferences[town] || [];
    setFormData({
      ...formData,
      street_preferences: {
        ...formData.street_preferences,
        [town]: currentStreets.filter(s => s !== street),
      },
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 rounded-t-2xl">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-900">Quiet Seeker Registration</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="flex items-center gap-2">
            {Array.from({ length: totalSteps }).map((_, i) => (
              <div
                key={i}
                className={`flex-1 h-2 rounded-full transition-all ${
                  i + 1 <= step ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              />
            ))}
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Step {step} of {totalSteps}
          </p>
        </div>

        <div className="p-6">
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Contact Information</h3>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={formData.seeker_name}
                  onChange={(e) => setFormData({ ...formData, seeker_name: e.target.value })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="John Smith"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="07700 900000"
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Budget Range *</h3>
              <p className="text-gray-600 mb-4">What is your budget for purchasing a property?</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Minimum Budget (£)
                  </label>
                  <select
                    value={formData.budget_min || ''}
                    onChange={(e) => setFormData({ ...formData, budget_min: parseInt(e.target.value) || 0 })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select minimum...</option>
                    <option value="100000">£100,000</option>
                    <option value="150000">£150,000</option>
                    <option value="200000">£200,000</option>
                    <option value="250000">£250,000</option>
                    <option value="300000">£300,000</option>
                    <option value="350000">£350,000</option>
                    <option value="400000">£400,000</option>
                    <option value="450000">£450,000</option>
                    <option value="500000">£500,000</option>
                    <option value="550000">£550,000</option>
                    <option value="600000">£600,000</option>
                    <option value="650000">£650,000</option>
                    <option value="700000">£700,000</option>
                    <option value="750000">£750,000</option>
                    <option value="800000">£800,000</option>
                    <option value="850000">£850,000</option>
                    <option value="900000">£900,000</option>
                    <option value="950000">£950,000</option>
                    <option value="1000000">£1,000,000</option>
                    <option value="1250000">£1,250,000</option>
                    <option value="1500000">£1,500,000</option>
                    <option value="2000000">£2,000,000+</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Maximum Budget (£)
                  </label>
                  <select
                    value={formData.budget_max || ''}
                    onChange={(e) => setFormData({ ...formData, budget_max: parseInt(e.target.value) || 0 })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select maximum...</option>
                    <option value="150000">£150,000</option>
                    <option value="200000">£200,000</option>
                    <option value="250000">£250,000</option>
                    <option value="300000">£300,000</option>
                    <option value="350000">£350,000</option>
                    <option value="400000">£400,000</option>
                    <option value="450000">£450,000</option>
                    <option value="500000">£500,000</option>
                    <option value="550000">£550,000</option>
                    <option value="600000">£600,000</option>
                    <option value="650000">£650,000</option>
                    <option value="700000">£700,000</option>
                    <option value="750000">£750,000</option>
                    <option value="800000">£800,000</option>
                    <option value="850000">£850,000</option>
                    <option value="900000">£900,000</option>
                    <option value="950000">£950,000</option>
                    <option value="1000000">£1,000,000</option>
                    <option value="1250000">£1,250,000</option>
                    <option value="1500000">£1,500,000</option>
                    <option value="2000000">£2,000,000</option>
                    <option value="3000000">£3,000,000+</option>
                  </select>
                </div>
              </div>
              {formData.budget_min > 0 && formData.budget_max > 0 && (
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-blue-900 font-semibold">
                    Budget Range: £{formData.budget_min.toLocaleString()} - £{formData.budget_max.toLocaleString()}
                  </p>
                </div>
              )}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Property Type *</h3>
              <p className="text-gray-600 mb-4">What type of property are you looking for? (Select all that apply)</p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {['Detached House', 'Semi-Detached House', 'Terraced House', 'Bungalow', 'Flat/Apartment', 'Cottage'].map((type) => (
                  <button
                    key={type}
                    onClick={() => toggleArrayValue('property_type', type)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      formData.property_type.includes(type)
                        ? 'border-blue-600 bg-blue-50 text-blue-900'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">{type}</span>
                      {formData.property_type.includes(type) && (
                        <CheckCircle className="w-5 h-5 text-blue-600" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Bedrooms & Bathrooms</h3>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Minimum Bedrooms
                  </label>
                  <select
                    value={formData.bedrooms_min || ''}
                    onChange={(e) => setFormData({ ...formData, bedrooms_min: e.target.value ? parseInt(e.target.value) : null })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Any</option>
                    {[1, 2, 3, 4, 5, 6].map((num) => (
                      <option key={num} value={num}>{num}+</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Maximum Bedrooms
                  </label>
                  <select
                    value={formData.bedrooms_max || ''}
                    onChange={(e) => setFormData({ ...formData, bedrooms_max: e.target.value ? parseInt(e.target.value) : null })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Any</option>
                    {[1, 2, 3, 4, 5, 6].map((num) => (
                      <option key={num} value={num}>{num}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Minimum Bathrooms
                </label>
                <select
                  value={formData.bathrooms_min || ''}
                  onChange={(e) => setFormData({ ...formData, bathrooms_min: e.target.value ? parseInt(e.target.value) : null })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Any</option>
                  {[1, 2, 3, 4].map((num) => (
                    <option key={num} value={num}>{num}+</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Select Your Preferred Areas</h3>
              <p className="text-gray-600 mb-4">Draw circles on the map to show where you'd like to live</p>
              <LocationMap
                circles={formData.location_circles}
                onCirclesChange={handleCirclesChange}
                center={[55.9533, -3.1883]}
              />
              <p className="text-sm text-slate-600">
                Click "Add Area" to place circles on areas where you'd like to find a home. You can adjust the radius of each circle and add multiple areas.
              </p>
            </div>
          )}

          {step === 6 && (
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Town Selection *</h3>
              {formData.location_circles.length === 0 ? (
                <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6 text-center">
                  <MapPin className="w-12 h-12 mx-auto mb-3 text-blue-400" />
                  <p className="text-blue-900 font-semibold mb-2">No areas selected on the map</p>
                  <p className="text-blue-700 text-sm">All towns will be shown. Go back to select specific areas on the map to filter towns.</p>
                </div>
              ) : (
                <p className="text-gray-600 mb-4">
                  Here are the towns selected in your area selections. Let's get down to street level — which town do you want to start with?
                </p>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                {availableTowns.map((town) => (
                  <button
                    key={town}
                    onClick={() => toggleArrayValue('area_preferences', town)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      formData.area_preferences.includes(town)
                        ? 'border-blue-600 bg-blue-50 text-blue-900'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <MapPin className="w-5 h-5" />
                        <span className="font-semibold">{town}</span>
                      </div>
                      {formData.area_preferences.includes(town) && (
                        <CheckCircle className="w-5 h-5 text-blue-600" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 7 && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Specific Street Preferences</h3>
              <p className="text-gray-600 mb-4">
                Are there specific streets you'd like to live on? (Optional)
              </p>
              {availableTowns.length === 0 ? (
                <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-6 text-center">
                  <MapPin className="w-12 h-12 mx-auto mb-3 text-yellow-400" />
                  <p className="text-yellow-800 font-semibold mb-2">No towns available</p>
                  <p className="text-yellow-700 text-sm">Go back to step 5 and add areas on the map to see street options.</p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                    <p className="text-blue-800 text-sm">
                      <strong>Tip:</strong> Selecting specific streets helps us find the perfect property for you.
                      {formData.area_preferences.length > 0
                        ? ` Showing streets in: ${formData.area_preferences.join(', ')}.`
                        : ' All towns from your selected areas are shown below.'}
                    </p>
                  </div>
                  {availableTowns.map((town) => {
                    const predefinedStreets = TOWN_STREETS[town] || [];
                    const selectedStreets = formData.street_preferences[town] || [];
                    const customStreets = selectedStreets.filter(s => !predefinedStreets.includes(s));

                    return (
                      <div key={town} className="bg-gray-50 p-4 rounded-lg border-2 border-gray-200">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-bold text-gray-900 flex items-center gap-2">
                            <MapPin className="w-5 h-5 text-blue-600" />
                            {town}
                          </h4>
                          <span className="text-xs text-gray-500">
                            {selectedStreets.length} selected
                          </span>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-3">
                          {predefinedStreets.map((street) => (
                            <button
                              key={street}
                              onClick={() => toggleStreetPreference(town, street)}
                              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                                selectedStreets.includes(street)
                                  ? 'bg-blue-600 text-white shadow-sm'
                                  : 'bg-white text-gray-700 border border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                              }`}
                            >
                              {street}
                            </button>
                          ))}
                        </div>

                        {customStreets.length > 0 && (
                          <div className="mb-3 p-3 bg-white rounded-lg border border-blue-200">
                            <p className="text-xs font-semibold text-blue-900 mb-2">Custom Streets:</p>
                            <div className="flex flex-wrap gap-2">
                              {customStreets.map((street) => (
                                <div
                                  key={street}
                                  className="inline-flex items-center gap-2 px-3 py-1 bg-blue-600 text-white rounded-lg text-sm"
                                >
                                  <span>{street}</span>
                                  <button
                                    onClick={() => removeCustomStreet(town, street)}
                                    className="hover:bg-blue-700 rounded-full p-0.5"
                                  >
                                    <X className="w-3 h-3" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="pt-3 border-t border-gray-300">
                          <label className="block text-xs font-semibold text-gray-700 mb-2">
                            Street not listed here? Type it below and add it (add as many as you like):
                          </label>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={customStreetInputs[town] || ''}
                              onChange={(e) => setCustomStreetInputs({ ...customStreetInputs, [town]: e.target.value })}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  addCustomStreet(town);
                                }
                              }}
                              placeholder="Enter street name..."
                              className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            />
                            <button
                              onClick={() => addCustomStreet(town)}
                              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
                            >
                              Add
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {step === 8 && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Property Requirements</h3>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Must-Have Features (Select all that apply)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['En-suite', 'Walk-in Closet', 'Home Office', 'Utility Room', 'Garage', 'Garden', 'Sea View', 'Modern Kitchen'].map((feature) => (
                    <button
                      key={feature}
                      onClick={() => toggleArrayValue('must_haves', feature)}
                      className={`px-4 py-2 rounded-lg text-sm transition-all ${
                        formData.must_haves.includes(feature)
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 hover:bg-gray-200'
                      }`}
                    >
                      {feature}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Outdoor Space (Select all that apply)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['Private Garden', 'Balcony', 'Terrace', 'Communal Gardens', 'No outdoor space needed'].map((space) => (
                    <button
                      key={space}
                      onClick={() => toggleArrayValue('outdoor_space', space)}
                      className={`px-4 py-2 rounded-lg text-sm transition-all ${
                        formData.outdoor_space.includes(space)
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-100 hover:bg-gray-200'
                      }`}
                    >
                      {space}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Parking Requirements
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['Off-street parking', 'Garage', 'Driveway', 'On-street only', 'No parking needed'].map((parking) => (
                    <button
                      key={parking}
                      onClick={() => toggleArrayValue('parking', parking)}
                      className={`px-4 py-2 rounded-lg text-sm transition-all ${
                        formData.parking.includes(parking)
                          ? 'bg-orange-600 text-white'
                          : 'bg-gray-100 hover:bg-gray-200'
                      }`}
                    >
                      {parking}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Property Condition Preference
                </label>
                <select
                  value={formData.property_condition}
                  onChange={(e) => setFormData({ ...formData, property_condition: e.target.value })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select preference</option>
                  <option value="Move-in ready">Move-in ready</option>
                  <option value="Needs minor work">Needs minor work</option>
                  <option value="Major renovation project">Major renovation project</option>
                  <option value="No preference">No preference</option>
                </select>
              </div>
            </div>
          )}

          {step === 9 && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Timeline & Position</h3>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  When are you looking to move? *
                </label>
                <select
                  value={formData.timeline}
                  onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select timeline</option>
                  <option value="As soon as possible">As soon as possible</option>
                  <option value="Within 3 months">Within 3 months</option>
                  <option value="3-6 months">3-6 months</option>
                  <option value="6-12 months">6-12 months</option>
                  <option value="12+ months">12+ months</option>
                  <option value="Flexible">Flexible</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Your Buying Position *
                </label>
                <select
                  value={formData.buyer_position}
                  onChange={(e) => setFormData({ ...formData, buyer_position: e.target.value })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select position</option>
                  <option value="Cash buyer - Nothing to sell">Cash buyer - Nothing to sell</option>
                  <option value="Home currently up for sale with Mowatts Matchlist">Home currently up for sale with Mowatts Matchlist</option>
                  <option value="Home under offer with Mowatts Matchlist">Home under offer with Mowatts Matchlist</option>
                  <option value="Under offer with another agent">Under offer with another agent</option>
                  <option value="First time buyer with mortgage approved">First time buyer with mortgage approved</option>
                  <option value="First time buyer - mortgage in progress">First time buyer - mortgage in progress</option>
                  <option value="Need to sell current property">Need to sell current property</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Additional Requirements
                </label>
                <p className="text-sm text-gray-600 mb-2">
                  This could include more about your personal situation, family circumstances, health, or motivations.
                </p>
                <textarea
                  value={formData.additional_requirements}
                  onChange={(e) => setFormData({ ...formData, additional_requirements: e.target.value })}
                  rows={4}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Tell us more about your situation..."
                />
              </div>
            </div>
          )}

          {step === 10 && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Listing Preferences & Agreement</h3>

              <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-6">
                <h4 className="font-bold text-blue-900 mb-3 flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  List in Quiet Seekers (Optional)
                </h4>
                <p className="text-blue-800 mb-3 text-sm">
                  Would you like to be featured in our Quiet Seekers section? This allows property sellers to see your requirements and reach out if they have a matching property.
                </p>
                <div className="bg-blue-100 border border-blue-300 rounded-lg p-4 mb-4">
                  <p className="text-blue-900 text-sm font-semibold mb-2">
                    Your Listing Will Be Completely Anonymous:
                  </p>
                  <ul className="text-blue-800 text-xs space-y-1 ml-4 list-disc">
                    <li>Your name, email, and phone number will NOT be displayed</li>
                    <li>Only your property requirements and preferences will be shown</li>
                    <li>Property sellers contact us, not you directly</li>
                    <li>We handle all communications and protect your privacy</li>
                    <li>Your listing requires our approval before going live</li>
                  </ul>
                </div>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.list_in_quiet_seekers}
                    onChange={(e) => setFormData({ ...formData, list_in_quiet_seekers: e.target.checked })}
                    className="mt-1 w-5 h-5 text-blue-600 border-2 border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  />
                  <span className="text-gray-700 font-medium">
                    Yes, list my requirements anonymously in Quiet Seekers (pending approval)
                  </span>
                </label>
              </div>

              <div className="bg-green-50 border-2 border-green-200 rounded-xl p-6">
                <h4 className="font-bold text-green-900 mb-3 flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Commission Agreement
                </h4>
                <div className="space-y-3 text-sm text-gray-700 mb-4">
                  <p className="font-semibold text-green-900 text-base">
                    Our service is completely FREE until your successful purchase is completed.
                  </p>
                  <p>
                    We only charge a <strong>1% commission fee</strong> on the property we find for you, and only when:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li>We successfully match you with a property</li>
                    <li>You complete the purchase of that property</li>
                    <li>The transaction is finalized</li>
                  </ul>
                  <p className="text-green-800 font-semibold">
                    No match = No fee. No purchase = No fee. It's that simple.
                  </p>
                  <p className="text-xs text-gray-600 mt-4">
                    By checking the box below, you agree to pay a 1% commission fee of the final purchase price if we successfully find and help you purchase a property through Mowatt's Matchlist.
                  </p>
                </div>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.commission_agreed}
                    onChange={(e) => setFormData({ ...formData, commission_agreed: e.target.checked })}
                    className="mt-1 w-5 h-5 text-green-600 border-2 border-gray-300 rounded focus:ring-2 focus:ring-green-500"
                  />
                  <span className="text-gray-700 font-medium">
                    I agree to the 1% commission fee upon successful property purchase *
                  </span>
                </label>
              </div>

              <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-6">
                <h4 className="font-bold text-amber-900 mb-3">Communication Preferences</h4>
                <p className="text-sm text-gray-700 mb-4">
                  We'll keep you informed about matching properties and important updates via email and phone.
                </p>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.opt_out_communication || false}
                    onChange={(e) => setFormData({ ...formData, opt_out_communication: e.target.checked })}
                    className="mt-1 w-5 h-5 text-amber-600 border-2 border-gray-300 rounded focus:ring-2 focus:ring-amber-500"
                  />
                  <div>
                    <span className="text-gray-700 font-medium block mb-1">
                      Opt out of communications
                    </span>
                    <span className="text-sm text-red-600 font-semibold">
                      ⚠️ Warning: Opting out will significantly reduce your chances of getting a match.
                    </span>
                  </div>
                </label>
              </div>

              {!formData.commission_agreed && (
                <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4 text-center">
                  <p className="text-yellow-800 text-sm font-semibold">
                    Please agree to the commission terms to complete your registration
                  </p>
                </div>
              )}
            </div>
          )}

          {step === 11 && (
            <LegalServicesSelector
              serviceType="buying"
              propertyValue={formData.budget_max || formData.budget_min}
              onSelect={(firmId, quote) => {
                setLegalFirmId(firmId);
                setLegalQuote(quote);
              }}
              selectedFirmId={legalFirmId}
            />
          )}
        </div>

        <div className="sticky bottom-0 bg-white border-t border-gray-200 p-6 rounded-b-2xl flex items-center justify-between">
          <button
            onClick={handleBack}
            disabled={step === 1}
            className={`px-6 py-3 rounded-lg font-semibold transition-all ${
              step === 1
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Back
          </button>
          {step < totalSteps ? (
            <button
              onClick={handleNext}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-all"
            >
              Next
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!formData.commission_agreed}
              className={`px-6 py-3 rounded-lg font-semibold transition-all flex items-center gap-2 ${
                formData.commission_agreed
                  ? 'bg-green-600 text-white hover:bg-green-700'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <CheckCircle className="w-5 h-5" />
              Submit Questionnaire
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
