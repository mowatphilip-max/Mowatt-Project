interface Circle {
  lat: number;
  lng: number;
  radius: number;
}

interface TownLocation {
  name: string;
  lat: number;
  lng: number;
}

const TOWN_LOCATIONS: TownLocation[] = [
  { name: 'North Berwick', lat: 56.0586, lng: -2.7207 },
  { name: 'Gullane', lat: 56.0422, lng: -2.8297 },
  { name: 'East Linton', lat: 55.9869, lng: -2.6569 },
  { name: 'Aberlady', lat: 56.0164, lng: -2.8681 },
  { name: 'Longniddry', lat: 55.9744, lng: -2.8906 },
];

function getDistanceInMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371e3;
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

export function getTownsInCircles(circles: Circle[]): string[] {
  if (circles.length === 0) {
    return TOWN_LOCATIONS.map((t) => t.name);
  }

  const townsInRange = new Set<string>();

  circles.forEach((circle) => {
    TOWN_LOCATIONS.forEach((town) => {
      const distance = getDistanceInMeters(circle.lat, circle.lng, town.lat, town.lng);
      if (distance <= circle.radius) {
        townsInRange.add(town.name);
      }
    });
  });

  return Array.from(townsInRange);
}
